"""BellService – the single interface (API) between UI layers (bot / future web) and data + audio.

All public methods take an `actor` (id, name) for the audit log. Thread-safe.
"""
from __future__ import annotations

import hashlib
import json
import logging
import random
import re
import shutil
import threading
import time as _time
import uuid
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Callable, Protocol

from ..config import Config
from ..player.audio_tools import AudioProcessor
from ..player.player import Player
from ..storage.db import Storage
from . import hebcal, logic, redact, system
from . import holidays as holidays_mod
from .logic import DAY_NAMES_HE, DayPlan, MuteState
from .playlist import Playlist, Track
from ..version import VERSION, changelog, vtuple

log = logging.getLogger(__name__)

SYSTEM_ACTOR = ("system", "מערכת")
REASON_HE = {"holiday": "יום חופש", "auto_holiday": "חופשה", "override": "מערכת מיוחדת לתאריך",
             "school_day": "יום לימודים (בוטל חופש)", "regular": "לפי היום בשבוע", "off_day": "אין לימודים"}


class Notifier(Protocol):
    def send(self, text: str) -> None: ...


@dataclass
class Actor:
    id: str
    name: str


def _actor(a) -> Actor:
    if isinstance(a, Actor):
        return a
    return Actor(str(a[0]), str(a[1]))


class BellService:
    def __init__(self, cfg: Config, storage: Storage, player: Player, audio: AudioProcessor,
                 notifier: Notifier | None = None, clock: Callable[[], datetime] = datetime.now):
        self.cfg = cfg
        self.sid = cfg.school_id
        self.db = storage
        self.player = player
        self.audio = audio
        self.notifier = notifier
        self.now = clock
        self._lock = threading.RLock()
        self._fired: set[tuple[date, str]] = set()
        self._last_fired = storage.get_setting(cfg.school_id, "last_fired") or ""
        self._auto_cache: dict = {}
        self._auto_cache_day: date | None = None
        self._notified: set[str] = set()
        self._rng = random.SystemRandom()
        self._morning_sent: date | None = None
        self._last_sync: str = "טרם בוצע"
        self.started_at = clock()
        self.bot_changed = threading.Event()   # set when token changes -> bot reconnects
        self.bot_status: dict = {"state": "off", "username": None, "error": None}
        self.ringtones_dir = cfg.data_dir / "ringtones"
        self.media_dir = cfg.data_dir / "media"
        self.uploads_dir = cfg.data_dir / "uploads"
        self.playlist = Playlist()
        self._track_started = 0.0
        for d in (self.ringtones_dir, self.media_dir, self.uploads_dir):
            d.mkdir(parents=True, exist_ok=True)

    # ================= setup =================
    def seed(self) -> None:
        """Idempotent first-run initialization from config."""
        db, sid, cfg = self.db, self.sid, self.cfg
        db.ensure_school(sid, cfg.school_name)
        if db.get_setting(sid, "users_seeded") != "1":
            for cid in cfg.authorized_chat_ids:
                db.add_user(sid, cid, "מקובץ ההגדרות", "מערכת", is_admin=True)
            db.set_setting(sid, "users_seeded", "1")
        if db.get_setting(sid, "seeded") != "1":
            self._seed_fresh()
        if not db.get_setting(sid, "weekday_map"):   # fresh install or upgrade from 1.1
            self._seed_weekdays()
        self._migrate_template_fixes()

    # Corrections to *template defaults* that shipped earlier. A schedule is changed only if it is still
    # exactly the old default – anything the school edited is never touched by an update.
    TEMPLATE_FIXES = [
        ("sunday_2", "ראשון", ["15:50", "16:30", "17:15", "17:30", "18:15"]),
    ]

    def _migrate_template_fixes(self):
        for key, name, old_times in self.TEMPLATE_FIXES:
            flag = f"fix_{key}"
            if self.db.get_setting(self.sid, flag) == "1":
                continue
            self.db.set_setting(self.sid, flag, "1")
            new_times = self.cfg.seed_schedules.get(name)
            sch = self.db.get_schedule_by_name(self.sid, name)
            if not sch or not new_times:
                continue
            bells = self.db.list_bells(self.sid, sch["id"])
            if [b["time"] for b in bells] != old_times:
                continue
            for b in bells:
                self.db.delete_bell(self.sid, b["id"])
            for t in new_times:
                self.db.add_bell(self.sid, sch["id"], logic.parse_time(t))
            self.db.log_action(self.sid, *SYSTEM_ACTOR, "template_fix", f"{name}: {', '.join(new_times)}")

    def _seed_schedule(self, name: str, times: list[str]) -> int:
        s = self.db.get_schedule_by_name(self.sid, name)
        sid_ = s["id"] if s else self.db.create_schedule(self.sid, name)
        for t in times:
            self.db.add_bell(self.sid, sid_, logic.parse_time(t))
        return sid_

    def _seed_fresh(self):
        db, sid, cfg = self.db, self.sid, self.cfg
        regular = cfg.seed_schedules.get(cfg.regular_name, [])
        self._seed_schedule(cfg.regular_name, regular)
        for name in cfg.extra_schedules:
            if not db.get_schedule_by_name(sid, name):
                self._seed_schedule(name, regular)
        db.set_setting(sid, "bell_volume", cfg.default_bell_volume)
        db.set_setting(sid, "music_volume", cfg.default_music_volume)
        default_src = cfg.assets_dir / "default_bell.wav"
        if default_src.exists():
            dst = self.ringtones_dir / "default_bell.wav"
            shutil.copyfile(default_src, dst)
            rid = db.add_ringtone(sid, "צלצול ברירת מחדל (זמני)", self._rel(dst), 0, "מערכת")
            db.set_setting(sid, "active_ringtone_id", rid)
        db.set_setting(sid, "seeded", "1")
        db.log_action(sid, *SYSTEM_ACTOR, "seed", "אתחול ראשוני")

    def _seed_weekdays(self):
        """Creates the per-weekday schedules (e.g. Sunday / Thursday) and assigns schedules to weekdays."""
        cfg, db = self.cfg, self.db
        old_active = db.get_setting(self.sid, "active_schedule_id")  # installs from 1.1
        ids = {}
        for name in set(n for n in cfg.weekday_seed.values() if n):
            existing = db.get_schedule_by_name(self.sid, name)
            if existing and db.list_bells(self.sid, existing["id"]):
                ids[name] = existing["id"]
            else:
                ids[name] = self._seed_schedule(name, cfg.seed_schedules.get(name, []))
        if old_active and cfg.regular_name in ids:
            ids[cfg.regular_name] = int(old_active)   # keep the school's edited regular schedule
        wmap = {wd: ids.get(name) if name else None for wd, name in cfg.weekday_seed.items()}
        db.set_setting(self.sid, "weekday_map", json.dumps({str(k): v for k, v in wmap.items()}))
        db.log_action(self.sid, *SYSTEM_ACTOR, "weekdays_seed",
                      ", ".join(f"{DAY_NAMES_HE[wd]}: {self.schedule_name(v)}" for wd, v in sorted(wmap.items())))

    def _rel(self, p: Path) -> str:
        try:
            return str(p.relative_to(self.cfg.data_dir))
        except ValueError:
            return str(p)

    def _abs(self, p: str) -> Path:
        pp = Path(p)
        return pp if pp.is_absolute() else self.cfg.data_dir / pp

    def _audit(self, actor, action: str, details: str = ""):
        a = _actor(actor)
        self.db.log_action(self.sid, a.id, a.name, action, details)
        log.info("[%s] %s %s", a.name, action, details)

    def log_unauthorized(self, chat_id, name: str, what: str):
        self._audit((str(chat_id), name or "?"), "unauthorized", what[:100])

    # ================= schedule resolution =================
    def _int_setting(self, key: str, default: int) -> int:
        v = self.db.get_setting(self.sid, key)
        return int(v) if v not in (None, "") else default

    def weekday_map(self) -> dict[int, int | None]:
        raw = json.loads(self.db.get_setting(self.sid, "weekday_map") or "{}")
        return {int(k): (int(v) if v else None) for k, v in raw.items()}

    def set_weekday(self, weekday: int, schedule_id: int | None, actor):
        if schedule_id:
            self.get_schedule(schedule_id)
        m = self.weekday_map()
        m[int(weekday)] = int(schedule_id) if schedule_id else None
        self.db.set_setting(self.sid, "weekday_map", json.dumps({str(k): v for k, v in m.items()}))
        self._audit(actor, "weekday_set", f"יום {DAY_NAMES_HE[int(weekday)]}: "
                                          f"{self.schedule_name(schedule_id) if schedule_id else 'אין צלצולים'}")

    def auto_holidays(self) -> dict[date, tuple[str, str]]:
        """Official + computed school vacations, precomputed for ~50 years and refreshed daily."""
        today = self.now().date()
        if self._auto_cache_day != today:
            self._auto_cache = holidays_mod.vacation_days(hebcal.hebrew_year_of(today) - 1, 51)
            self._auto_cache_day = today
        return self._auto_cache

    def _plans(self, start: date, end: date) -> dict[date, DayPlan]:
        db, sid = self.db, self.sid
        overrides = {k: v["schedule_id"] for k, v in db.overrides_between(sid, start, end).items()}
        hol = {k: (v["note"] or "חופש") for k, v in db.holidays_map(sid, start, end).items()}
        school = db.school_days_between(sid, start, end)
        auto = {k: v[0] for k, v in self.auto_holidays().items() if start <= k <= end}
        wmap = self.weekday_map()
        out, d = {}, start
        while d <= end:
            out[d] = logic.resolve_day(d, wmap, overrides, hol, school, auto)
            d += timedelta(days=1)
        return out

    def day_plan(self, d: date) -> tuple[DayPlan, list[str]]:
        plan = self._plans(d, d)[d]
        times = [b["time"] for b in self.db.list_bells(self.sid, plan.schedule_id)] if plan.schedule_id else []
        return plan, times

    def schedule_name(self, schedule_id: int | None) -> str:
        if not schedule_id:
            return "—"
        s = self.db.get_schedule(self.sid, schedule_id)
        return s["name"] if s else "?"

    def next_bell(self) -> tuple[datetime, DayPlan] | None:
        return logic.next_bell(self.now(), self.day_plan)

    # ================= mute =================
    def mute_state(self) -> MuteState:
        g = lambda k: self.db.get_setting(self.sid, k)  # noqa: E731
        day = g("mute_day")
        return MuteState(forever=g("mute_forever") == "1",
                         day=date.fromisoformat(day) if day else None,
                         next_once=g("mute_next") == "1")

    def set_mute(self, mode: str, actor) -> str:
        db, sid = self.db, self.sid
        if mode == "off":
            for k in ("mute_forever", "mute_day", "mute_next"):
                db.set_setting(sid, k, "")
        elif mode == "next":
            db.set_setting(sid, "mute_next", "1")
        elif mode == "today":
            db.set_setting(sid, "mute_day", self.now().date().isoformat())
        elif mode == "forever":
            db.set_setting(sid, "mute_forever", "1")
        else:
            raise ValueError(mode)
        self._audit(actor, "mute", {"off": "ביטול", "next": "צלצול אחד", "today": "היום",
                                    "forever": "עד שיוחזר"}[mode])
        return self.mute_state().describe(self.now().date())

    # ================= firing =================
    def tick(self, prev: datetime, now: datetime) -> None:
        """Called every second by the scheduler thread."""
        for d in sorted({prev.date(), now.date()}):
            plan, times = self.day_plan(d)
            for t in logic.due_times(times, d, prev, now, self.cfg.fire_grace_seconds):
                key = (d, t)
                if key in self._fired or f"{d.isoformat()} {t}" <= self._last_fired:
                    continue  # already handled (also across a restart, e.g. during an update)
                self._fired.add(key)
                self._last_fired = f"{d.isoformat()} {t}"
                self.db.set_setting(self.sid, "last_fired", self._last_fired)
                self._fire_scheduled(d, t, plan)
        self._fired = {k for k in self._fired if k[0] >= now.date() - timedelta(days=1)}
        self._maybe_morning_check(prev, now)
        self._maybe_daily_maintenance(prev, now)
        self._maybe_auto_update(prev, now)
        self._playlist_tick()

    def _fire_scheduled(self, d: date, t: str, plan: DayPlan):
        with self._lock:
            reason = self.mute_state().reason_for(d)
            if reason == "next":
                self.db.set_setting(self.sid, "mute_next", "")
            if reason:
                self._audit(SYSTEM_ACTOR, "bell_skipped", f"{t} ({reason})")
                return
            try:
                self._interrupt_media()
                path, rt_name = self._take_ringtone()
                self.player.play_bell(path, self.volumes()["bell"])
                self._audit(SYSTEM_ACTOR, "bell", f"{t} – {self.schedule_name(plan.schedule_id)} – {rt_name}")
            except Exception as e:
                log.exception("bell failed")
                self._audit(SYSTEM_ACTOR, "bell_failed", f"{t}: {e}")
                self._notify(f"⚠️ צלצול {t} נכשל: {e}")

    def ring_now(self, actor) -> None:
        self._interrupt_media()
        path, rt_name = self._take_ringtone()
        self.player.play_bell(path, self.volumes()["bell"])
        self._audit(actor, "ring_now", rt_name)

    def _notify(self, text: str):
        if self.notifier:
            try:
                self.notifier.send(text)
            except Exception:
                log.exception("notify failed")

    # Fire-and-forget: the bot only speaks on a real fault or when asked. Routine messages are opt-in.
    NOTIFY_OPTIONS = {"morning_status": "סטטוס בוקר לפני הצלצול הראשון",
                      "holiday_today": "הודעה בבוקר של יום חופש",
                      "holiday_reminder": "תזכורת שבוע לפני חופשה"}

    def notify_options(self) -> dict[str, bool]:
        return {k: self.db.get_setting(self.sid, f"notify_{k}") == "1" for k in self.NOTIFY_OPTIONS}

    def set_notify_option(self, key: str, on: bool, actor):
        if key not in self.NOTIFY_OPTIONS:
            raise ValueError("אפשרות לא מוכרת")
        self.db.set_setting(self.sid, f"notify_{key}", "1" if on else "")
        self._audit(actor, "notify_option", f"{self.NOTIFY_OPTIONS[key]}: {'פעיל' if on else 'כבוי'}")

    def _once(self, key: str) -> bool:
        if key in self._notified:
            return False
        self._notified.add(key)
        return True

    def health_problems(self) -> list[str]:
        problems = []
        if not self.player.healthy():
            problems.append("אין התקן שמע – הצלצולים לא יישמעו")
        rt = self.active_ringtone()
        if rt and not self._abs(rt["path"]).exists():
            problems.append(f"קובץ הצלצול '{rt['name']}' חסר – מתנגן צלצול ברירת המחדל")
        return problems

    def _maybe_morning_check(self, prev: datetime, now: datetime):
        today = now.date()
        plan, times = self.day_plan(today)
        opts = None
        if times:
            first = datetime.combine(today, logic.to_time(min(times)))
            check_at = first - timedelta(minutes=self.cfg.morning_check_minutes_before)
            if prev < check_at <= now and self._once(f"morning:{today}"):
                problems = self.health_problems()
                if problems:   # a real fault: always reported
                    self._notify("⚠️ תקלה במערכת הצלצולים:\n" + "\n".join("• " + p for p in problems))
                opts = self.notify_options()
                if opts["morning_status"]:
                    self._notify("☀️ סטטוס בוקר\n\n" + self.status_text())
        try:
            at = datetime.combine(today, logic.to_time(self.cfg.notify_time))
        except ValueError:
            return
        if not (prev < at <= now):
            return
        opts = opts or self.notify_options()
        if opts["holiday_today"] and plan.reason in ("holiday", "auto_holiday") and self._once(f"hol:{today}"):
            self._notify(f"🏖 היום חופש{(' – ' + plan.name) if plan.name else ''}. אין צלצולים.")
        if opts["holiday_reminder"]:
            for span in self.upcoming_vacations(days=8):
                if span["from"] == today + timedelta(days=7) and self._once(f"rem:{span['from']}"):
                    self._notify(f"📅 תזכורת: בעוד שבוע ({span['from']:%d/%m}) מתחילה חופשת {span['name']} "
                                 f"עד {span['to']:%d/%m}. אם צריך – עדכנו את לוח החופשות.")

    def _maybe_daily_maintenance(self, prev: datetime, now: datetime):
        try:
            at = datetime.combine(now.date(), logic.to_time(self.cfg.time_sync_at))
        except Exception:
            return
        if prev < at <= now:
            threading.Thread(target=self._maintenance, daemon=True).start()

    def _maintenance(self):
        try:
            self.sync_gsheet()
        except Exception:
            log.exception("gsheet")
        ok, out = system.sync_clock()
        self._last_sync = f"{self.now():%d/%m %H:%M} – {'הצליח' if ok else 'נכשל'}"
        log.info("time sync: %s %s", ok, out)
        for u in self.db.old_uploads(self.sid, (self.now() - timedelta(days=7)).isoformat()):
            self.db.delete_upload(self.sid, u["id"])
            self._abs(u["path"]).unlink(missing_ok=True)
        cutoff = _time.time() - 2 * 86400
        for f in self.media_dir.glob("*"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except OSError:
                pass

    # ================= status =================
    def status(self) -> dict:
        now = self.now()
        today = now.date()
        plan, times = self.day_plan(today)
        nb = self.next_bell()
        rt = self.upcoming_ringtone()
        return {
            "now": now, "plan": plan, "schedule_name": self.schedule_name(plan.schedule_id),
            "times": times, "remaining": [t for t in times if t > now.strftime("%H:%M")],
            "next": nb, "next_schedule": self.schedule_name(nb[1].schedule_id) if nb else None,
            "mute": self.mute_state().describe(today), "ringtone": rt["name"] if rt else "ברירת מחדל",
            "volumes": self.volumes(), "playing": self.player.now_playing(),
            "audio_ok": self.player.healthy(), "ffmpeg": self.audio.available,
            "last_sync": self._last_sync, "started": self.started_at,
        }

    def status_text(self) -> str:
        s = self.status()
        now: datetime = s["now"]
        plan: DayPlan = s["plan"]
        lines = [f"📊 סטטוס – {self.cfg.school_name}",
                 f"📅 יום {DAY_NAMES_HE[now.weekday()]} {now:%d/%m/%Y}, {now:%H:%M}"]
        if plan.schedule_id:
            lines.append(f"🗓 מערכת היום: {s['schedule_name']} ({REASON_HE[plan.reason]})")
            lines.append(f"🔔 נותרו היום: {len(s['remaining'])} מתוך {len(s['times'])}")
        else:
            lines.append(f"🗓 היום אין צלצולים ({plan.name or REASON_HE[plan.reason]})")
        lines.append("⏭ הצלצול הבא: " + self.next_bell_text(s["next"], now))
        lines.append(f"🔇 השתקה: {s['mute']}")
        lines.append(f"🎼 צלצול: {s['ringtone']}" + (" (אקראי מהסבב)" if self.ringtone_mode() == "random" else ""))
        v = s["volumes"]
        lines.append(f"🔊 עוצמה: צלצול {v['bell']}% | שירים וכריזה {v['music']}%")
        p = s["playing"]
        lines.append(f"▶️ מתנגן כעת: {p['title']}" if p else "▶️ מתנגן כעת: —")
        lines.append("🔈 שמע: " + ("תקין" if s["audio_ok"] else "⚠️ אין התקן שמע!"))
        if not s["ffmpeg"]:
            lines.append("⚠️ ffmpeg חסר – אין נרמול עוצמה")
        lines.append(f"🕒 סנכרון שעון אחרון: {s['last_sync']}")
        lines.append(f"⏱ פועל מאז: {s['started']:%d/%m %H:%M}")
        lines.append(f"🏷 גרסה: {VERSION}")
        lines.append(f"🆔 מזהה מכשיר: {self.device_id}")
        return "\n".join(lines)

    def next_bell_text(self, nb, now: datetime | None = None) -> str:
        now = now or self.now()
        if not nb:
            return "אין צלצולים ב-30 הימים הקרובים"
        dt, plan = nb
        mins = int((dt - now).total_seconds() // 60)
        if dt.date() == now.date():
            when = f"היום {dt:%H:%M} (עוד {mins} דק')" if mins < 120 else f"היום {dt:%H:%M}"
        elif dt.date() == now.date() + timedelta(days=1):
            when = f"מחר {dt:%H:%M}"
        else:
            when = f"יום {DAY_NAMES_HE[dt.weekday()]} {dt:%d/%m} {dt:%H:%M}"
        muted = self.mute_state().reason_for(dt.date())
        return when + f" – {self.schedule_name(plan.schedule_id)}" + (" 🔇 (יושתק)" if muted else "")

    # ================= schedules =================
    def list_schedules(self) -> list[dict]:
        wmap = self.weekday_map()
        rows = self.db.list_schedules(self.sid)
        for r in rows:
            r["days"] = sorted((wd for wd, v in wmap.items() if v == r["id"]), key=lambda w: (w + 1) % 7)
            r["active"] = bool(r["days"])
        return rows

    def get_schedule(self, schedule_id: int) -> dict:
        s = self.db.get_schedule(self.sid, schedule_id)
        if not s:
            raise ValueError("המערכת לא נמצאה")
        s["bells"] = self.db.list_bells(self.sid, schedule_id)
        s["days"] = sorted((wd for wd, v in self.weekday_map().items() if v == schedule_id), key=lambda w: (w + 1) % 7)
        s["active"] = bool(s["days"])
        return s

    def add_bells(self, schedule_id: int, text: str, actor) -> tuple[list[str], list[str]]:
        s = self.get_schedule(schedule_id)
        added, existing = [], []
        for t in logic.parse_times(text):
            (added if self.db.add_bell(self.sid, schedule_id, t) else existing).append(t)
        if added:
            self._audit(actor, "bell_add", f"{s['name']}: {', '.join(added)}")
        return added, existing

    def delete_bell(self, bell_id: int, actor) -> dict:
        b = self.db.get_bell(self.sid, bell_id)
        if not b:
            raise ValueError("השעה לא נמצאה")
        self.db.delete_bell(self.sid, bell_id)
        self._audit(actor, "bell_delete", f"{self.schedule_name(b['schedule_id'])}: {b['time']}")
        return b

    def move_bell(self, bell_id: int, new_time_text: str, actor) -> tuple[dict, str]:
        b = self.db.get_bell(self.sid, bell_id)
        if not b:
            raise ValueError("השעה לא נמצאה")
        new = logic.parse_time(new_time_text)
        self.db.move_bell(self.sid, bell_id, new)
        self._audit(actor, "bell_move", f"{self.schedule_name(b['schedule_id'])}: {b['time']} → {new}")
        return b, new

    def create_schedule(self, name: str, actor, copy_from: int | None = None) -> int:
        name = name.strip()[:40]
        if not name:
            raise ValueError("שם ריק")
        new_id = self.db.create_schedule(self.sid, name)
        if copy_from:
            for b in self.db.list_bells(self.sid, copy_from):
                self.db.add_bell(self.sid, new_id, b["time"])
        self._audit(actor, "schedule_create", name + (f" (עותק של {self.schedule_name(copy_from)})" if copy_from else ""))
        return new_id

    def rename_schedule(self, schedule_id: int, name: str, actor):
        old = self.schedule_name(schedule_id)
        self.db.rename_schedule(self.sid, schedule_id, name.strip()[:40])
        self._audit(actor, "schedule_rename", f"{old} → {name}")

    def delete_schedule(self, schedule_id: int, actor):
        days = [wd for wd, v in self.weekday_map().items() if v == schedule_id]
        if days:
            raise ValueError("המערכת משויכת לימים: " + ", ".join(DAY_NAMES_HE[d] for d in days)
                             + ". קודם משייכים לימים האלה מערכת אחרת.")
        name = self.schedule_name(schedule_id)
        self.db.delete_schedule(self.sid, schedule_id)
        self._audit(actor, "schedule_delete", name)


    # ----- per-date -----
    def set_date_schedule(self, dates: list[date], schedule_id: int, actor):
        s = self.get_schedule(schedule_id)
        for d in dates:
            self.db.set_override(self.sid, d, schedule_id)
        self._audit(actor, "date_schedule", f"{s['name']}: " + ", ".join(f"{d:%d/%m}" for d in dates))

    def list_date_schedules(self) -> list[dict]:
        return self.db.list_overrides(self.sid, self.now().date())

    def remove_date_schedule(self, d: date, actor):
        self.db.delete_override(self.sid, d)
        self._audit(actor, "date_schedule_remove", f"{d:%d/%m/%Y}")

    # ----- holidays -----
    def add_holidays(self, dates: list[date], actor, note: str = ""):
        for d in dates:
            self.db.add_holiday(self.sid, d, note)
        self._audit(actor, "holiday_add", ", ".join(f"{d:%d/%m}" for d in dates))

    def list_holidays(self) -> list[dict]:
        return self.db.list_holidays(self.sid, self.now().date())

    def upcoming_vacations(self, days: int = 120) -> list[dict]:
        """Vacation spans (auto + school-added) that start within `days`, merged per name, for display."""
        today = self.now().date()
        plans = self._plans(today, today + timedelta(days=days))
        spans, cur = [], None
        for d, p in sorted(plans.items()):
            if p.reason in ("holiday", "auto_holiday"):
                name = p.name or "חופש"
                if cur and cur["name"] == name and (d - cur["to"]).days <= 3:
                    cur["to"] = d
                else:
                    cur = {"name": name, "from": d, "to": d, "auto": p.reason == "auto_holiday"}
                    spans.append(cur)
        return spans

    def set_day_mode(self, d: date, mode: str, actor, schedule_id: int | None = None):
        """mode: auto (follow the vacation calendar) | school (cancel a holiday) | holiday | schedule"""
        db, sid = self.db, self.sid
        db.delete_override(sid, d)
        db.delete_holiday(sid, d)
        db.set_school_day(sid, d, False)
        if mode == "school":
            db.set_school_day(sid, d, True)
        elif mode == "holiday":
            db.add_holiday(sid, d, "חופש")
        elif mode == "schedule":
            self.get_schedule(int(schedule_id))
            db.set_override(sid, d, int(schedule_id))
        elif mode != "auto":
            raise ValueError("מצב לא מוכר")
        label = {"auto": "לפי לוח החופשות", "school": "יום לימודים", "holiday": "חופש",
                 "schedule": f"מערכת {self.schedule_name(schedule_id)}"}[mode]
        self._audit(actor, "day_mode", f"{d:%d/%m/%Y}: {label}")

    def import_holidays(self, filename: str, data: bytes, actor) -> dict:
        from . import holiday_import
        entries = holiday_import.parse(filename, data, self.now().date())
        if not entries:
            raise ValueError("לא נמצאו בקובץ תאריכי חופשה")
        tag = f"import:{datetime.now():%Y%m%d%H%M%S}"
        for d, name in entries:
            self.db.add_holiday(self.sid, d, name or "חופש", tag)
        days = sorted(d for d, _ in entries)
        self._audit(actor, "holiday_import", f"{filename}: {len(days)} ימים ({days[0]:%d/%m/%y}–{days[-1]:%d/%m/%y})")
        return {"tag": tag, "count": len(days), "from": days[0].isoformat(), "to": days[-1].isoformat(),
                "items": [{"date": d.isoformat(), "name": n} for d, n in sorted(entries)[:200]]}

    def undo_import(self, tag: str, actor) -> int:
        if not tag.startswith("import:"):
            raise ValueError("ייבוא לא מוכר")
        n = self.db.delete_holidays_by_source(self.sid, tag)
        self._audit(actor, "holiday_import_undo", f"{n} ימים")
        return n

    # ----- Google Sheet (published CSV) -----
    def gsheet_settings(self) -> dict:
        g = lambda k: self.db.get_setting(self.sid, k) or ""  # noqa: E731
        return {"url": g("gsheet_url"), "last_ok": g("gsheet_last_ok"), "status": g("gsheet_status")}

    def set_gsheet_url(self, url: str, actor) -> dict:
        url = url.strip()
        if url and not url.startswith("https://"):
            raise ValueError("הכתובת חייבת להתחיל ב-https:// (קישור 'פרסום לאינטרנט' בפורמט CSV)")
        self.db.set_setting(self.sid, "gsheet_url", url)
        if not url:
            self.db.delete_holidays_by_source(self.sid, "gsheet")
            self.db.set_setting(self.sid, "gsheet_status", "")
        self._audit(actor, "gsheet_url", "הוגדר קישור" if url else "הקישור הוסר")
        return self.sync_gsheet() if url else self.gsheet_settings()

    def sync_gsheet(self, fetch=None) -> dict:
        """Pulls the published sheet. Offline -> keeps the last copy (the rows already stored)."""
        from . import holiday_import
        url = self.db.get_setting(self.sid, "gsheet_url")
        if not url:
            return self.gsheet_settings()
        try:
            data = (fetch or holiday_import.fetch_url)(url)
            entries = holiday_import.parse("sheet.csv", data, self.now().date(), keywords_only=True)
        except Exception as e:  # no internet / bad sheet: keep the last copy, no bot message (not a fault)
            self.db.set_setting(self.sid, "gsheet_status", f"לא עודכן ({type(e).__name__}) – משתמשים בעותק האחרון")
            log.warning("gsheet sync failed: %s", e)
            return self.gsheet_settings()
        self.db.delete_holidays_by_source(self.sid, "gsheet")
        for d, name in entries:
            self.db.add_holiday(self.sid, d, name or "חופש", "gsheet")
        (self.cfg.data_dir / "gsheet_last.csv").write_bytes(data)
        now = self.now()
        self.db.set_setting(self.sid, "gsheet_last_ok", now.isoformat(timespec="minutes"))
        self.db.set_setting(self.sid, "gsheet_status", f"עודכן {now:%d/%m %H:%M} – {len(entries)} ימי חופשה")
        return self.gsheet_settings()

    def remove_holiday(self, d: date, actor):
        self.db.delete_holiday(self.sid, d)
        self._audit(actor, "holiday_remove", f"{d:%d/%m/%Y}")

    # ================= volume =================
    def volumes(self) -> dict:
        return {"bell": self._int_setting("bell_volume", self.cfg.default_bell_volume),
                "music": self._int_setting("music_volume", self.cfg.default_music_volume)}

    def set_volume(self, kind: str, value: int, actor) -> dict:
        if kind not in ("bell", "music"):
            raise ValueError(kind)
        value = max(0, min(100, int(value)))
        self.db.set_setting(self.sid, f"{kind}_volume", value)
        if kind == "music":
            self.player.set_media_volume(value)
        self._audit(actor, "volume", f"{'צלצול' if kind == 'bell' else 'שירים וכריזה'} {value}%")
        return self.volumes()

    # ================= ringtones =================
    def active_ringtone(self) -> dict | None:
        rid = self.db.get_setting(self.sid, "active_ringtone_id")
        return self.db.get_ringtone(self.sid, int(rid)) if rid else None

    def active_ringtone_path(self) -> Path:
        rt = self.active_ringtone()
        if rt:
            p = self._abs(rt["path"])
            if p.exists():
                return p
            log.error("ringtone file missing: %s", p)
        return self.cfg.assets_dir / "default_bell.wav"

    def list_ringtones(self) -> list[dict]:
        active = self.active_ringtone()
        upcoming = self.upcoming_ringtone()
        rows = self.db.list_ringtones(self.sid)
        for r in rows:
            r["active"] = bool(active and r["id"] == active["id"])
            r["in_rotation"] = bool(r.get("in_rotation"))
            r["next"] = bool(upcoming and r["id"] == upcoming["id"])
        return rows

    # ----- fixed / random rotation -----
    def ringtone_mode(self) -> str:
        return "random" if self.db.get_setting(self.sid, "ringtone_mode") == "random" else "fixed"

    def set_ringtone_mode(self, mode: str, actor):
        if mode not in ("fixed", "random"):
            raise ValueError("מצב לא מוכר")
        self.db.set_setting(self.sid, "ringtone_mode", mode)
        self._choose_next()
        self._audit(actor, "ringtone_mode", "אקראי מהסבב" if mode == "random" else "צלצול קבוע")

    def set_rotation(self, rid: int, on: bool, actor):
        rt = self.get_ringtone(rid)
        self.db.set_rotation(self.sid, rid, on)
        self._choose_next()
        self._audit(actor, "ringtone_rotation", f"{rt['name']}: {'נוסף לסבב' if on else 'הוצא מהסבב'}")

    def rotation(self) -> list[dict]:
        return [r for r in self.db.list_ringtones(self.sid) if r.get("in_rotation") and self._abs(r["path"]).exists()]

    def _choose_next(self, exclude: int | None = None) -> dict | None:
        """Pre-chooses the ringtone of the next bell (random mode): never the same one twice in a row."""
        pool = self.rotation()
        if exclude is not None and len(pool) > 1:
            pool = [r for r in pool if r["id"] != exclude]
        cur = self.db.get_setting(self.sid, "next_ringtone_id")
        if cur and any(str(r["id"]) == cur for r in pool) and exclude is None:
            return next(r for r in pool if str(r["id"]) == cur)
        pick = self._rng.choice(pool) if pool else None
        self.db.set_setting(self.sid, "next_ringtone_id", pick["id"] if pick else "")
        return pick

    def upcoming_ringtone(self) -> dict | None:
        """The ringtone the next bell will play."""
        if self.ringtone_mode() == "random":
            nxt = self.db.get_setting(self.sid, "next_ringtone_id")
            pool = self.rotation()
            hit = [r for r in pool if str(r["id"]) == nxt]
            if hit:
                return hit[0]
            if pool:
                return self._choose_next()
        return self.active_ringtone()

    def _take_ringtone(self) -> tuple[Path, str]:
        """Ringtone for a bell that is ringing now; in random mode also pre-chooses the following one."""
        rt = self.upcoming_ringtone()
        if self.ringtone_mode() == "random" and rt:
            self.db.set_setting(self.sid, "last_ringtone_id", rt["id"])
            self._choose_next(exclude=rt["id"])
        if rt:
            p = self._abs(rt["path"])
            if p.exists():
                return p, rt["name"]
            log.error("ringtone file missing: %s", p)
        return self.cfg.assets_dir / "default_bell.wav", "ברירת מחדל"

    def get_ringtone(self, rid: int) -> dict:
        rt = self.db.get_ringtone(self.sid, rid)
        if not rt:
            raise ValueError("הצלצול לא נמצא")
        rt["abs_path"] = self._abs(rt["path"])
        return rt

    def import_ringtone(self, src: Path, name: str, actor, start: float | None = None,
                        end: float | None = None) -> dict:
        dst = self.ringtones_dir / f"rt_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}.wav"
        out, dur = self.audio.convert(src, dst, normalize=True, max_seconds=None,   # full length, normalized
                                      start=start, end=end)
        a = _actor(actor)
        rid = self.db.add_ringtone(self.sid, name[:60] or "צלצול", self._rel(out), dur, a.name)
        cut = f", {logic.fmt_secs(start or 0)}–{logic.fmt_secs(end)}" if end is not None else ""
        self._audit(actor, "ringtone_upload", f"{name} ({dur:.1f} שנ'{cut})")
        return self.get_ringtone(rid)

    def activate_ringtone(self, rid: int, actor) -> dict:
        rt = self.get_ringtone(rid)
        cur = self.active_ringtone()
        if cur and cur["id"] != rid:
            self.db.set_setting(self.sid, "previous_ringtone_id", cur["id"])
        self.db.set_setting(self.sid, "active_ringtone_id", rid)
        self._audit(actor, "ringtone_activate", rt["name"])
        return rt

    def revert_ringtone(self, actor) -> dict:
        prev = self.db.get_setting(self.sid, "previous_ringtone_id")
        if not prev or not self.db.get_ringtone(self.sid, int(prev)):
            raise ValueError("אין צלצול קודם")
        return self.activate_ringtone(int(prev), actor)

    def delete_ringtone(self, rid: int, actor):
        rt = self.get_ringtone(rid)
        if rt["id"] == (self.active_ringtone() or {}).get("id"):
            raise ValueError("אי אפשר למחוק את הצלצול הפעיל")
        self.db.delete_ringtone(self.sid, rid)
        if self.db.get_setting(self.sid, "next_ringtone_id") == str(rid):
            self._choose_next()
        try:
            rt["abs_path"].unlink(missing_ok=True)
        except OSError:
            pass
        self._audit(actor, "ringtone_delete", rt["name"])

    def rename_ringtone(self, rid: int, name: str, actor):
        rt = self.get_ringtone(rid)
        name = name.strip()[:60]
        if not name:
            raise ValueError("שם ריק")
        self.db.rename_ringtone(self.sid, rid, name)
        self._audit(actor, "ringtone_rename", f"{rt['name']} → {name}")

    def preview_ringtone(self, rid: int, actor):
        rt = self.get_ringtone(rid)
        self._interrupt_media()
        self.player.play_bell(rt["abs_path"], self.volumes()["bell"])
        self._audit(actor, "ringtone_preview", rt["name"])

    # ================= song library (uploads) =================
    def stage_upload(self, src: Path, name: str, actor, library: bool = True) -> dict:
        """Stores an uploaded audio file (compressed). library=True -> it stays in the song library until deleted;
        False (e.g. a file uploaded only to make a ringtone) -> temporary, removed after a week."""
        dst = self.uploads_dir / f"u_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}"
        out, dur = self.audio.encode_song(src, dst, max_seconds=None)
        peaks = json.dumps(self.audio.peaks(out))
        name = (name or "שיר").strip()[:80]
        uid = self.db.add_upload(self.sid, name, self._rel(out), dur, _actor(actor).name, library, peaks)
        if library:
            self._audit(actor, "song_add", f"{name} ({logic.fmt_secs(dur)})")
        return self.get_upload(uid)

    def get_upload(self, uid: int) -> dict:
        u = self.db.get_upload(self.sid, int(uid))
        if not u or not self._abs(u["path"]).exists():
            raise ValueError("השיר כבר לא זמין – העלו אותו שוב")
        u["abs_path"] = self._abs(u["path"])
        return u

    @staticmethod
    def _trim_of(u: dict) -> tuple[float | None, float | None]:
        return (u.get("trim_start"), u.get("trim_end")) if u.get("trim_end") is not None else (None, None)

    def _song_view(self, u: dict) -> dict:
        ts, te = self._trim_of(u)
        return {"id": u["id"], "name": u["name"], "duration": u["duration"], "trim_start": ts, "trim_end": te,
                "length": (te - (ts or 0)) if te is not None else u["duration"],
                "created_at": u["created_at"], "created_by": u["created_by"]}

    def list_songs(self, query: str = "") -> list[dict]:
        return [self._song_view(u) for u in self.db.list_songs(self.sid, query.strip())
                if self._abs(u["path"]).exists()]

    def list_uploads(self, limit: int = 200) -> list[dict]:   # the UI's "songs" list = the library
        return self.list_songs()[:limit]

    def upload_peaks(self, uid: int, buckets: int = 240) -> list[float]:
        u = self.get_upload(uid)
        if u.get("peaks"):
            return json.loads(u["peaks"])
        peaks = self.audio.peaks(u["abs_path"], buckets)   # songs uploaded before 1.3
        self.db.update_upload(self.sid, u["id"], peaks=json.dumps(peaks))
        return peaks

    def _check_range(self, u: dict, start, end) -> tuple[float | None, float | None]:
        if start is None and end is None:
            return None, None
        start = float(start or 0)
        end = float(end) if end is not None else u["duration"]
        if u["duration"]:
            end = min(end, u["duration"])
        if end - start < 0.5:
            raise ValueError("הקטע קצר מדי או שהסוף לפני ההתחלה")
        return start, end

    def set_song_trim(self, uid: int, start, end, actor) -> dict:
        """Saves the chosen segment with the song (None/None = whole song)."""
        u = self.get_upload(uid)
        start, end = self._check_range(u, start, end)
        if start is not None and start <= 0.05 and end >= (u["duration"] or end) - 0.05:
            start = end = None                                      # the whole song = no trim
        self.db.update_upload(self.sid, u["id"], trim_start=start, trim_end=end, in_library=1)
        self._audit(actor, "song_trim", f"{u['name']}: " + (f"{logic.fmt_secs(start)}–{logic.fmt_secs(end)}"
                                                              if end is not None else "כל השיר"))
        return self._song_view(self.get_upload(uid))

    def rename_song(self, uid: int, name: str, actor):
        u = self.get_upload(uid)
        name = name.strip()[:80]
        if not name:
            raise ValueError("שם ריק")
        self.db.update_upload(self.sid, u["id"], name=name)
        self._audit(actor, "song_rename", f"{u['name']} → {name}")

    def delete_song(self, uid: int, actor):
        u = self.get_upload(uid)
        with self._lock:
            cur = self.playlist.current
            if cur and cur.upload_id == u["id"]:
                self.playlist.clear()
                self.player.stop_media()
            self.playlist.items = [t for t in self.playlist.items if t is cur or t.upload_id != u["id"]]
        self.db.delete_upload(self.sid, u["id"])
        u["abs_path"].unlink(missing_ok=True)
        self._audit(actor, "song_delete", u["name"])

    def make_clip(self, uid: int, start=None, end=None, normalize: bool = True) -> tuple[Path, float]:
        u = self.get_upload(uid)
        start, end = self._check_range(u, start, end)
        if start is None:
            return u["abs_path"], u["duration"]
        dst = self.media_dir / f"clip_{uuid.uuid4().hex[:10]}.wav"
        return self.audio.convert(u["abs_path"], dst, normalize=normalize, max_seconds=None, start=start, end=end)

    def ringtone_from_upload(self, uid: int, actor, start=None, end=None, name: str | None = None,
                             activate: bool = True) -> dict:
        """Library song -> ringtone. Without an explicit segment the song's saved trim is used."""
        u = self.get_upload(uid)
        if start is None and end is None:
            start, end = self._trim_of(u)
        start, end = self._check_range(u, start, end)
        rt = self.import_ringtone(u["abs_path"], name or Path(u["name"]).stem, actor, start=start, end=end)
        if activate:
            self.activate_ringtone(rt["id"], actor)
        return rt

    # ================= songs / playlist / announcements =================
    def _interrupt_media(self):
        """A bell (or announcement) stops the song and the whole playlist."""
        with self._lock:
            self.playlist.clear()

    def _song_track(self, u: dict) -> Track:
        ts, te = self._trim_of(u)
        # \u2066…\u2069 = left-to-right isolate, so "0:03–0:18" isn't reversed inside Hebrew text
        title = u["name"] + (f" ✂️ \u2066{logic.fmt_secs(ts or 0)}–{logic.fmt_secs(te)}\u2069" if te is not None else "")
        return Track(title=title, path=None if te is not None else u["abs_path"], upload_id=u["id"])

    def _start_track(self, track: Track | None):
        if track:
            if track.path is None:   # trimmed library song: cut just before it plays
                u = self.get_upload(track.upload_id)
                track.path, _ = self.make_clip(u["id"], *self._trim_of(u), normalize=False)
            self._track_started = _time.time()
            self.player.play_media(track.path, self.volumes()["music"], track.title, "song")

    def play_uploads(self, ids: list[int], actor, start=None, end=None) -> dict:
        """One id = a single song, several = a playlist in the given order. Each song plays with its saved trim;
        an explicit segment for a single song is saved as its trim."""
        if not ids:
            raise ValueError("לא נבחרו שירים")
        if len(ids) == 1 and (start is not None or end is not None):
            self.set_song_trim(ids[0], start, end, actor)
        tracks = [self._song_track(self.get_upload(uid)) for uid in ids]
        with self._lock:
            self._start_track(self.playlist.load(tracks))
        self._audit(actor, "playlist_play" if len(tracks) > 1 else "song_play",
                    f"{len(tracks)} שירים" if len(tracks) > 1 else tracks[0].title)
        return self.playlist_state()

    def play_library(self, actor, ids: list[int] | None = None, shuffle: bool = False) -> dict:
        """'Play all' / 'Shuffle' / play a selection from the library."""
        ids = list(ids) if ids else [s["id"] for s in self.list_songs()]
        if not ids:
            raise ValueError("ספריית השירים ריקה")
        if shuffle:
            self._rng.shuffle(ids)
        return self.play_uploads(ids, actor)

    def enqueue(self, ids: list[int], actor) -> dict:
        tracks = [self._song_track(self.get_upload(uid)) for uid in ids]
        if not tracks:
            raise ValueError("לא נבחרו שירים")
        with self._lock:
            self._start_track(self.playlist.extend(tracks))
        self._audit(actor, "playlist_add", ", ".join(t.title for t in tracks)[:150])
        return self.playlist_state()

    def _playlist_tick(self):
        with self._lock:
            if not self.playlist.active or self.player.now_playing():
                return
            if _time.time() - self._track_started < 2:
                return
            self._advance()

    def _advance(self):
        for _ in range(len(self.playlist.items) + 1):
            track = self.playlist.advance()
            if not track:
                return
            try:
                self._start_track(track)
                return
            except Exception:
                log.exception("track failed, skipping")

    def playlist_state(self) -> dict:
        with self._lock:
            st = self.playlist.state()
        st["playing"] = self.player.now_playing()
        return st

    def playlist_next(self, actor) -> dict:
        with self._lock:
            if not self.playlist.active:
                raise ValueError("אין פלייליסט פעיל")
            self._advance()
            if not self.playlist.active:
                self.player.stop_media()
        self._audit(actor, "playlist_next")
        return self.playlist_state()

    def playlist_remove(self, key: int, actor) -> dict:
        with self._lock:
            t = self.playlist.remove(int(key))
        self._audit(actor, "playlist_remove", t.title)
        return self.playlist_state()

    def playlist_move(self, key: int, delta: int, actor) -> dict:
        with self._lock:
            self.playlist.move(int(key), int(delta))
        return self.playlist_state()

    def prepare_media(self, src: Path, normalize: bool) -> Path:
        dst = self.media_dir / f"m_{uuid.uuid4().hex[:10]}.wav"
        out, _ = self.audio.convert(src, dst, normalize=normalize,
                                    max_seconds=None, fade=True)
        return out

    def play_song(self, prepared: Path, title: str, actor):
        with self._lock:
            self._start_track(self.playlist.load([Track(title=title, path=prepared)]))
        self._audit(actor, "song_play", title)

    def play_announcement(self, prepared: Path, actor):
        self._interrupt_media()
        self.player.play_media(prepared, self.volumes()["music"], "כריזה", "announcement")
        self._audit(actor, "announcement")

    def stop_media(self, actor):
        with self._lock:
            self.playlist.clear()
            self.player.stop_media()
        self._audit(actor, "media_stop")

    def stop_all(self, actor):
        """'Stop playback' button: silences everything now. The bell schedule is not touched."""
        with self._lock:
            self.playlist.clear()
            self.player.stop_all()
        self._audit(actor, "stop_all")

    # ================= users / bot settings =================
    def is_authorized(self, chat_id: int) -> bool:
        return self.db.is_user(self.sid, int(chat_id))

    def authorized_ids(self) -> list[int]:
        return [u["chat_id"] for u in self.db.list_users(self.sid)]

    def user_key(self, chat_id) -> str:
        return hashlib.sha256(f"{self.sid}:{chat_id}".encode()).hexdigest()[:12]

    def list_users(self) -> list[dict]:
        """For display only: no full chat ids leave the service."""
        return [{"key": self.user_key(u["chat_id"]), "name": u["name"], "masked": redact.mask_id(u["chat_id"]),
                 "is_admin": bool(u["is_admin"]), "added_at": u["added_at"]} for u in self.db.list_users(self.sid)]

    def _chat_id_by_key(self, key: str) -> int:
        for u in self.db.list_users(self.sid):
            if self.user_key(u["chat_id"]) == key:
                return int(u["chat_id"])
        raise ValueError("המשתמש לא נמצא")

    def add_user(self, chat_id, name: str, actor):
        try:
            cid = int(str(chat_id).strip())
        except ValueError:
            raise ValueError("מזהה צ'אט חייב להיות מספר")
        name = (name or "").strip()[:40] or str(cid)
        self.db.add_user(self.sid, cid, name, _actor(actor).name)
        self._audit(actor, "user_add", f"{name} ({redact.mask_id(cid)})")

    def is_admin(self, chat_id: int) -> bool:
        return self.db.is_admin(self.sid, int(chat_id))

    def set_admin(self, chat_id: int, is_admin: bool, actor):
        self.db.set_admin(self.sid, int(chat_id), bool(is_admin))
        self._audit(actor, "user_admin", f"{redact.mask_id(chat_id)}: {'מנהל' if is_admin else 'משתמש רגיל'}")

    def set_admin_by_key(self, key: str, is_admin: bool, actor):
        self.set_admin(self._chat_id_by_key(key), is_admin, actor)

    def remove_user_by_key(self, key: str, actor):
        self.remove_user(self._chat_id_by_key(key), actor)

    def approve_request(self, key: str, actor):
        for r in self.db.recent_unauthorized(self.sid):
            if r["actor_id"].lstrip("-").isdigit() and self.user_key(int(r["actor_id"])) == key:
                return self.add_user(int(r["actor_id"]), r["actor_name"], actor)
        raise ValueError("הבקשה לא נמצאה")

    def remove_user(self, chat_id: int, actor):
        self.db.delete_user(self.sid, int(chat_id))
        self._audit(actor, "user_remove", redact.mask_id(chat_id))

    def access_requests(self) -> list[dict]:
        users = set(self.authorized_ids())
        return [{"key": self.user_key(int(r["actor_id"])), "name": r["actor_name"],
                 "masked": redact.mask_id(r["actor_id"]), "ts": r["ts"]}
                for r in self.db.recent_unauthorized(self.sid)
                if r["actor_id"].lstrip("-").isdigit() and int(r["actor_id"]) not in users][:10]

    TELEGRAM_API = "https://api.telegram.org"

    def bot_mode(self) -> str:
        """'telegram' (default) or 'relay' – our own Bot-API server (School Bells relay on Cloudflare)."""
        return "relay" if self.db.get_setting(self.sid, "bot_mode") == "relay" else "telegram"

    def telegram_token(self) -> str:
        t = self.db.get_setting(self.sid, "bot_token")
        if t is not None:           # set (or deliberately cleared) from the UI
            return t
        return self.cfg.bot_token if self.cfg.bot_enabled else ""

    def bot_token(self) -> str:
        """The credential of the active connection (Telegram token or relay key). Internal use only (bot/notifier);
        never returned by any API."""
        if self.bot_mode() == "relay":
            return self.db.get_setting(self.sid, "relay_key") or ""
        return self.telegram_token()

    def bot_server(self) -> str:
        """Base URL of the Bot API in use, e.g. https://api.telegram.org or https://relay.example.workers.dev"""
        if self.bot_mode() == "relay":
            return (self.db.get_setting(self.sid, "relay_url") or "").rstrip("/")
        return self.TELEGRAM_API

    def bot_api_base(self) -> str:
        return self.bot_server() + "/bot"

    def bot_file_base(self) -> str:
        return self.bot_server() + "/file/bot"

    def token_info(self) -> dict:
        t = self.telegram_token()
        return {"set": bool(t), "last4": t[-4:] if t else "", "bot": self.bot_status.get("username")}

    def relay_info(self) -> dict:
        """No key in here – only whether one is saved, its school id (public) and the phone link."""
        url = (self.db.get_setting(self.sid, "relay_url") or "").rstrip("/")
        key = self.db.get_setting(self.sid, "relay_key") or ""
        school = key.split(":", 1)[0] if key else ""
        return {"mode": self.bot_mode(), "url": url, "key_set": bool(key), "last4": key[-4:] if key else "",
                "phone_link": f"{url}/s/{school}/" if url and school else ""}

    @staticmethod
    def validate_relay_url(url: str) -> str:
        url = (url or "").strip().rstrip("/")
        if url.endswith("/bot"):
            url = url[:-4]
        m = re.fullmatch(r"(https://[A-Za-z0-9.-]+(?::\d+)?|http://(?:127\.0\.0\.1|localhost)(?::\d+)?)", url)
        if not m:
            raise ValueError("כתובת השרת צריכה להתחיל ב-https://, למשל https://school-bells-relay.NAME.workers.dev")
        return url

    def set_relay(self, url: str | None, key: str | None, actor):
        """Saves the relay address and/or key (a key looks like a bot token: '<school>:<secret>') and switches to it."""
        if url is not None:
            self.db.set_setting(self.sid, "relay_url", self.validate_relay_url(url))
        if key:
            key = key.strip()
            if not re.fullmatch(r"\d{5,}:[A-Za-z0-9_-]{30,}", key):
                raise ValueError("המפתח לא נראה תקין. מעתיקים אותו כמו שהוא מדף הניהול של השרת")
            self.db.set_setting(self.sid, "relay_key", key)
        if not self.db.get_setting(self.sid, "relay_url"):
            raise ValueError("חסרה כתובת השרת")
        self.db.set_setting(self.sid, "bot_mode", "relay")
        self._audit(actor, "bot_mode", "שרת פרטי" + (" – מפתח חדש נשמר" if key else ""))
        self.bot_changed.set()

    def clear_relay_key(self, actor):
        self.db.set_setting(self.sid, "relay_key", "")
        self._audit(actor, "token_clear", "מפתח השרת הפרטי נמחק")
        self.bot_changed.set()

    def set_bot_mode(self, mode: str, actor):
        if mode not in ("telegram", "relay"):
            raise ValueError("מצב לא מוכר")
        if mode == "relay" and not self.db.get_setting(self.sid, "relay_url"):
            raise ValueError("קודם הזינו כתובת שרת ומפתח")
        self.db.set_setting(self.sid, "bot_mode", mode)
        self._audit(actor, "bot_mode", "טלגרם" if mode == "telegram" else "שרת פרטי")
        self.bot_changed.set()

    def clear_bot_token(self, actor):
        self.db.set_setting(self.sid, "bot_token", "")   # the Telegram token (the relay key has its own)
        self._audit(actor, "token_clear", "הטוקן נמחק")
        self.bot_changed.set()

    @staticmethod
    def validate_token(token: str) -> str:
        token = token.strip()
        if not re.fullmatch(r"\d{5,}:[A-Za-z0-9_-]{30,}", token):
            raise ValueError("הטוקן לא נראה תקין. הוא אמור להיראות כך: 123456789:AAH...")
        return token

    def set_bot_token(self, token: str, actor):
        token = self.validate_token(token)
        self.db.set_setting(self.sid, "bot_token", token)
        self._audit(actor, "token_set", "טוקן חדש נשמר")
        self.bot_changed.set()

    def set_bot_status(self, state: str, username: str | None = None, error: str | None = None,
                       code: str | None = None, retry_at: datetime | None = None, detail: str | None = None):
        """state: off | connecting | online | error. code: 409 / 429 / 401 / 403 / ssl / proxy / network / error.
        detail: the original connection error (e.g. 'SSLCertVerificationError: ... CERTIFICATE_VERIFY_FAILED')."""
        self.bot_status = {"state": state, "username": username, "error": error, "code": code,
                           "retry_at": retry_at.isoformat(timespec="seconds") if retry_at else None,
                           "detail": detail}

    # ================= version / software update =================
    @property
    def version(self) -> str:
        return VERSION

    @property
    def updates_dir(self) -> Path:
        return self.cfg.app_dir / "updates"

    def inspect_update(self, zip_path: Path, actor) -> dict:
        from ..update import package
        info = package.inspect(zip_path, self.cfg.app_dir)
        token = uuid.uuid4().hex[:12]
        self._pending_updates = {token: (zip_path, info)}  # only the latest one can be installed
        self._audit(actor, "update_check", f"{info['current']} → {info['version']} (חתימה תקינה)")
        return {**{k: v for k, v in info.items() if k != "prefix"}, "token": token}

    def apply_update(self, token: str, actor) -> dict:
        from ..update import package
        pending = getattr(self, "_pending_updates", {}).pop(token, None)
        if not pending:
            raise ValueError("העדכון כבר לא זמין – העלו את הקובץ שוב")
        zip_path, info = pending
        lock = self.updates_dir / "update.lock"
        if lock.exists() and _time.time() - lock.stat().st_mtime < 1800:
            self._pending_updates = {token: pending}
            raise ValueError("עדכון קודם עדיין מסתיים – נסו שוב בעוד דקה")
        info = package.inspect(zip_path, self.cfg.app_dir)  # re-verify right before installing
        staged = package.stage(zip_path, info, self.updates_dir / "staging")
        self._audit(actor, "update_start", f"{info['current']} → {info['version']}")
        a = _actor(actor)
        self.db.set_setting(self.sid, "update_requested_by", a.id if a.id.lstrip("-").isdigit() else "")
        self.launch_update(staged)
        return {"version": info["version"], "current": info["current"]}

    # ----- remote source (nightly auto-update) -----
    def update_settings(self) -> dict:
        g = lambda k: self.db.get_setting(self.sid, k) or ""  # noqa: E731
        url = g("update_url")
        return {"url": url, "channel": g("update_effective_channel") or "stable",   # decided by the signed manifest
                "auto": bool(url) and g("update_auto") != "0",           # on by default once a URL is set
                "check_at": self.cfg.update_check_at, "last_check": g("update_last_check"),
                "last_status": g("update_last_status")}

    def set_update_settings(self, actor, url: str | None = None, auto: bool | None = None) -> dict:
        """The channel is NOT a setting: beta is granted only by the vendor's signed manifest (beta_devices)."""
        from ..update import remote
        changes = []
        if url is not None:
            url = remote.check_url(url) if url.strip() else ""
            self.db.set_setting(self.sid, "update_url", url)
            changes.append("כתובת " + ("הוגדרה" if url else "הוסרה"))
        if auto is not None:
            self.db.set_setting(self.sid, "update_auto", "1" if auto else "0")
            changes.append("עדכון אוטומטי " + ("פעיל" if auto else "כבוי"))
        self._audit(actor, "update_source", ", ".join(changes))
        return self.update_settings()

    @property
    def device_id(self) -> str:
        from ..update.device import device_id
        return device_id(self.cfg.data_dir)

    def about(self) -> dict:
        st = self.update_settings()
        return {"version": VERSION, "device_id": self.device_id, "school": self.cfg.school_name,
                "channel": st["channel"], "update_url": st["url"], "auto": st["auto"],
                "last_check": st["last_check"], "last_status": st["last_status"]}

    def in_school_hours(self, when: datetime, margin_min: int = 45) -> bool:
        _, times = self.day_plan(when.date())
        if not times:
            return False
        first = datetime.combine(when.date(), logic.to_time(times[0])) - timedelta(minutes=margin_min)
        last = datetime.combine(when.date(), logic.to_time(times[-1])) + timedelta(minutes=margin_min)
        return first <= when <= last

    def check_for_update(self, actor, install: bool = True, manual: bool = False) -> dict:
        """Asks the update source for a newer signed version on this computer's channel and installs it.
        Returns {status: none|up_to_date|installing|unavailable|error, ...}."""
        from ..update import remote
        st = self.update_settings()
        now = self.now()
        if not st["url"]:
            return {"status": "none", "message": "לא הוגדרה כתובת מקור עדכונים"}

        def done(status, message, **kw):
            self.db.set_setting(self.sid, "update_last_check", now.isoformat(timespec="minutes"))
            self.db.set_setting(self.sid, "update_last_status", message)
            return {"status": status, "message": message, **kw}

        try:
            man = remote.fetch_manifest(st["url"])
            channel, entry = remote.choose_entry(man, st["url"], self.device_id)
        except remote.SourceError as e:   # offline / source down: not a fault, try again next night
            log.warning("update source unavailable: %s", e)
            return done("unavailable", f"מקור העדכונים לא זמין ({e})")
        except remote.ManifestRejected as e:   # unsigned / tampered manifest: refuse, report as a fault
            if not manual:
                self._notify(f"⚠️ מקור העדכונים נדחה: {e}")
            return done("error", f"מקור העדכונים נדחה: {e}")
        self.db.set_setting(self.sid, "update_effective_channel", channel)
        st["channel"] = channel
        cur, new = VERSION, str(entry["version"])
        if vtuple(new) <= vtuple(cur):
            return done("up_to_date", f"מעודכן (גרסה {cur}, ערוץ {'בדיקה' if st['channel'] == 'beta' else 'יציב'})",
                        version=cur)
        if not install:
            return done("available", f"קיימת גרסה {new}", version=new)
        nb = self.next_bell()
        if nb and (nb[0] - now).total_seconds() < 180:
            return done("later", "צלצול בעוד פחות מ-3 דקות – נסו שוב אחריו")
        try:
            path = remote.download(entry, self.updates_dir / "incoming" / f"remote-{new}.zip")
            info = self.inspect_update(path, actor)          # signature + version + hashes
            self.apply_update(info["token"], actor)
        except remote.SourceError as e:
            return done("unavailable", f"ההורדה נכשלה ({e})")
        except ValueError as e:                              # bad signature / damaged / not applicable: a fault
            res = done("error", f"עדכון {new} לא הותקן: {e}")
            if not manual:
                self._notify(f"⚠️ עדכון אוטומטי לגרסה {new} לא הותקן: {e}")
            return res
        return done("installing", f"מתקין את גרסה {new}", version=new)

    def _maybe_auto_update(self, prev: datetime, now: datetime):
        try:
            at = datetime.combine(now.date(), logic.to_time(self.cfg.update_check_at))
        except ValueError:
            return
        if not (prev < at <= now):
            return
        st = self.update_settings()
        if not st["auto"] or self.in_school_hours(now):      # never during school hours
            return
        threading.Thread(target=self._auto_update_job, daemon=True).start()

    def _auto_update_job(self):
        try:
            self.check_for_update(SYSTEM_ACTOR)
        except Exception as e:
            log.exception("auto update")
            self._notify(f"⚠️ בדיקת העדכון האוטומטית נכשלה: {e}")

    def launch_update(self, staged: Path):  # replaced in tests
        from ..update import package
        package.launch(staged, self.cfg.app_dir)

    def last_update_result(self) -> dict | None:
        import json
        try:
            return json.loads((self.updates_dir / "last_result.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def report_update_result(self):
        """At startup. Fire-and-forget: a successful update is reported only to the admin who started it
        from the bot (it answers their command); a failed update (rolled back) is a fault -> all admins."""
        r = self.last_update_result()
        if not r or r.get("notified"):
            return
        if r.get("status") == "ok" and r.get("to") == VERSION:
            self._audit(SYSTEM_ACTOR, "update_done", f"{r.get('from')} → {VERSION}")
            requester = self.db.get_setting(self.sid, "update_requested_by")
            if requester and self.notifier and hasattr(self.notifier, "send_to"):
                self.notifier.send_to(int(requester), f"✅ העדכון לגרסה {VERSION} הותקן בהצלחה.")
        elif r.get("status") == "rolled_back":
            tail = "\n".join((r.get("log_tail") or "").splitlines()[-8:])[-900:]
            self._notify(f"⚠️ העדכון לגרסה {r.get('to')} נכשל והמערכת חזרה לגרסה {r.get('from')}.\n"
                         f"סיבה: {r.get('error', '?')}" + (f"\n\nסוף הלוג:\n{redact.redact(tail)}" if tail else ""))
            self._audit(SYSTEM_ACTOR, "update_failed", f"{r.get('to')}: {r.get('error', '')}"[:200])
        self.db.set_setting(self.sid, "update_requested_by", "")
        r["notified"] = True
        try:
            (self.updates_dir / "last_result.json").write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass

    # ================= views for UI =================
    def today_timeline(self) -> dict:
        now = self.now()
        plan, times = self.day_plan(now.date())
        hm = now.strftime("%H:%M:%S")
        items, next_marked = [], False
        for t in times:
            if t + ":00" <= hm:
                state = "past"
            elif not next_marked:
                state, next_marked = "next", True
            else:
                state = "future"
            items.append({"time": t, "state": state})
        return {"plan": plan, "items": items}

    def calendar_month(self, year: int, month: int) -> list[dict]:
        import calendar as _cal
        first = date(year, month, 1)
        last = date(year, month, _cal.monthrange(year, month)[1])
        plans = self._plans(first, last)
        auto = self.auto_holidays()
        manual = self.db.holidays_map(self.sid, first, last)
        out = []
        for d, plan in sorted(plans.items()):
            src = manual.get(d, {}).get("source", "")
            out.append({"date": d.isoformat(), "day": d.day, "weekday": d.weekday(), "reason": plan.reason,
                        "name": plan.name, "schedule_id": plan.schedule_id,
                        "schedule_name": self.schedule_name(plan.schedule_id) if plan.schedule_id else None,
                        "auto_name": auto[d][0] if d in auto else None,
                        "auto_source": auto[d][1] if d in auto else None,
                        "source": "gsheet" if src == "gsheet" else "import" if src.startswith("import:") else src})
        return out

    def set_holiday(self, d: date, on: bool, actor):
        if on:
            self.add_holidays([d], actor)
        else:
            self.remove_holiday(d, actor)

    # ================= log =================
    def recent_log(self, limit: int = 20) -> list[dict]:
        return self.db.recent_actions(self.sid, limit)
