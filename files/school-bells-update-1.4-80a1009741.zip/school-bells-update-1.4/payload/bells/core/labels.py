"""Hebrew labels shared by all UIs (bot, local web)."""

ACTION_HE = {
    "ring_now": "צלצול ידני", "bell": "צלצול", "bell_skipped": "צלצול הושתק", "bell_failed": "צלצול נכשל",
    "mute": "השתקה", "bell_add": "הוספת שעות", "bell_delete": "מחיקת שעה", "bell_move": "הזזת שעה",
    "schedule_create": "מערכת חדשה", "schedule_rename": "שינוי שם מערכת", "schedule_delete": "מחיקת מערכת",
    "schedule_activate": "מעבר מערכת", "date_schedule": "מערכת לתאריך", "date_schedule_remove": "ביטול מערכת לתאריך",
    "holiday_add": "יום חופש", "holiday_remove": "ביטול יום חופש", "volume": "עוצמה",
    "ringtone_upload": "העלאת צלצול", "ringtone_activate": "החלפת צלצול", "ringtone_delete": "מחיקת צלצול",
    "ringtone_preview": "השמעת צלצול", "song_play": "ניגון שיר", "announcement": "כריזה", "media_stop": "עצירת ניגון",
    "unauthorized": "⛔ ניסיון לא מורשה", "seed": "אתחול", "user_add": "הוספת משתמש",
    "user_remove": "הסרת משתמש", "token_set": "עדכון טוקן", "ringtone_rename": "שינוי שם צלצול", "playlist_play": "ניגון פלייליסט", "playlist_next": "שיר הבא",
    "playlist_remove": "הסרה מהתור", "user_admin": "הרשאת מנהל",
    "update_check": "בדיקת עדכון", "weekday_set": "שיוך מערכת ליום", "weekdays_seed": "מערכות לפי ימים",
    "day_mode": "שינוי יום בלוח", "holiday_import": "ייבוא חופשות", "holiday_import_undo": "ביטול ייבוא",
    "gsheet_url": "גיליון חופשות", "token_clear": "מחיקת טוקן", "bot_mode": "חיבור הבוט", "notify_option": "הגדרת התראות",
    "ringtone_mode": "מצב צלצול", "template_fix": "תיקון ברירת מחדל", "song_add": "שיר נוסף לספרייה", "song_trim": "חיתוך שיר",
    "song_rename": "שינוי שם שיר", "song_delete": "מחיקת שיר", "playlist_add": "הוספה לתור", "stop_all": "עצירת השמעה",
    "update_source": "מקור עדכונים", "update_auto_check": "בדיקת עדכון אוטומטית", "ringtone_rotation": "סבב צלצולים", "update_start": "התקנת עדכון", "update_done": "עדכון הושלם", "update_failed": "עדכון נכשל",
}
