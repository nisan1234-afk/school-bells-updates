"use strict";
/* Local UI for the bell system. Talks only to the local BellService API (127.0.0.1). */

// ---------- helpers ----------
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;  // only used with static markup
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return el;
}
const icon = (id) => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); const u = document.createElementNS("http://www.w3.org/2000/svg", "use"); u.setAttribute("href", "#i-" + id); s.append(u); return s; };
const $ = (sel) => document.querySelector(sel);
const pad = (n) => String(n).padStart(2, "0");
const WD = ["א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"];
const MONTHS = ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"];
const DAYS = ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"];

async function api(method, url, body) {
  const r = await fetch(url, {
    method, headers: { "Content-Type": "application/json", "X-Bells": "1" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let j = {};
  try { j = await r.json(); } catch (e) { /* empty */ }
  if (!r.ok) throw new Error(j.error || "שגיאה בתקשורת עם התוכנה");
  return j;
}
const GET = (u) => api("GET", u);
const POST = (u, b) => api("POST", u, b || {});

function toast(text, err) {
  const t = h("div", { class: "toast" + (err ? " err" : "") }, text);
  $("#toasts").append(t);
  setTimeout(() => t.remove(), err ? 5000 : 2600);
}
async function act(fn, okText) {
  try { const r = await fn(); if (okText) toast(okText); await poll(); return r ?? true; }
  catch (e) { toast(e.message, true); }
}

function modal(title, body, buttons) {
  return new Promise((resolve) => {
    const back = $("#modal");
    back.replaceChildren();
    const close = (v) => { back.hidden = true; back.replaceChildren(); resolve(v); };
    const btns = buttons.map((b) => h("button", { class: "btn " + (b.cls || ""), onclick: () => close(b.value ? b.value() : b.ret) }, b.text));
    back.append(h("div", { class: "modal", role: "dialog" }, h("h3", {}, title), body, h("div", { class: "btns" }, btns)));
    back.hidden = false;
    back.onclick = (e) => { if (e.target === back) close(null); };
    const first = back.querySelector("input,select");
    if (first) { first.focus(); first.addEventListener("keydown", (e) => { if (e.key === "Enter") btns[0].click(); }); }
  });
}
function ask(title, label, value) {
  const inp = h("input", { type: "text", value: value || "" });
  return modal(title, h("label", { class: "grid", style: "gap:6px" }, label, inp),
    [{ text: "אישור", cls: "primary", value: () => inp.value.trim() || null }, { text: "ביטול", ret: null }]);
}

const fmtDate = (iso) => { const [y, m, d] = iso.split("-").map(Number); return `${d}/${m}/${y}`; };
const parseLocal = (iso) => new Date(iso);  // server sends local time without zone

// ---------- state polling ----------
let S = null;           // latest /api/state
let offset = 0;         // server clock - browser clock
let page = "home";
let booted = false;

async function poll() {
  try {
    S = await GET("/api/state");
    offset = parseLocal(S.now).getTime() - Date.now();
    renderSide();
    if (page === "home") updateHome();
    if (page === "songs") updatePlaylistPanel();
  } catch (e) {
    $("#side-status").replaceChildren(h("div", {}, h("span", { class: "dot bad" }), "אין חיבור לתוכנת הצלצולים"));
  }
}
// the bot's real state: code (409 / 429 / 401 / 403 / network) + message + when it will try again
function botError(b) {
  const label = { "409": "409 – הבוט פועל במקום אחר", "429": "429 – הגבלת קצב", "401": "401 – טוקן נדחה",
                  "403": "403 – נחסם", ssl: "SSL – תעודה לא מוכרת", proxy: "שגיאת פרוקסי",
                  network: "אין רשת לטלגרם" }[b.code] || "שגיאה";
  let wait = "";
  if (b.retry_at) {
    const sec = Math.max(0, Math.round((parseLocal(b.retry_at).getTime() - (Date.now() + offset)) / 1000));
    wait = sec > 0 ? ` · ניסיון חוזר בעוד ${sec >= 120 ? Math.round(sec / 60) + " דק'" : sec + " שנ'"}` : " · מנסה עכשיו…";
  }
  return { label, detail: (b.error || "") + wait };
}
function renderSide() {
  $("#school-name").textContent = S.school;
  const b = S.bot;
  const botLine = b.state === "online" ? [h("span", { class: "dot ok" }), "בוט מחובר " , h("span", { class: "ltr" }, b.username || "")]
    : b.state === "off" ? [h("span", { class: "dot" }), "בוט לא מוגדר"]
    : b.state === "connecting" ? [h("span", { class: "dot warn" }), "מתחבר לטלגרם..."]
    : [h("span", { class: "dot " + (b.code === "401" || b.code === "409" ? "bad" : "warn") }), h("span", { title: botError(b).detail }, "בוט: " + botError(b).label)];
  $("#side-status").replaceChildren(
    h("div", {}, h("span", { class: "dot " + (S.audio_ok ? "ok" : "bad") }), S.audio_ok ? "שמע תקין" : "אין התקן שמע!"),
    h("div", {}, ...botLine));
  $("#side-status").append(h("div", { class: "version" }, "גרסה " + S.version));
  const badge = $("#req-badge");
  badge.hidden = !S.requests; badge.textContent = S.requests || "";
}

// ---------- HOME ----------
let muteOpen = false, dragging = false;
function renderHome() {
  const m = $("#main");
  m.replaceChildren(
    h("div", { class: "grid" },
      h("div", { class: "hero" },
        h("div", { class: "card clock-card" },
          h("div", { class: "date", id: "h-date" }),
          h("div", { class: "hdate", id: "h-hdate" }),
          h("div", { class: "clock ltr", id: "h-clock" }, "--:--:--"),
          h("div", { class: "today-sched", id: "h-sched" })),
        h("div", { class: "card next-card" },
          h("div", { class: "next-label" }, "הצלצול הבא בעוד"),
          h("div", { class: "countdown ltr", id: "h-count" }, "--:--"),
          h("div", { class: "next-sub", id: "h-next" }),
          h("div", { id: "h-mute" }))),
      h("div", { class: "actions" },
        h("button", { class: "big ring", onclick: () => act(() => POST("/api/ring"), "🔔 צלצל!") }, icon("bell"), "צלצול עכשיו"),
        h("div", { style: "position:relative" },
          h("button", { class: "big mute", id: "h-mutebtn", style: "width:100%", onclick: (e) => { e.stopPropagation(); muteOpen = !muteOpen; updateHome(); } }, icon("mute"), "השתקה"),
          h("div", { id: "h-pop" })),
        h("button", { class: "big stop", id: "h-stop", onclick: () => act(() => POST("/api/stop"), "ההשמעה נעצרה") }, icon("stop"), "עצור השמעה")),
      h("div", { class: "lower" },
        h("div", { class: "card" },
          h("div", { class: "row", style: "margin-bottom:14px" }, h("h3", { style: "margin:0" }, "הצלצולים של היום"), h("span", { class: "spacer" }), h("span", { class: "muted small", id: "h-count2" })),
          h("div", { id: "h-timeline" })),
        h("div", { class: "card" },
          h("h3", {}, "עוצמה"),
          h("div", { class: "vol" }, volRow("bell", "🔔 צלצול"), volRow("music", "🎵 שירים וכריזה")),
          h("div", { class: "status-list", id: "h-status" })))));
  document.addEventListener("click", closeMute);
  if (S) updateHome();
}
function closeMute() { if (muteOpen) { muteOpen = false; updateHome(); } }
function volRow(kind, label) {
  const out = h("output", { id: "v-out-" + kind }, "");
  const r = h("input", { type: "range", min: 0, max: 100, step: 5, id: "v-" + kind,
    oninput: () => { dragging = true; out.textContent = r.value + "%"; },
    onchange: async () => { dragging = false; await act(() => POST("/api/volume", { kind, value: +r.value })); } });
  return h("div", { class: "vol-row" }, h("label", {}, label, out), r);
}
function updateHome() {
  if (!S || !$("#h-clock")) return;
  const now = new Date(Date.now() + offset);
  const d = parseLocal(S.now);
  $("#h-date").textContent = `יום ${S.day_name}, ${new Intl.DateTimeFormat("he-IL", { day: "numeric", month: "long", year: "numeric" }).format(d)}`;
  try { $("#h-hdate").textContent = new Intl.DateTimeFormat("he-IL-u-ca-hebrew", { day: "numeric", month: "long", year: "numeric" }).format(d); } catch (e) { /* no hebrew calendar */ }
  $("#h-sched").textContent = S.today.schedule ? `מערכת היום: ${S.today.schedule}` : `היום אין צלצולים · ${S.today_name || S.today.reason_he}`;
  tickClock(now);

  $("#h-next").textContent = S.next ? S.next.text : "אין צלצולים בקרוב";
  const mt = S.mute.forever || S.mute.today || S.mute.next;
  $("#h-mute").replaceChildren(mt ? h("div", { class: "mute-banner" }, icon("mute"), "השתקה פעילה: " + S.mute.text) : "");
  $("#h-mutebtn").classList.toggle("on", !!mt);
  $("#h-pop").replaceChildren(muteOpen ? h("div", { class: "popover", onclick: (e) => e.stopPropagation() },
    ...[["next", "השתקת הצלצול הבא בלבד"], ["today", "השתקה עד סוף היום"], ["forever", "השתקה עד שאחזיר"], ["off", "🔔 ביטול השתקה"]]
      .map(([mode, t]) => h("button", { onclick: () => { muteOpen = false; act(() => POST("/api/mute", { mode }), "עודכן"); } }, t))) : "");

  const items = S.today.items;
  const done = items.filter((i) => i.state === "past").length;
  $("#h-count2").textContent = items.length ? `${done} מתוך ${items.length} צלצלו` : "";
  $("#h-timeline").replaceChildren(items.length
    ? h("div", { class: "timeline" }, items.map((i) => h("div", { class: "chip " + i.state }, h("span", { class: "ltr" }, i.time),
        h("small", {}, i.state === "next" ? "הבא" : i.state === "past" ? "✓ צלצל" : ""))))
    : h("div", { class: "empty" }, "היום אין צלצולים (" + (S.today_name || S.today.reason_he) + ")"));

  for (const k of ["bell", "music"]) {
    if (!dragging) { $("#v-" + k).value = S.volumes[k]; $("#v-out-" + k).textContent = S.volumes[k] + "%"; }
  }
  $("#h-status").replaceChildren(
    h("div", {}, h("span", {}, S.ringtone_mode === "random" ? "הצלצול הבא (אקראי)" : "צלצול"), h("span", {}, S.ringtone)),
    h("div", {}, h("span", {}, "מתנגן כעת"), h("span", {}, S.playing ? S.playing.title + (S.playlist.queue.length ? ` (+${S.playlist.queue.length} בתור)` : "") : "—")),
    h("div", {}, h("span", {}, "רמקולים"), h("span", {}, S.audio_ok ? "תקין ✓" : "⚠️ לא זמין")));
}
function tickClock(now) {
  const c = $("#h-clock");
  if (!c) return;
  c.textContent = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  const cd = $("#h-count");
  if (S && S.next) {
    let sec = Math.max(0, Math.round((parseLocal(S.next.at).getTime() - now.getTime()) / 1000));
    const hh = Math.floor(sec / 3600), mm = Math.floor((sec % 3600) / 60), ss = sec % 60;
    cd.textContent = hh >= 24 ? `${Math.floor(hh / 24)} ימים` : hh ? `${hh}:${pad(mm)}:${pad(ss)}` : `${pad(mm)}:${pad(ss)}`;
  } else cd.textContent = "—";
}

// ---------- SCHEDULES ----------
let selSched = null;
const WD_ORDER = [6, 0, 1, 2, 3, 4, 5];                 // Python weekday numbers, Sunday first
const WD_NAME = ["שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת", "ראשון"];   // by Python weekday
const daysText = (days) => days.map((d) => WD_NAME[d]).join(", ");
async function renderSchedules() {
  const [list, wk] = await Promise.all([GET("/api/schedules"), GET("/api/weekdays")]);
  if (!list.find((s) => s.id === selSched)) selSched = (list.find((s) => s.active) || list[0] || {}).id;
  const s = selSched ? await GET("/api/schedules/" + selSched) : null;
  const m = $("#main");
  const weekCard = h("div", { class: "card", style: "margin-bottom:20px" },
    h("h3", {}, "איזו מערכת מצלצלת בכל יום"),
    h("div", { class: "week" }, WD_ORDER.map((wd) => {
      const cur = wk.map[String(wd)];
      const sel = h("select", { onchange: (e) => act(() => POST("/api/weekdays", { weekday: wd, schedule_id: e.target.value ? +e.target.value : null }), "עודכן").then(renderSchedules) },
        h("option", { value: "", selected: !cur }, "— אין צלצולים —"),
        list.map((x) => h("option", { value: x.id, selected: x.id === cur }, x.name)));
      return h("label", { class: "wd-cell" + (cur ? "" : " off") }, h("b", {}, "יום " + WD_NAME[wd]), sel);
    })),
    h("p", { class: "muted small", style: "margin:10px 0 0" }, "חגים וחופשות מבוטלים אוטומטית לפי לוח החופשות. ליום חריג – לוח השנה."));
  const items = list.map((x) => h("button", { class: "sched-item" + (x.id === selSched ? " sel" : ""), onclick: () => { selSched = x.id; renderSchedules(); } },
    h("span", {}, h("b", {}, x.name), h("div", { class: "muted small" }, x.count + " צלצולים" + (x.days.length ? " · " + daysText(x.days) : ""))),
    x.active ? h("span", { class: "pill" }, x.days.length === 1 ? WD_NAME[x.days[0]] : x.days.length + " ימים") : ""));
  const newBtn = h("button", { class: "btn", onclick: async () => {
    const name = await ask("מערכת חדשה", "שם המערכת (תיווצר ריקה)");
    if (name) { const r = await act(() => POST("/api/schedules", { name }), "נוצרה מערכת"); if (r) { selSched = r.id; renderSchedules(); } }
  } }, icon("plus"), "מערכת חדשה");

  let panel = h("div", { class: "card" }, "אין מערכות");
  if (s) {
    const rows = s.bells.map((b, i) => {
      const t = timeInput(b.time);
      t.addEventListener("change", () => {
        if (!TIME_RE.test(t.value.trim())) { toast("שעה לא תקינה – כתבו למשל 09:15", true); t.value = b.time; return; }
        act(() => POST(`/api/bells/${b.id}/move`, { time: t.value.trim() }), "השעה עודכנה").then(renderSchedules);
      });
      const prev = i ? s.bells[i - 1].time : null;
      const gap = prev ? minutes(b.time) - minutes(prev) : null;
      return h("tr", {},
        h("td", { class: "muted" }, i + 1),
        h("td", {}, t),
        h("td", { class: "muted small" }, gap !== null ? `${gap} דק' אחרי הקודם` : "ראשון ביום"),
        h("td", { style: "text-align:end" }, h("button", { class: "btn icon ghost danger", title: "מחיקה",
          onclick: () => act(() => POST(`/api/bells/${b.id}/delete`), `${b.time} נמחק`).then(renderSchedules) }, icon("trash"))));
    });
    const multi = h("input", { type: "text", placeholder: "שעה חדשה, למשל 08:15 (אפשר כמה: 08:00 08:45)", style: "flex:1;min-width:260px" });
    const add = async () => {
      const times = multi.value.trim();
      if (!times) return toast("בחרו שעה להוספה", true);
      const r = await act(() => POST(`/api/schedules/${s.id}/bells`, { times }));
      if (r) { toast(r.added.length ? "נוספו: " + r.added.join(", ") : "השעות כבר קיימות"); renderSchedules(); }
    };
    multi.addEventListener("keydown", (e) => e.key === "Enter" && add());
    panel = h("div", { class: "card" },
      h("div", { class: "row", style: "margin-bottom:14px" },
        h("h3", { style: "margin:0;font-size:1.35rem" }, s.name),
        s.days.length ? h("span", { class: "pill" }, "מצלצלת ב: " + daysText(s.days)) : h("span", { class: "pill gray" }, "לא משויכת לימים"),
        h("span", { class: "spacer" }),
        h("button", { class: "btn", onclick: async () => {
          const name = await ask("שכפול מערכת", `שם לעותק של "${s.name}"`, s.name + " – עותק");
          if (name) { const r = await act(() => POST("/api/schedules", { name, copy_from: s.id }), "המערכת שוכפלה"); if (r) { selSched = r.id; renderSchedules(); } }
        } }, icon("copy"), "שכפול"),
        h("button", { class: "btn", onclick: async () => {
          const name = await ask("שינוי שם", "שם חדש", s.name);
          if (name) act(() => POST(`/api/schedules/${s.id}/rename`, { name }), "השם עודכן").then(renderSchedules);
        } }, icon("edit"), "שינוי שם"),
        h("button", { class: "btn danger", disabled: s.days.length > 0, title: s.days.length ? "משויכת לימים – קודם שנו את השיוך" : "מחיקה",
          onclick: () => act(() => POST(`/api/schedules/${s.id}/delete`), "המערכת נמחקה").then(renderSchedules) }, icon("trash"), "מחיקה")),
      s.bells.length
        ? h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "#"), h("th", {}, "שעה (לחצו לשינוי)"), h("th", {}, "מרווח"), h("th", {}))), h("tbody", {}, rows))
        : h("div", { class: "empty" }, "אין עדיין שעות במערכת הזו. הוסיפו למטה."),
      h("div", { class: "add-row" }, multi, h("button", { class: "btn primary", onclick: add }, icon("plus"), "הוספה")));
  }
  m.replaceChildren(
    h("h1", { class: "page-title" }, "מערכות שעות"),
    h("p", { class: "page-sub" }, "לכל יום בשבוע משויכת מערכת. בחרו מערכת כדי לערוך את השעות שלה."),
    weekCard,
    h("div", { class: "sched-layout" }, h("div", { class: "sched-list" }, items, newBtn), panel));
}
const TIME_RE = /^\d{1,2}[:.]\d{2}$/;
const timeInput = (v) => h("input", { type: "text", value: v, class: "time-in", maxlength: 5, inputmode: "numeric", dir: "ltr", "aria-label": "שעה" });
const minutes = (t) => { const [a, b] = t.split(":").map(Number); return a * 60 + b; };

// ---------- CALENDAR ----------
let calMonth = null, lastImport = null;
function dayLabel(d) {
  if (d.reason === "auto_holiday") return "🏖 " + d.name;
  if (d.reason === "holiday") return "🏖 " + (d.name || "חופש") + (d.source === "gsheet" ? " ☁" : d.source === "import" ? " ⇩" : "");
  if (d.reason === "override") return "★ " + d.schedule_name;
  if (d.reason === "school_day") return "✎ " + (d.schedule_name || "") ;
  return d.schedule_name || "";
}
async function renderCalendar() {
  if (!calMonth) { const d = S ? parseLocal(S.now) : new Date(); calMonth = [d.getFullYear(), d.getMonth() + 1]; }
  const [y, mo] = calMonth;
  const [data, vac] = await Promise.all([GET(`/api/calendar?month=${y}-${pad(mo)}`), GET("/api/vacations?days=400")]);
  const shift = (n) => { let yy = y, mm = mo + n; if (mm < 1) { mm = 12; yy--; } if (mm > 12) { mm = 1; yy++; } calMonth = [yy, mm]; renderCalendar(); };
  const lead = (data.days[0].weekday + 1) % 7;  // Sunday-first
  const cells = [...WD.map((w) => h("div", { class: "wd" }, w)), ...Array.from({ length: lead }, () => h("div", {}))];
  for (const d of data.days) {
    cells.push(h("button", { class: `day ${d.reason}${d.date === data.today ? " today" : ""}${d.date < data.today ? " past" : ""}`, title: d.auto_name ? `${d.auto_name} (${d.auto_source === "official" ? "לוח רשמי" : "מחושב מהלוח העברי"})` : "", onclick: () => editDay(d, data.schedules) },
      h("span", { class: "num" }, d.day), h("span", { class: "lbl" }, dayLabel(d))));
  }
  const prog = h("div", {});
  const drop = dropZone("ייבוא לוח חופשות מקובץ", "גררו קובץ CSV / Excel / ICS עם תאריכי חופשה. הימים מסומנים מיד, ואפשר לבטל את הייבוא.", false, async ([f]) => {
    prog.replaceChildren(h("div", { class: "muted" }, "⏳ קורא את הקובץ..."));
    try {
      const r = await fetch("/api/holidays/import", { method: "POST", headers: { "X-Bells": "1", "X-Filename": encodeURIComponent(f.name), "Content-Type": "application/octet-stream" }, body: f });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "הייבוא נכשל");
      lastImport = j;
    } catch (e) { toast(e.message, true); }
    renderCalendar();
  }, ".csv,.xlsx,.ics,text/csv,text/calendar");
  const imported = lastImport ? h("div", { class: "card result" },
    h("div", { class: "row" }, h("b", {}, `✓ יובאו ${lastImport.count} ימי חופש (${fmtDate(lastImport.from)} – ${fmtDate(lastImport.to)})`), h("span", { class: "spacer" }),
      h("button", { class: "btn", onclick: () => act(() => POST("/api/holidays/import/undo", { tag: lastImport.tag }), "הייבוא בוטל").then(() => { lastImport = null; renderCalendar(); }) }, icon("undo"), "ביטול הייבוא"),
      h("button", { class: "btn ghost", onclick: () => { lastImport = null; renderCalendar(); } }, "סגירה")),
    h("div", { class: "muted small", style: "margin-top:8px" }, lastImport.items.slice(0, 30).map((i) => `${fmtDate(i.date)} ${i.name}`).join(" · "))) : "";
  const gs = vac.gsheet;
  const gUrl = h("input", { type: "text", value: gs.url, placeholder: "קישור 'פרסום לאינטרנט' של גיליון גוגל בפורמט CSV (לא חובה)", dir: "ltr", style: "flex:1;min-width:260px" });
  const upcoming = vac.upcoming.slice(0, 12).map((v) => h("li", {}, h("b", {}, v.name), ` · ${fmtDate(v.from)}` + (v.to !== v.from ? ` – ${fmtDate(v.to)}` : "")));
  $("#main").replaceChildren(
    h("h1", { class: "page-title" }, "לוח שנה"),
    h("p", { class: "page-sub" }, "חגים וחופשות מסומנים אוטומטית (לוח משרד החינוך / חישוב מהלוח העברי) – בלי צלצולים. לחיצה על יום מאפשרת לשנות אותו."),
    h("div", { class: "card" },
      h("div", { class: "cal-head" },
        h("button", { class: "btn icon", title: "החודש הקודם", onclick: () => shift(-1) }, icon("chev-r")),
        h("div", { class: "cal-title" }, `${MONTHS[mo - 1]} ${y}`),
        h("button", { class: "btn icon", title: "החודש הבא", onclick: () => shift(1) }, icon("chev-l")),
        h("span", { class: "spacer" }),
        h("button", { class: "btn", onclick: () => { calMonth = null; renderCalendar(); } }, "היום")),
      h("div", { class: "cal" }, cells),
      h("div", { class: "legend" },
        h("span", {}, h("i", { style: "background:#fff" }), "יום לימודים"),
        h("span", {}, h("i", { style: "background:var(--auto)" }), "חג / חופשה (אוטומטי)"),
        h("span", {}, h("i", { style: "background:var(--holiday)" }), "חופש שהוספתם"),
        h("span", {}, h("i", { style: "background:var(--special)" }), "מערכת מיוחדת"),
        h("span", {}, h("i", { style: "background:var(--off)" }), "אין לימודים (שישי/שבת)"))),
    h("div", { class: "settings-grid", style: "margin-top:20px" },
      h("div", { class: "card" }, h("h3", {}, "החופשות הקרובות"), upcoming.length ? h("ul", { class: "changes" }, upcoming) : h("div", { class: "empty" }, "אין")),
      h("div", { class: "grid" }, drop, prog, imported,
        h("div", { class: "card" }, h("h3", {}, "גיליון גוגל (לא חובה)"),
          h("div", { class: "row" }, gUrl, h("button", { class: "btn primary", onclick: () => act(() => POST("/api/settings/gsheet", { url: gUrl.value }), "נשמר").then(renderCalendar) }, "שמירה")),
          h("p", { class: "muted small", style: "margin:8px 0 0" }, gs.status || "נמשך פעם ביום כשיש אינטרנט. שורות שכתוב בהן \"חופש\" מסומנות. בלי אינטרנט – משתמשים בעותק האחרון."),
          gs.url ? h("button", { class: "btn small ghost", onclick: () => act(() => POST("/api/settings/gsheet/sync"), "עודכן").then(renderCalendar) }, "עדכן עכשיו") : ""))));
}
async function editDay(d, schedules) {
  const cur = d.reason === "holiday" ? "holiday" : d.reason === "override" ? "schedule" : d.reason === "school_day" ? "school" : "auto";
  const radio = (val, text) => h("label", { class: "opt" }, h("input", { type: "radio", name: "dm", value: val, checked: cur === val }), text);
  const sel = h("select", { style: "flex:1" }, schedules.map((s) => h("option", { value: s.id, selected: s.id === d.schedule_id }, s.name)));
  const ndays = h("input", { type: "number", min: 1, max: 60, value: 1, style: "width:80px", dir: "ltr" });
  const autoText = d.auto_name ? `ברירת מחדל: ${d.auto_name} – בלי צלצולים` : "ברירת מחדל – לפי היום בשבוע";
  const body = h("div", { class: "grid", style: "gap:10px" },
    radio("auto", autoText),
    d.auto_name ? radio("school", "✎ יום לימודים (לבטל את החופש ביום הזה)") : "",
    radio("holiday", "🏖 יום חופש – בלי צלצולים"),
    h("label", { class: "opt" }, h("input", { type: "radio", name: "dm", value: "schedule", checked: cur === "schedule" }), "מערכת מיוחדת:", sel),
    h("label", { class: "row small muted" }, "להחיל על", ndays, "ימים ברצף"));
  sel.addEventListener("change", () => body.querySelector("input[value=schedule]").checked = true);
  const [yy, mm, dd] = d.date.split("-").map(Number);
  const res = await modal(`יום ${DAYS[(d.weekday + 1) % 7]}, ${dd}/${mm}/${yy}`, body,
    [{ text: "שמירה", cls: "primary", value: () => ({ mode: body.querySelector("input[name=dm]:checked").value, sid: +sel.value, n: Math.max(1, Math.min(60, +ndays.value || 1)) }) }, { text: "ביטול", ret: null }]);
  if (!res) return;
  const dates = [d.date];
  const c = new Date(yy, mm - 1, dd);
  for (let i = 1; i < res.n; i++) { c.setDate(c.getDate() + 1); dates.push(`${c.getFullYear()}-${pad(c.getMonth() + 1)}-${pad(c.getDate())}`); }
  await act(async () => { for (const date of dates) await POST("/api/calendar/day", { date, mode: res.mode, schedule_id: res.sid }); },
    dates.length > 1 ? `עודכנו ${dates.length} ימים` : "היום עודכן");
  renderCalendar();
}

// ---------- shared: upload + trim editor ----------
let editor = null;   // {u: {id,name,duration}, peaks, start, end, mode: 'ringtone'|'song'}
const fmtS = (x, whole) => { x = Math.max(0, +x || 0); if (whole) x = Math.round(x); const m = Math.floor(x / 60), s = x - m * 60; return `${m}:${s < 10 ? "0" : ""}${whole ? s : s.toFixed(1)}`; };

function dropZone(title, sub, multiple, onFiles, accept) {
  const fileInp = h("input", { type: "file", multiple: multiple || null, accept: accept || "audio/*,.mp3,.wav,.m4a,.ogg,.aac,.flac,.opus", hidden: true,
    onchange: () => { if (fileInp.files.length) onFiles([...fileInp.files]); } });
  const drop = h("div", { class: "drop", onclick: () => fileInp.click() }, icon("upload"), h("div", { class: "big-t" }, title), h("div", { class: "muted" }, sub), fileInp);
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("over"); const fs = [...e.dataTransfer.files]; if (fs.length) onFiles(multiple ? fs : fs.slice(0, 1)); });
  return drop;
}
async function stageFiles(files, progressEl, library = true) {
  const out = [];
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    if (f.size > 60 * 1024 * 1024) { toast(`"${f.name}" גדול מדי (עד 60MB)`, true); continue; }
    progressEl.replaceChildren(h("div", { class: "card" }, files.length > 1 ? `⏳ מעלה ${i + 1} מתוך ${files.length}: ${f.name}` : `⏳ מעלה ומעבד: ${f.name}`));
    try {
      const r = await fetch("/api/uploads", { method: "POST", headers: { "X-Bells": "1", "X-Library": library ? "1" : "0", "X-Filename": encodeURIComponent(f.name), "Content-Type": "application/octet-stream" }, body: f });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "העלאה נכשלה");
      out.push(j);
    } catch (e) { toast(`${f.name}: ${e.message}`, true); }
  }
  progressEl.replaceChildren();
  return out;
}
async function openEditor(uploadId, mode, start, end) {
  const d = await GET(`/api/uploads/${uploadId}/peaks`);
  // start from the segment saved with the song (if any)
  editor = { u: d, peaks: d.peaks, mode, start: start ?? d.trim_start ?? 0, end: end ?? d.trim_end ?? d.duration };
  if (page === "ringtones") renderRingtones(); else if (page === "songs") renderSongs(); else location.hash = mode === "ringtone" ? "#ringtones" : "#songs";
}
function trimEditor() {
  const e = editor, dur = e.u.duration || 0;
  const canvas = h("canvas", { class: "wave", height: 96 });
  const rs = h("input", { type: "range", min: 0, max: dur, step: 0.1, value: e.start, class: "handle", "aria-label": "התחלה" });
  const re = h("input", { type: "range", min: 0, max: dur, step: 0.1, value: e.end, class: "handle", "aria-label": "סוף" });
  const ns = h("input", { type: "number", min: 0, max: dur, step: 0.1, value: e.start.toFixed(1), class: "sec-in" });
  const ne = h("input", { type: "number", min: 0, max: dur, step: 0.1, value: e.end.toFixed(1), class: "sec-in" });
  const info = h("div", { class: "trim-info" });
  const audio = h("audio", { src: `/media/upload/${e.u.id}`, preload: "auto" });
  const listenBtn = h("button", { class: "btn" }, icon("play"), "האזנה לקטע");
  const draw = () => {
    const w = canvas.clientWidth || 600; canvas.width = w * (window.devicePixelRatio || 1); canvas.style.height = "96px";
    const ctx = canvas.getContext("2d"), W = canvas.width, H = canvas.height, n = e.peaks.length || 1;
    ctx.clearRect(0, 0, W, H);
    const x0 = dur ? (e.start / dur) * W : 0, x1 = dur ? (e.end / dur) * W : W;
    ctx.fillStyle = "rgba(31,95,139,.10)"; ctx.fillRect(x0, 0, x1 - x0, H);
    const bw = W / n;
    const xu = x1;
    e.peaks.forEach((p, i) => {
      const x = i * bw;
      ctx.fillStyle = x >= x0 && x <= xu ? "#1f5f8b" : x >= x0 && x <= x1 ? "#8fb3cf" : "#c3ccd6";
      const bh = Math.max(2, p * (H - 10)); ctx.fillRect(x + bw * .15, (H - bh) / 2, Math.max(1, bw * .7), bh);
    });
    ctx.fillStyle = "#f2a900"; ctx.fillRect(x0 - 2, 0, 4, H); ctx.fillRect(x1 - 2, 0, 4, H);
  };
  const sync = (from) => {
    let a = +(from === "num" ? ns.value : rs.value), b = +(from === "num" ? ne.value : re.value);
    a = Math.max(0, Math.min(a, dur)); b = Math.max(0, Math.min(b, dur));
    if (b - a < 0.5) {
      // dragging one handle past the other moves the whole window (keeps the segment length)
      const keep = Math.max(0.5, e.end - e.start);
      const movingEnd = document.activeElement === re || document.activeElement === ne;
      if (movingEnd) { a = Math.max(0, b - keep); if (b - a < 0.5) b = Math.min(dur, a + 0.5); }
      else { b = Math.min(dur, a + keep); if (b - a < 0.5) a = Math.max(0, b - 0.5); }
    }
    e.start = a; e.end = b;
    rs.value = a; re.value = b; ns.value = a.toFixed(1); ne.value = b.toFixed(1);
    const len = b - a;
    info.replaceChildren(h("span", {}, "קטע: ", h("b", { class: "ltr" }, `${fmtS(a)} – ${fmtS(b)}`), `  ·  אורך ${len.toFixed(1)} שנ'`));
    draw();
  };
  rs.addEventListener("input", () => sync("range")); re.addEventListener("input", () => sync("range"));
  ns.addEventListener("change", () => sync("num")); ne.addEventListener("change", () => sync("num"));
  const stopListen = () => { audio.pause(); listenBtn.replaceChildren(icon("play"), "האזנה לקטע"); };
  listenBtn.addEventListener("click", () => {
    if (!audio.paused) return stopListen();
    audio.currentTime = e.start; audio.play().catch(() => toast("לא ניתן לנגן בחלון", true));
    listenBtn.replaceChildren(icon("stop"), "עצירת האזנה");
  });
  audio.addEventListener("timeupdate", () => { if (audio.currentTime >= e.end) stopListen(); });
  audio.addEventListener("ended", stopListen);
  const full = e.start <= 0.05 && e.end >= dur - 0.05;
  const range = () => (e.start <= 0.05 && e.end >= dur - 0.05) ? {} : { start: +e.start.toFixed(2), end: +e.end.toFixed(2) };
  const close = () => { stopListen(); editor = null; page === "ringtones" ? renderRingtones() : renderSongs(); };
  const saveRt = h("button", { class: "btn " + (e.mode === "ringtone" ? "primary" : ""), onclick: async () => {
    const r = await act(() => POST(`/api/uploads/${e.u.id}/ringtone`, range()));
    if (r) { toast(`✓ "${r.name}" הוא הצלצול הקבוע (${(+r.duration).toFixed(1)} שנ')`); close(); }
  } }, icon("bell"), "שמור כצלצול קבוע");
  const playNow = h("button", { class: "btn " + (e.mode === "song" ? "primary" : ""), onclick: async () => {
    stopListen();
    const r = await act(() => POST(`/api/uploads/${e.u.id}/play`, range()), "▶️ מתנגן ברמקולים");
    if (r) { editor = null; location.hash = "#songs"; if (page === "songs") renderSongs(); }
  } }, icon("speaker"), "נגן עכשיו כשיר");
  const saveTrim = h("button", { class: "btn", onclick: async () => {
    const r = await act(() => POST(`/api/songs/${e.u.id}/trim`, { start: +e.start.toFixed(2), end: +e.end.toFixed(2) }), "החיתוך נשמר עם השיר");
    if (r) close();
  } }, "💾 שמור חיתוך בספרייה");
  const el = h("div", { class: "card result editor" },
    h("div", { class: "row", style: "margin-bottom:10px" }, h("h3", { style: "margin:0" }, "✂️ חיתוך: " + e.u.name), h("span", { class: "muted small" }, `אורך הקובץ ${fmtS(dur, true)}`), h("span", { class: "spacer" }),
      h("button", { class: "btn ghost", onclick: close }, "סגירה")),
    h("p", { class: "muted small", style: "margin:0 0 10px" }, "גררו את שתי הידיות (או כתבו שניות) כדי לבחור את הקטע. אפשר להשאיר את כל הקובץ."),
    h("div", { class: "trim", dir: "ltr" }, canvas, rs, re),
    h("div", { class: "row trim-fields" },
      h("label", { class: "row" }, "מ-שנייה", ns), h("label", { class: "row" }, "עד שנייה", ne),
      h("button", { class: "btn ghost small", onclick: () => { ns.value = 0; ne.value = dur; sync("num"); } }, "כל הקובץ")),
    info,
    h("div", { class: "row", style: "margin-top:14px" }, listenBtn, e.mode === "ringtone" ? [saveRt, playNow] : [playNow, saveTrim, saveRt]), audio);
  requestAnimationFrame(() => sync("range"));
  window.addEventListener("resize", draw);
  return el;
}

// ---------- RINGTONES ----------
async function renderRingtones() {
  const data = await GET("/api/ringtones");
  const prog = h("div", { id: "rt-progress" });
  const drop = dropZone("גררו לכאן קובץ שמע להחלפת הצלצול", "או לחצו לבחירה (mp3, wav, m4a...). הצלצול מתנגן באורך המלא; אפשר לחתוך קטע ולהאזין לפני השמירה.", false,
    async (files) => { const [u] = await stageFiles(files, prog, false); if (u) openEditor(u.id, "ringtone"); });
  const active = data.items.find((r) => r.active);
  const random = data.mode === "random";
  const rows = data.items.map((r) => h("div", { class: "rt-row" },
    h("label", { class: "rot", title: "בסבב האקראי" }, h("input", { type: "checkbox", checked: r.in_rotation, onchange: (e) => act(() => POST(`/api/ringtones/${r.id}/rotation`, { on: e.target.checked })).then(renderRingtones) }), "בסבב"),
    h("div", { style: "flex:1;min-width:200px" }, h("span", { class: "rt-name" }, r.name), " ", r.active ? h("span", { class: "pill" }, random ? "קבוע" : "פעיל") : "", r.next && random ? h("span", { class: "pill next" }, "הבא בתור") : "",
      h("div", { class: "muted small" }, `${r.duration ? (+r.duration).toFixed(1) + " שנ' · " : ""}${fmtDate(r.created_at.slice(0, 10))} · ${r.created_by || ""}`)),
    h("audio", { controls: true, src: `/media/ringtone/${r.id}`, preload: "none" }),
    h("button", { class: "btn icon", title: "השמעה ברמקולים", onclick: () => act(() => POST(`/api/ringtones/${r.id}/play`), "מושמע ברמקולים") }, icon("speaker")),
    r.active ? "" : h("button", { class: "btn", onclick: () => act(() => POST(`/api/ringtones/${r.id}/activate`), "הצלצול הוחלף").then(renderRingtones) }, "קבע כצלצול"),
    h("button", { class: "btn icon", title: "שינוי שם", onclick: async () => { const n = await ask("שינוי שם צלצול", "שם חדש", r.name); if (n) act(() => POST(`/api/ringtones/${r.id}/rename`, { name: n }), "עודכן").then(renderRingtones); } }, icon("edit")),
    r.active ? "" : h("button", { class: "btn icon danger", title: "מחיקה", onclick: () => act(() => POST(`/api/ringtones/${r.id}/delete`), "נמחק").then(renderRingtones) }, icon("trash"))));
  const modeBox = h("div", { class: "card" },
    h("div", { class: "row" }, h("h3", { style: "margin:0" }, "איזה צלצול יתנגן"), h("span", { class: "spacer" }),
      h("div", { class: "seg" },
        h("button", { class: random ? "" : "on", onclick: () => act(() => POST("/api/ringtones/mode", { mode: "fixed" }), "צלצול קבוע").then(renderRingtones) }, "📌 צלצול קבוע"),
        h("button", { class: random ? "on" : "", onclick: () => act(() => POST("/api/ringtones/mode", { mode: "random" }), "אקראי מהסבב").then(renderRingtones) }, "🔀 אקראי"))),
    h("p", { style: "margin:10px 0 0" }, "הצלצול הבא יתנגן: ", h("b", {}, data.upcoming),
      random ? h("span", { class: "muted small" }, ` · בכל צלצול נבחר באקראי צלצול מסומן "בסבב" (${data.items.filter((r) => r.in_rotation).length}), בלי לחזור על אותו צלצול פעמיים ברצף`) : ""));
  $("#main").replaceChildren(
    h("h1", { class: "page-title" }, "צלצולים"),
    h("p", { class: "page-sub" }, random ? "מצב אקראי מהסבב" : ["הצלצול הקבוע: ", h("b", {}, active ? active.name : "ברירת מחדל")]),
    h("div", { class: "grid" }, modeBox, editor ? trimEditor() : drop, prog,
      h("div", { class: "card" },
        h("div", { class: "row", style: "margin-bottom:6px" }, h("h3", { style: "margin:0" }, "ספריית צלצולים"), h("span", { class: "spacer" }),
          h("button", { class: "btn", disabled: !data.has_previous, onclick: () => act(() => POST("/api/ringtones/revert")).then((r) => { if (r) toast("חזרנו ל: " + r.name); renderRingtones(); }) }, icon("undo"), "חזרה לצלצול הקודם")),
        rows)));
}

// ---------- SONGS / PLAYLIST ----------
let songQuery = "", songSel = new Set();
async function renderSongs() {
  const songs = await GET("/api/songs?q=" + encodeURIComponent(songQuery));
  const prog = h("div", {});
  const drop = dropZone("גררו לכאן שיר אחד או כמה שירים", "כל שיר נשמר בספרייה. כמה קבצים יחד = פלייליסט שמתנגן מיד. קובץ אחד = אפשר לחתוך ואז לנגן או לשמור כצלצול.", true,
    async (files) => {
      const ups = await stageFiles(files, prog);
      if (ups.length > 1) { await act(() => POST("/api/playlist", { ids: ups.map((u) => u.id) }), `▶️ פלייליסט של ${ups.length} שירים מתנגן`); renderSongs(); }
      else if (ups.length === 1) openEditor(ups[0].id, "song");
    });
  songSel = new Set([...songSel].filter((id) => songs.some((x) => x.id === id)));
  const selIds = () => songs.filter((x) => songSel.has(x.id)).map((x) => x.id);   // library order
  const search = h("input", { type: "text", class: "search", placeholder: "חיפוש שיר...", value: songQuery,
    oninput: (ev) => { songQuery = ev.target.value; clearTimeout(search._t); search._t = setTimeout(renderSongs, 300); } });
  const n = songSel.size;
  const toolbar = h("div", { class: "row", style: "margin-bottom:10px" },
    h("h3", { style: "margin:0" }, `ספריית שירים (${songs.length})`), search, h("span", { class: "spacer" }),
    h("button", { class: "btn", disabled: !songs.length, onclick: () => act(() => POST("/api/songs/play", {}), "▶️ מנגן את כל הספרייה").then(renderSongs) }, icon("play"), "נגן הכול"),
    h("button", { class: "btn", disabled: !songs.length, onclick: () => act(() => POST("/api/songs/play", { shuffle: true }), "🔀 ערבוב").then(renderSongs) }, "🔀 ערבוב"),
    h("button", { class: "btn primary", disabled: !n, onclick: () => act(() => POST("/api/songs/play", { ids: selIds() }), `▶️ ${n} שירים`).then(() => { songSel.clear(); renderSongs(); }) }, `▶ נגן נבחרים${n ? ` (${n})` : ""}`),
    h("button", { class: "btn", disabled: !n, onclick: () => act(() => POST("/api/songs/enqueue", { ids: selIds() }), "נוסף לתור").then(() => { songSel.clear(); renderSongs(); }) }, `➕ לתור${n ? ` (${n})` : ""}`));
  const list = songs.map((u) => h("div", { class: "rt-row" },
    h("input", { type: "checkbox", class: "admin-cb", checked: songSel.has(u.id), title: "בחירה לפלייליסט",
      onchange: (ev) => { ev.target.checked ? songSel.add(u.id) : songSel.delete(u.id); renderSongs(); } }),
    h("div", { style: "flex:1;min-width:200px" }, h("span", { class: "rt-name" }, u.name),
      h("div", { class: "muted small" }, u.trim_end != null
        ? ["✂️ ", h("span", { class: "ltr" }, `${fmtS(u.trim_start || 0, true)}–${fmtS(u.trim_end, true)}`), ` (${fmtS(u.length, true)} מתוך ${fmtS(u.duration, true)})`]
        : fmtS(u.duration, true), ` · ${fmtDate(u.created_at.slice(0, 10))} · ${u.created_by || ""}`)),
    h("button", { class: "btn", onclick: () => act(() => POST("/api/songs/play", { ids: [u.id] }), "▶️ מתנגן").then(() => updatePlaylistPanel(true)) }, icon("play"), "נגן"),
    h("button", { class: "btn icon", title: "הוספה לתור", onclick: () => act(() => POST("/api/songs/enqueue", { ids: [u.id] }), "נוסף לתור").then(() => updatePlaylistPanel(true)) }, icon("plus")),
    h("button", { class: "btn icon", title: "חיתוך", onclick: () => openEditor(u.id, "song") }, "✂️"),
    h("button", { class: "btn icon", title: "הפוך לצלצול", onclick: () => openEditor(u.id, "ringtone") }, icon("bell")),
    h("button", { class: "btn icon", title: "שינוי שם", onclick: async () => { const nm = await ask("שינוי שם שיר", "שם חדש", u.name); if (nm) act(() => POST(`/api/songs/${u.id}/rename`, { name: nm }), "עודכן").then(renderSongs); } }, icon("edit")),
    h("button", { class: "btn icon danger", title: "מחיקה מהספרייה", onclick: () => act(() => POST(`/api/songs/${u.id}/delete`), "נמחק").then(renderSongs) }, icon("trash"))));
  $("#main").replaceChildren(
    h("h1", { class: "page-title" }, "שירים"),
    h("p", { class: "page-sub" }, "כל שיר שמעלים נשמר בספרייה (עם החיתוך שנבחר). כשמגיע זמן צלצול – הכול נעצר והצלצול יוצא."),
    h("div", { class: "grid" },
      h("div", { class: "card", id: "pl-panel" }),
      editor ? trimEditor() : drop, prog,
      h("div", { class: "card" }, toolbar, list.length ? list : h("div", { class: "empty" }, songQuery ? "לא נמצאו שירים" : "הספרייה ריקה – גררו לכאן שירים"))));
  if (songQuery) { search.focus(); search.setSelectionRange(songQuery.length, songQuery.length); }
  updatePlaylistPanel();
}
let plSig = "";
function updatePlaylistPanel(force) {
  const box = $("#pl-panel");
  if (!box || !S) return;
  const pl = S.playlist || {}, cur = pl.current, q = pl.queue || [];
  const playing = S.playing && S.playing.kind !== "announcement" ? S.playing : null;
  const sig = JSON.stringify([cur && cur.key, q.map((t) => t.key), !!playing]);
  if (sig === plSig && !force && box.childElementCount) return;
  plSig = sig;
  if (!cur && !playing) { box.replaceChildren(h("h3", {}, "מתנגן כעת"), h("div", { class: "empty" }, "שום דבר לא מתנגן")); return; }
  const toRt = (t) => t.upload_id ? h("button", { class: "btn icon", title: "הפוך לצלצול", onclick: () => openEditor(t.upload_id, "ringtone") }, icon("bell")) : "";
  box.replaceChildren(
    h("div", { class: "row" }, h("h3", { style: "margin:0" }, "מתנגן כעת"), h("span", { class: "spacer" }),
      h("button", { class: "btn", disabled: !cur, onclick: () => act(() => POST("/api/playlist/next"), "⏭ הבא").then(() => updatePlaylistPanel(true)) }, "⏭ הבא"),
      h("button", { class: "btn danger solid", onclick: () => act(() => POST("/api/stop"), "ההשמעה נעצרה").then(() => updatePlaylistPanel(true)) }, icon("stop"), "עצור הכול")),
    h("div", { class: "now" }, h("span", { class: "eq" }, h("i"), h("i"), h("i")), h("b", {}, cur ? cur.title : playing.title), cur ? toRt(cur) : ""),
    q.length ? h("div", {}, h("div", { class: "muted small", style: "margin:12px 0 6px" }, `בתור (${q.length}):`),
      h("ol", { class: "queue" }, q.map((t, i) => h("li", {},
        h("span", { style: "flex:1" }, t.title),
        h("button", { class: "btn icon ghost", title: "למעלה", disabled: i === 0, onclick: () => act(() => POST("/api/playlist/move", { key: t.key, delta: -1 })).then(() => updatePlaylistPanel(true)) }, "▲"),
        h("button", { class: "btn icon ghost", title: "למטה", disabled: i === q.length - 1, onclick: () => act(() => POST("/api/playlist/move", { key: t.key, delta: 1 })).then(() => updatePlaylistPanel(true)) }, "▼"),
        toRt(t),
        h("button", { class: "btn icon ghost danger", title: "הסרה מהתור", onclick: () => act(() => POST("/api/playlist/remove", { key: t.key })).then(() => updatePlaylistPanel(true)) }, "✕"))))) : h("div", { class: "muted small", style: "margin-top:10px" }, "אין שירים נוספים בתור"));
}

// ---------- LOG ----------
async function renderLog() {
  const rows = await GET("/api/log?limit=300");
  const q = h("input", { type: "text", class: "search", placeholder: "חיפוש ביומן...", oninput: () => draw() });
  const body = h("tbody");
  const draw = () => {
    const f = q.value.trim();
    body.replaceChildren(...rows.filter((r) => !f || [r.actor_name, r.action_he, r.details].join(" ").includes(f)).map((r) =>
      h("tr", {}, h("td", {}, `${fmtDate(r.ts.slice(0, 10))} ${r.ts.slice(11, 16)}`), h("td", {}, r.actor_name), h("td", {}, h("b", {}, r.action_he)), h("td", { class: "muted" }, r.details || ""))));
  };
  draw();
  $("#main").replaceChildren(
    h("h1", { class: "page-title" }, "יומן פעולות"),
    h("p", { class: "page-sub" }, "מי עשה מה – מהבוט, מהמחשב הזה ומהמערכת עצמה."),
    h("div", { class: "card" }, h("div", { class: "row", style: "margin-bottom:12px" }, q),
      h("table", { class: "log-table" }, h("thead", {}, h("tr", {}, h("th", {}, "זמן"), h("th", {}, "מי"), h("th", {}, "פעולה"), h("th", {}, "פרטים"))), body)));
}

// ---------- SETTINGS ----------
async function renderSettings() {
  const st = await GET("/api/settings");
  const b = st.bot, tk = st.token;
  const statusBox = h("div", { class: "status-box" },
    h("span", { class: "dot " + (b.state === "online" ? "ok" : b.state === "off" ? "" : "warn") }),
    b.state === "online" ? ["הבוט מחובר: ", h("span", { class: "ltr" }, b.username)] : b.state === "off" ? "הבוט לא מוגדר"
      : b.state === "connecting" ? (st.relay.mode === "relay" ? "מתחבר לשרת הפרטי..." : "מתחבר לטלגרם...")
      : h("div", {}, h("b", {}, botError(b).label), h("div", { class: "small", style: "font-weight:400;margin-top:4px" }, botError(b).detail),
          b.detail ? h("pre", { class: "logtail", dir: "ltr", style: "max-height:9em" }, b.detail) : ""));
  let tokenArea;
  if (tk.set) {   // the token itself never comes back from the server
    tokenArea = h("div", { class: "row" },
      h("span", { class: "secret" }, "טוקן שמור ", h("span", { class: "ltr" }, "••••••" + tk.last4), tk.bot ? [" · ", h("span", { class: "ltr" }, tk.bot)] : ""),
      h("span", { class: "spacer" }),
      h("button", { class: "btn danger", onclick: () => act(() => POST("/api/settings/token/delete"), "הטוקן נמחק – הזינו חדש").then(renderSettings) }, icon("trash"), "מחק והזן מחדש"));
  } else {
    const tok = h("input", { type: "password", placeholder: "הדביקו כאן את הטוקן מ-BotFather", style: "flex:1;min-width:240px", autocomplete: "off" });
    tokenArea = h("div", {},
      h("div", { class: "row" }, tok, h("button", { class: "btn primary", onclick: async () => {
        if (!tok.value.trim()) return toast("הדביקו טוקן", true);
        const r = await act(() => POST("/api/settings/token", { token: tok.value }));
        tok.value = "";
        if (r) { toast(r.checked ? "נשמר ✓ " + r.info : "נשמר. " + r.info); setTimeout(renderSettings, 3000); renderSettings(); }
      } }, "שמירה")),
      h("div", { class: "help", style: "margin-top:16px" }, "איך מקבלים טוקן?",
        h("ol", {}, h("li", {}, "בטלגרם מחפשים @BotFather ולוחצים Start"), h("li", {}, "שולחים /newbot ובוחרים שם"), h("li", {}, "מעתיקים את הטוקן שהוא שולח ומדביקים כאן"))));
  }
  // connection: Telegram, or our own server (same bot, another address; phones use a web page with Google sign-in)
  const rl = st.relay, relayMode = rl.mode === "relay";
  const modeRow = h("div", { class: "seg", style: "margin-bottom:12px" },
    [["telegram", "טלגרם"], ["relay", "שרת פרטי"]].map(([m, label]) => h("button", {
      class: rl.mode === m ? "on" : "", onclick: () => {
        if (m === rl.mode) return;
        if (m === "relay" && !rl.url) { relayForm.hidden = false; tokenArea.hidden = true; return; }
        act(() => POST("/api/settings/botmode", { mode: m }), m === "relay" ? "עובר לשרת הפרטי" : "עובר לטלגרם").then(renderSettings);
      } }, label)));
  const rUrl = h("input", { type: "text", placeholder: "https://school-bells-relay.NAME.workers.dev", value: rl.url || "", class: "ltr", style: "direction:ltr;flex:1;min-width:240px", autocomplete: "off" });
  const rKey = h("input", { type: "password", placeholder: "המפתח מדף הניהול של השרת", style: "flex:1;min-width:240px", autocomplete: "off" });
  const saveRelay = async () => {
    const r = await act(() => POST("/api/settings/relay", { url: rUrl.value, key: rKey.value }));
    rKey.value = "";
    if (r) { toast(r.checked ? "נשמר ✓ " + r.info : "נשמר" + (r.info ? ". " + r.info : " ✓")); renderSettings(); setTimeout(renderSettings, 3000); }
  };
  const relayForm = h("div", { hidden: !relayMode },
    h("div", { class: "row", style: "margin-bottom:8px" }, h("span", { class: "small", style: "min-width:70px" }, "כתובת"), rUrl),
    rl.key_set
      ? h("div", { class: "row" }, h("span", { class: "secret" }, "מפתח שמור ", h("span", { class: "ltr" }, "••••••" + rl.last4)), h("span", { class: "spacer" }),
          h("button", { class: "btn", onclick: saveRelay }, "שמירת כתובת"),
          h("button", { class: "btn danger", onclick: () => act(() => POST("/api/settings/relay/delete"), "המפתח נמחק – הזינו חדש").then(renderSettings) }, icon("trash"), "מחק והזן מחדש"))
      : h("div", { class: "row" }, h("span", { class: "small", style: "min-width:70px" }, "מפתח"), rKey, h("button", { class: "btn primary", onclick: saveRelay }, "שמירה")),
    rl.phone_link ? h("div", { class: "help", style: "margin-top:14px" }, "קישור לטלפונים של הצוות (כניסה עם גוגל, ואז 'בקש גישה'):",
      h("div", { class: "row", style: "margin-top:6px" }, h("code", { class: "ltr", style: "direction:ltr;word-break:break-all;flex:1" }, rl.phone_link),
        h("button", { class: "btn", onclick: () => navigator.clipboard.writeText(rl.phone_link).then(() => toast("הקישור הועתק")) }, "העתק"))) : "");
  tokenArea.hidden = relayMode;
  const name = h("input", { type: "text", placeholder: "שם (למשל: המזכירה)" });
  const cid = h("input", { type: "text", placeholder: "מזהה צ'אט (מספר)", class: "ltr", style: "direction:ltr", autocomplete: "off" });
  const addUser = () => cid.value.trim() ? act(() => POST("/api/settings/users", { chat_id: cid.value.trim(), name: name.value }), "המשתמש נוסף ✓").then(renderSettings) : toast("הכניסו מזהה", true);
  const notify = h("div", { class: "grid", style: "gap:8px" }, Object.entries(st.notify_labels).map(([k, label]) =>
    h("label", { class: "opt" }, h("input", { type: "checkbox", checked: st.notify[k], onchange: (e) => act(() => POST("/api/settings/notify", { key: k, on: e.target.checked }), "נשמר") }), label)));

  $("#main").replaceChildren(
    h("h1", { class: "page-title" }, "הגדרות"),
    h("p", { class: "page-sub" }, "כל שינוי כאן חל מיד – גם בבוט."),
    h("div", { class: "settings-grid" },
      h("div", { class: "card" }, h("h3", {}, "חיבור הבוט"), modeRow, statusBox, tokenArea, relayForm),
      h("div", { class: "card" },
        h("h3", {}, "משתמשים מורשים"),
        st.requests.length ? h("div", {}, h("p", { class: "small", style: "margin:0 0 8px;font-weight:600" }, "ביקשו גישה לבוט:"),
          st.requests.map((r) => h("div", { class: "request" },
            h("div", { style: "flex:1" }, h("b", {}, r.name), h("div", { class: "muted small" }, h("span", { class: "ltr" }, r.masked), " · ", fmtDate(r.ts.slice(0, 10)), " ", r.ts.slice(11, 16))),
            h("button", { class: "btn primary", onclick: () => act(() => POST(`/api/settings/requests/${r.key}/approve`), "המשתמש נוסף ✓").then(renderSettings) }, icon("check"), "אישור")))) : "",
        st.users.length ? h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "שם"), h("th", {}, "מזהה"), h("th", { title: "מנהל יכול גם להתקין עדכוני תוכנה דרך הבוט" }, "מנהל"), h("th", {}))),
          h("tbody", {}, st.users.map((u) => h("tr", {}, h("td", {}, u.name), h("td", { class: "muted" }, h("span", { class: "ltr" }, u.masked)),
            h("td", {}, h("input", { type: "checkbox", class: "admin-cb", checked: u.is_admin, title: "מנהל", onchange: (e) => act(() => POST(`/api/settings/users/${u.key}/admin`, { is_admin: e.target.checked }), e.target.checked ? "הוגדר כמנהל" : "הוסר ממנהלים") })),
            h("td", { style: "text-align:end" }, h("button", { class: "btn icon ghost danger", title: "הסרה", onclick: () => act(() => POST(`/api/settings/users/${u.key}/delete`), "הוסר").then(renderSettings) }, icon("trash")))))))
          : h("div", { class: "empty" }, "אין עדיין משתמשים מורשים"),
        h("div", { class: "add-row" }, name, cid, h("button", { class: "btn primary", onclick: addUser }, icon("plus"), "הוספה")),
        h("div", { class: "help", style: "margin-top:16px" }, "הדרך הקלה: מבקשים מהאדם לשלוח הודעה כלשהי לבוט. הוא יופיע כאן תחת \"ביקשו גישה\" – ולוחצים אישור."))),
    h("div", { class: "settings-grid", style: "margin-top:20px" },
      h("div", { class: "card" }, h("h3", {}, "הודעות בבוט"),
        h("p", { class: "muted small", style: "margin-top:0" }, "המערכת \"שגר ושכח\": הבוט כותב רק כשיש תקלה אמיתית או כשפונים אליו. הודעות שגרה כבויות, ואפשר להפעיל כאן:"),
        notify),
      h("div", { class: "card", id: "update-card" })));
  renderUpdateCard();
}

// ---------- software update ----------
async function renderUpdateCard() {
  const box = $("#update-card");
  if (!box) return;
  const us = await GET("/api/update/status");
  const last = us.last;
  const lastLine = !last ? "" : last.status === "ok" ? h("p", { class: "muted small" }, `עדכון אחרון: ${last.from} ← ${last.to} הצליח (${fmtDate(last.at.slice(0, 10))} ${last.at.slice(11, 16)})`)
    : last.status === "rolled_back" ? h("div", {}, h("p", { class: "warn-t" }, `⚠️ העדכון לגרסה ${last.to} נכשל והמערכת חזרה לגרסה ${last.from}. סיבה: ${last.error || "?"}`),
        last.log_tail ? h("details", {}, h("summary", { class: "small" }, "סוף הלוג של הגרסה שנכשלה"), logBox(last.log_tail)) : "")
    : h("p", { class: "muted small" }, `עדכון לגרסה ${last.to || "?"} לא הוחל: ${last.error || ""}`);
  const prog = h("div", {});
  const drop = dropZone("עדכון תוכנה: גררו לכאן קובץ school-bells-update-….zip", "הקובץ נבדק (חתימה מקורית, גרסה חדשה יותר) ומותקן מיד. אם משהו נכשל – חוזרים לבד לגרסה הקודמת.", false,
    async ([f]) => {
      prog.replaceChildren(h("div", { class: "muted" }, "⏳ בודק ומתקין..."));
      try {
        const r = await fetch("/api/update/install", { method: "POST", headers: { "X-Bells": "1", "Content-Type": "application/zip" }, body: f });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || "העדכון נדחה");
        showUpdating(j);
      } catch (e) { prog.replaceChildren(h("p", { class: "warn-t" }, "העדכון לא הותקן: " + e.message)); }
    }, ".zip,application/zip");
  const src = us.source;
  const url = h("input", { type: "text", value: src.url, dir: "ltr", placeholder: "https://…/manifest.json", style: "flex:1;min-width:220px" });
  const save = () => act(() => POST("/api/update/settings", { url: url.value }), "נשמר").then(renderUpdateCard);
  const auto = h("label", { class: "row small" }, h("input", { type: "checkbox", class: "admin-cb", checked: src.auto, disabled: !src.url,
    onchange: (e) => act(() => POST("/api/update/settings", { auto: e.target.checked }), "נשמר").then(renderUpdateCard) }), `עדכון אוטומטי כל לילה ב-${src.check_at} (רק כשאין לימודים)`);
  const checkNow = h("button", { class: "btn", disabled: !src.url, onclick: async () => {
    const r = await act(() => POST("/api/update/check", { install: true }));
    if (!r) return;
    if (r.status === "installing") showUpdating({ version: r.version, current: us.version }); else { toast(r.message, r.status === "error"); renderUpdateCard(); }
  } }, "🔄 עדכן עכשיו");
  box.replaceChildren(
    h("div", { class: "row", style: "margin-bottom:8px" }, h("h3", { style: "margin:0" }, "עדכון תוכנה"), h("span", { class: "pill gray" }, "גרסה " + us.version), h("span", { class: "spacer" }),
      h("button", { class: "btn ghost small", onclick: () => showChangelog(us.changelog) }, "היסטוריית גרסאות")),
    lastLine,
    h("div", { class: "grid", style: "gap:8px;margin-bottom:14px" },
      h("div", { class: "row" }, url, h("button", { class: "btn primary", onclick: save }, "שמירה")),
      h("div", { class: "row" }, auto, h("span", { class: "spacer" }), checkNow),
      src.last_status ? h("div", { class: "muted small" }, `בדיקה אחרונה ${src.last_check.replace("T", " ")}: ${src.last_status}`) : ""),
    drop, prog);
}
const logBox = (text) => h("pre", { class: "logtail", dir: "ltr" }, text);
function showUpdating(info) {
  const back = $("#modal");
  const msg = h("p", { class: "muted", style: "margin:0" }, "המערכת נעצרת, מגבה את הגרסה הנוכחית, מחליפה קבצים ועולה מחדש. החלון יתחבר מחדש לבד.");
  back.replaceChildren(h("div", { class: "modal" }, h("h3", {}, `⏳ מתקין את גרסה ${info.version}...`), msg, h("div", { class: "spinner" })));
  back.hidden = false; back.onclick = null;
  const started = Date.now();
  const tick = async () => {
    try {
      const r = await fetch("/api/health", { cache: "no-store" });
      const j = await r.json();
      if (j.version === info.version) { location.hash = "#settings"; location.reload(); return; }
      if (Date.now() - started > 20000 && j.version === info.current) {   // came back on the old version = rolled back
        const us = await GET("/api/update/status");
        if (us.last && us.last.status !== "ok" && us.last.at && new Date(us.last.at).getTime() > started - 60000) {
          msg.textContent = `העדכון לא הצליח והמערכת חזרה לגרסה ${info.current}. ${us.last.error || ""}`;
          back.querySelector(".spinner").remove();
          const m = back.querySelector(".modal");
          m.classList.add("wide");
          if (us.last.log_tail) m.append(h("div", { class: "small" }, "סוף הלוג של הגרסה שנכשלה (אפשר לצלם ולשלוח):"), logBox(us.last.log_tail));
          m.append(h("div", { class: "btns" }, h("button", { class: "btn primary", onclick: () => location.reload() }, "סגירה")));
          return;
        }
      }
    } catch (e) { /* restarting */ }
    if (Date.now() - started > 240000) { msg.textContent = "העדכון לוקח יותר מהצפוי. בדקו את התיקייה updates\\logs, או הפעילו מחדש את המחשב."; return; }
    setTimeout(tick, 2000);
  };
  setTimeout(tick, 4000);
}
function showChangelog(cl, onlyVersion) {
  const versions = Object.keys(cl).filter((v) => !onlyVersion || v === onlyVersion);
  return modal(onlyVersion ? `מה חדש בגרסה ${onlyVersion}` : "היסטוריית גרסאות",
    h("div", { class: "changelog" }, versions.map((v) => h("div", {}, onlyVersion ? "" : h("h4", {}, "גרסה " + v), h("ul", { class: "changes" }, cl[v].map((c) => h("li", {}, c)))))),
    [{ text: onlyVersion ? "הבנתי" : "סגירה", cls: "primary", ret: true }]);
}

// ---------- ABOUT ----------
async function renderAbout() {
  const a = await GET("/api/about");
  const row = (k, v) => h("div", {}, h("span", {}, k), h("span", {}, v));
  const idBox = h("span", { class: "device-id ltr" }, a.device_id);
  $("#main").replaceChildren(
    h("h1", { class: "page-title" }, "אודות"),
    h("p", { class: "page-sub" }, a.school),
    h("div", { class: "card", style: "max-width:640px" },
      h("h3", {}, "מזהה מכשיר"),
      h("div", { class: "row" }, idBox, h("button", { class: "btn", onclick: async () => {
        try { await navigator.clipboard.writeText(a.device_id); toast("המזהה הועתק"); }
        catch (e) { const r = document.createRange(); r.selectNodeContents(idBox); getSelection().removeAllRanges(); getSelection().addRange(r); toast("המזהה מסומן – Ctrl+C להעתקה"); }
      } }, icon("copy"), "העתקה")),
      h("p", { class: "muted small" }, "מזהה קבוע של המחשב הזה. ספק המערכת משתמש בו כדי לצרף מחשב לערוץ הבדיקה."),
      h("div", { class: "status-list" },
        row("גרסה", a.version),
        row("ערוץ עדכונים", a.channel === "beta" ? "בדיקה (נקבע ע״י ספק המערכת)" : "יציב"),
        row("מקור עדכונים", a.update_url ? "מוגדר" : "לא מוגדר"),
        row("עדכון אוטומטי", a.auto ? "פעיל" : "כבוי"),
        row("בדיקה אחרונה", a.last_check ? `${a.last_check.replace("T", " ")} – ${a.last_status}` : "—"))));
}

// ---------- router ----------
const PAGES = {
  home: { render: renderHome },
  schedules: { render: renderSchedules, refresh: renderSchedules },
  calendar: { render: renderCalendar, refresh: renderCalendar },
  ringtones: { render: renderRingtones, refresh: () => editor ? Promise.resolve() : renderRingtones() },
  songs: { render: renderSongs, refresh: () => editor ? Promise.resolve() : renderSongs() },
  log: { render: renderLog, refresh: renderLog },
  settings: { render: renderSettings, refresh: renderSettings },
  about: { render: renderAbout },
};
async function go() {
  page = (location.hash || "#home").slice(1);
  if (!PAGES[page]) page = "home";
  document.removeEventListener("click", closeMute);
  if (!$("#modal").hidden) $("#modal").click();
  if (editor && !["ringtones", "songs"].includes(page)) editor = null;
  document.querySelectorAll("audio").forEach((a) => a.pause());  // a click on the backdrop cancels an open dialog
  document.querySelectorAll("#nav a").forEach((a) => a.classList.toggle("active", a.dataset.page === page));
  try { await PAGES[page].render(); } catch (e) { toast(e.message, true); }
}
window.addEventListener("hashchange", go);
document.getElementById("side-stop").addEventListener("click", () => act(() => POST("/api/stop"), "ההשמעה נעצרה"));

// background refresh of non-home pages (changes made from the bot), unless the user is in the middle of editing
setInterval(() => {
  const busy = document.activeElement && ["INPUT", "SELECT", "AUDIO"].includes(document.activeElement.tagName);
  const playing = [...document.querySelectorAll("audio")].some((a) => !a.paused);
  if (page !== "home" && PAGES[page].refresh && !busy && !playing && $("#modal").hidden) PAGES[page].refresh().catch(() => {});
}, 8000);
setInterval(poll, 2000);
setInterval(() => page === "home" && tickClock(new Date(Date.now() + offset)), 250);
poll().then(go).then(() => { booted = true; poll(); });
