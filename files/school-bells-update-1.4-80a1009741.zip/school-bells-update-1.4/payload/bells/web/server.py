"""Local web UI server (127.0.0.1 only). A thin JSON layer over BellService – no business logic here."""
from __future__ import annotations

import json
import logging
import mimetypes
import re
import threading
import urllib.parse
import uuid
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from ..bot.notifier import check_token
from ..core.labels import ACTION_HE
from ..core.redact import redact
from ..core.logic import DAY_NAMES_HE
from ..core.service import REASON_HE, BellService

log = logging.getLogger(__name__)
STATIC = Path(__file__).resolve().parent / "static"
UI_ACTOR = ("ui", "מחשב הצלצולים")
MAX_UPLOAD = 60 * 1024 * 1024
ROUTES: list[tuple[str, re.Pattern, str]] = []


def route(method: str, pattern: str):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn.__name__))
        return fn
    return deco


class Api:
    """Maps HTTP endpoints to BellService calls."""

    def __init__(self, svc: BellService):
        self.svc = svc

    # ---------- dashboard ----------
    @route("GET", "/api/state")
    def state(self, body, q):
        svc = self.svc
        now = svc.now()
        tl = svc.today_timeline()
        plan = tl["plan"]
        nb = svc.next_bell()
        mute = svc.mute_state()
        rt = svc.upcoming_ringtone()
        return {
            "now": now.isoformat(timespec="seconds"),
            "day_name": DAY_NAMES_HE[now.weekday()],
            "school": svc.cfg.school_name,
            "today": {"schedule": svc.schedule_name(plan.schedule_id) if plan.schedule_id else None,
                      "reason": plan.reason, "reason_he": REASON_HE[plan.reason], "items": tl["items"]},
            "next": {"at": nb[0].isoformat(timespec="seconds"), "text": svc.next_bell_text(nb, now),
                     "muted": bool(mute.reason_for(nb[0].date()))} if nb else None,
            "mute": {"text": mute.describe(now.date()), "forever": mute.forever,
                     "today": mute.day == now.date(), "next": mute.next_once},
            "volumes": svc.volumes(),
            "playing": svc.player.now_playing(),
            "playlist": svc.playlist_state(),
            "audio_ok": svc.player.healthy(),
            "ringtone": rt["name"] if rt else "ברירת מחדל",
            "today_name": plan.name,
            "bot": svc.bot_status,
            "version": svc.version,
            "ringtone_mode": svc.ringtone_mode(),
            "requests": len(svc.access_requests()),
        }

    @route("POST", "/api/ring")
    def ring(self, body, q):
        self.svc.ring_now(UI_ACTOR)

    @route("POST", "/api/mute")
    def mute(self, body, q):
        self.svc.set_mute(body.get("mode", ""), UI_ACTOR)

    @route("POST", "/api/stop")
    def stop(self, body, q):
        self.svc.stop_all(UI_ACTOR)

    @route("POST", "/api/volume")
    def volume(self, body, q):
        return self.svc.set_volume(body["kind"], int(body["value"]), UI_ACTOR)

    # ---------- schedules ----------
    @route("GET", "/api/schedules")
    def schedules(self, body, q):
        return self.svc.list_schedules()

    @route("POST", "/api/schedules")
    def schedule_create(self, body, q):
        copy = body.get("copy_from")
        return {"id": self.svc.create_schedule(body.get("name", ""), UI_ACTOR, copy_from=int(copy) if copy else None)}

    @route("GET", r"/api/schedules/(\d+)")
    def schedule_get(self, body, q, sid):
        return self.svc.get_schedule(int(sid))

    @route("POST", r"/api/schedules/(\d+)/rename")
    def schedule_rename(self, body, q, sid):
        self.svc.rename_schedule(int(sid), body.get("name", ""), UI_ACTOR)

    @route("GET", "/api/weekdays")
    def weekdays(self, body, q):
        return {"map": {str(k): v for k, v in self.svc.weekday_map().items()}, "schedules": self.svc.list_schedules()}

    @route("POST", "/api/weekdays")
    def weekday_set(self, body, q):
        self.svc.set_weekday(int(body["weekday"]), body.get("schedule_id") or None, UI_ACTOR)

    @route("POST", r"/api/schedules/(\d+)/delete")
    def schedule_delete(self, body, q, sid):
        self.svc.delete_schedule(int(sid), UI_ACTOR)

    @route("POST", r"/api/schedules/(\d+)/bells")
    def bells_add(self, body, q, sid):
        added, existing = self.svc.add_bells(int(sid), body.get("times", ""), UI_ACTOR)
        return {"added": added, "existing": existing}

    @route("POST", r"/api/bells/(\d+)/move")
    def bell_move(self, body, q, bid):
        self.svc.move_bell(int(bid), body.get("time", ""), UI_ACTOR)

    @route("POST", r"/api/bells/(\d+)/delete")
    def bell_delete(self, body, q, bid):
        self.svc.delete_bell(int(bid), UI_ACTOR)

    # ---------- calendar ----------
    @route("GET", "/api/calendar")
    def calendar(self, body, q):
        y, m = (int(x) for x in q.get("month", [self.svc.now().strftime("%Y-%m")])[0].split("-"))
        return {"days": self.svc.calendar_month(y, m), "today": self.svc.now().date().isoformat(),
                "schedules": self.svc.list_schedules()}

    @route("POST", "/api/calendar/day")
    def calendar_day(self, body, q):
        """body: {date, mode: auto | school | holiday | schedule, schedule_id}"""
        self.svc.set_day_mode(date.fromisoformat(body["date"]), body.get("mode", ""), UI_ACTOR, body.get("schedule_id"))

    @route("GET", "/api/vacations")
    def vacations(self, body, q):
        return {"upcoming": [{**v, "from": v["from"].isoformat(), "to": v["to"].isoformat()}
                             for v in self.svc.upcoming_vacations(int(q.get("days", ["400"])[0]))],
                "gsheet": self.svc.gsheet_settings()}

    @route("POST", "/api/holidays/import/undo")
    def holidays_import_undo(self, body, q):
        return {"removed": self.svc.undo_import(body.get("tag", ""), UI_ACTOR)}

    # ---------- ringtones ----------
    @route("GET", "/api/ringtones")
    def ringtones(self, body, q):
        rows = self.svc.list_ringtones()
        prev = self.svc.db.get_setting(self.svc.sid, "previous_ringtone_id")
        up = self.svc.upcoming_ringtone()
        return {"items": [{k: r[k] for k in ("id", "name", "duration", "created_at", "created_by", "active",
                                             "in_rotation", "next")} for r in rows],
                "has_previous": bool(prev), "mode": self.svc.ringtone_mode(),
                "upcoming": up["name"] if up else "ברירת מחדל"}

    @route("POST", "/api/ringtones/mode")
    def rt_mode(self, body, q):
        self.svc.set_ringtone_mode(body.get("mode", ""), UI_ACTOR)

    @route("POST", r"/api/ringtones/(\d+)/rotation")
    def rt_rotation(self, body, q, rid):
        self.svc.set_rotation(int(rid), bool(body.get("on")), UI_ACTOR)

    @route("POST", r"/api/ringtones/(\d+)/activate")
    def rt_activate(self, body, q, rid):
        self.svc.activate_ringtone(int(rid), UI_ACTOR)

    @route("POST", r"/api/ringtones/(\d+)/play")
    def rt_play(self, body, q, rid):
        self.svc.preview_ringtone(int(rid), UI_ACTOR)

    @route("POST", r"/api/ringtones/(\d+)/delete")
    def rt_delete(self, body, q, rid):
        self.svc.delete_ringtone(int(rid), UI_ACTOR)

    @route("POST", r"/api/ringtones/(\d+)/rename")
    def rt_rename(self, body, q, rid):
        self.svc.rename_ringtone(int(rid), body.get("name", ""), UI_ACTOR)

    @route("POST", "/api/ringtones/revert")
    def rt_revert(self, body, q):
        return {"name": self.svc.revert_ringtone(UI_ACTOR)["name"]}

    # ---------- uploads: trim, play, make ringtone ----------
    @route("GET", "/api/uploads")
    def uploads(self, body, q):
        return self.svc.list_uploads()

    @route("GET", r"/api/uploads/(\d+)/peaks")
    def upload_peaks(self, body, q, uid):
        u = self.svc.get_upload(int(uid))
        return {**self.svc._song_view(u), "peaks": self.svc.upload_peaks(int(uid))}

    # ---------- song library ----------
    @route("GET", "/api/songs")
    def songs(self, body, q):
        return self.svc.list_songs(q.get("q", [""])[0])

    @route("POST", "/api/songs/play")
    def songs_play(self, body, q):
        return self.svc.play_library(UI_ACTOR, [int(i) for i in body.get("ids") or []], bool(body.get("shuffle")))

    @route("POST", "/api/songs/enqueue")
    def songs_enqueue(self, body, q):
        return self.svc.enqueue([int(i) for i in body.get("ids") or []], UI_ACTOR)

    @route("POST", r"/api/songs/(\d+)/rename")
    def song_rename(self, body, q, uid):
        self.svc.rename_song(int(uid), body.get("name", ""), UI_ACTOR)

    @route("POST", r"/api/songs/(\d+)/delete")
    def song_delete(self, body, q, uid):
        self.svc.delete_song(int(uid), UI_ACTOR)

    @route("POST", r"/api/songs/(\d+)/trim")
    def song_trim(self, body, q, uid):
        return self.svc.set_song_trim(int(uid), body.get("start"), body.get("end"), UI_ACTOR)

    @route("POST", r"/api/uploads/(\d+)/play")
    def upload_play(self, body, q, uid):
        return self.svc.play_uploads([int(uid)], UI_ACTOR, body.get("start"), body.get("end"))

    @route("POST", r"/api/uploads/(\d+)/ringtone")
    def upload_ringtone(self, body, q, uid):
        rt = self.svc.ringtone_from_upload(int(uid), UI_ACTOR, body.get("start"), body.get("end"), body.get("name"))
        return {"id": rt["id"], "name": rt["name"], "duration": rt["duration"]}

    # ---------- playlist ----------
    @route("GET", "/api/playlist")
    def playlist(self, body, q):
        return self.svc.playlist_state()

    @route("POST", "/api/playlist")
    def playlist_play(self, body, q):
        return self.svc.play_uploads([int(i) for i in body.get("ids", [])], UI_ACTOR)

    @route("POST", "/api/playlist/next")
    def playlist_next(self, body, q):
        return self.svc.playlist_next(UI_ACTOR)

    @route("POST", "/api/playlist/remove")
    def playlist_remove(self, body, q):
        return self.svc.playlist_remove(int(body["key"]), UI_ACTOR)

    @route("POST", "/api/playlist/move")
    def playlist_move(self, body, q):
        return self.svc.playlist_move(int(body["key"]), int(body["delta"]), UI_ACTOR)

    # ---------- version / update ----------
    @route("GET", "/api/health")
    def health(self, body, q):
        return {"ok": True, "version": self.svc.version}

    @route("GET", "/api/update/status")
    def update_status(self, body, q):
        from ..version import changelog
        return {"version": self.svc.version, "last": self.svc.last_update_result(),
                "changelog": changelog(self.svc.cfg.app_dir), "source": self.svc.update_settings()}

    @route("POST", "/api/update/settings")
    def update_settings(self, body, q):
        if "channel" in body:
            raise ValueError("הערוץ נקבע רק על ידי ספק המערכת")
        return self.svc.set_update_settings(UI_ACTOR, url=body.get("url"), auto=body.get("auto"))

    @route("GET", "/api/about")
    def about(self, body, q):
        return self.svc.about()

    @route("POST", "/api/update/check")
    def update_check(self, body, q):
        return self.svc.check_for_update(UI_ACTOR, install=bool(body.get("install", True)), manual=True)

    @route("POST", "/api/update/apply")
    def update_apply(self, body, q):
        return self.svc.apply_update(body.get("token", ""), UI_ACTOR)


    # ---------- log ----------
    @route("GET", "/api/log")
    def action_log(self, body, q):
        rows = self.svc.recent_log(int(q.get("limit", ["200"])[0]))
        return [{"ts": r["ts"], "actor_name": redact(r["actor_name"] or ""), "action": r["action"],
                 "action_he": ACTION_HE.get(r["action"], r["action"]), "details": redact(r["details"] or "")}
                for r in rows]  # no chat ids, no tokens

    # ---------- settings ----------
    @route("GET", "/api/settings")
    def settings(self, body, q):
        """Never returns the token or full chat ids."""
        svc = self.svc
        return {"token": svc.token_info(), "relay": svc.relay_info(), "bot": svc.bot_status, "users": svc.list_users(),
                "requests": svc.access_requests(), "notify": svc.notify_options(),
                "notify_labels": svc.NOTIFY_OPTIONS, "gsheet": svc.gsheet_settings()}

    @route("POST", "/api/settings/token")
    def settings_token(self, body, q):
        if self.svc.token_info()["set"]:
            raise ValueError("כבר שמור טוקן. כדי להחליף – 'מחק והזן מחדש'")
        token = self.svc.validate_token(body.get("token", ""))
        ok, info = check_token(token)
        if not ok and "שגוי" in info:
            raise ValueError(info)
        self.svc.set_bot_token(token, UI_ACTOR)
        return {"checked": ok, "info": info if ok else info}

    @route("POST", "/api/settings/token/delete")
    def settings_token_delete(self, body, q):
        self.svc.clear_bot_token(UI_ACTOR)

    @route("POST", "/api/settings/relay")
    def settings_relay(self, body, q):
        """Address + key of our own Bot-API server. The key is checked once and never returned."""
        svc = self.svc
        url = svc.validate_relay_url(body.get("url", ""))
        key = (body.get("key") or "").strip()
        if key:
            if svc.relay_info()["key_set"]:
                raise ValueError("כבר שמור מפתח. כדי להחליף – 'מחק והזן מחדש'")
            ok, info = check_token(key, api_base=url + "/bot")
            if not ok and "שגוי" in info:
                raise ValueError(info)
        elif not svc.relay_info()["key_set"]:
            raise ValueError("הדביקו את המפתח מדף הניהול של השרת")
        else:
            ok, info = False, ""
        svc.set_relay(url, key or None, UI_ACTOR)
        return {"checked": ok, "info": info}

    @route("POST", "/api/settings/relay/delete")
    def settings_relay_delete(self, body, q):
        self.svc.clear_relay_key(UI_ACTOR)

    @route("POST", "/api/settings/botmode")
    def settings_botmode(self, body, q):
        self.svc.set_bot_mode(body.get("mode", ""), UI_ACTOR)

    @route("POST", "/api/settings/users")
    def settings_user_add(self, body, q):
        self.svc.add_user(body.get("chat_id", ""), body.get("name", ""), UI_ACTOR)

    @route("POST", r"/api/settings/users/([0-9a-f]{12})/admin")
    def settings_user_admin(self, body, q, key):
        self.svc.set_admin_by_key(key, bool(body.get("is_admin")), UI_ACTOR)

    @route("POST", r"/api/settings/users/([0-9a-f]{12})/delete")
    def settings_user_delete(self, body, q, key):
        self.svc.remove_user_by_key(key, UI_ACTOR)

    @route("POST", r"/api/settings/requests/([0-9a-f]{12})/approve")
    def settings_request_approve(self, body, q, key):
        self.svc.approve_request(key, UI_ACTOR)

    @route("POST", "/api/settings/notify")
    def settings_notify(self, body, q):
        self.svc.set_notify_option(body.get("key", ""), bool(body.get("on")), UI_ACTOR)

    @route("POST", "/api/settings/gsheet")
    def settings_gsheet(self, body, q):
        return self.svc.set_gsheet_url(body.get("url", ""), UI_ACTOR)

    @route("POST", "/api/settings/gsheet/sync")
    def settings_gsheet_sync(self, body, q):
        return self.svc.sync_gsheet()


def make_handler(api: Api, port: int):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class Handler(BaseHTTPRequestHandler):
        server_version = "SchoolBells"

        def log_message(self, fmt, *args):  # quiet
            log.debug("web: " + fmt, *args)

        def _send(self, code: int, payload: bytes, ctype: str, extra: dict | None = None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(payload)

        def _send_media(self, p: Path):
            """Serves audio with HTTP Range support so the browser can seek (listen to a trimmed segment)."""
            data = p.read_bytes()
            ctype = mimetypes.guess_type(p.name)[0] or "audio/wav"
            rng = re.fullmatch(r"bytes=(\d*)-(\d*)", self.headers.get("Range", "").strip())
            if not rng or (not rng.group(1) and not rng.group(2)):
                return self._send(200, data, ctype, {"Accept-Ranges": "bytes"})
            size = len(data)
            if rng.group(1):
                start = int(rng.group(1))
                end = min(int(rng.group(2)), size - 1) if rng.group(2) else size - 1
            else:  # suffix range: last N bytes
                start, end = max(0, size - int(rng.group(2))), size - 1
            if start >= size or start > end:
                return self._send(416, b"", ctype, {"Content-Range": f"bytes */{size}"})
            self._send(206, data[start:end + 1], ctype,
                       {"Accept-Ranges": "bytes", "Content-Range": f"bytes {start}-{end}/{size}"})

        def _json(self, code: int, obj):
            self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode(), "application/json; charset=utf-8")

        def _guard(self, mutating: bool) -> bool:
            # Blocks DNS-rebinding (Host) and cross-site requests from web pages (custom header -> CORS preflight)
            if self.headers.get("Host") not in allowed_hosts:
                self._json(403, {"error": "forbidden host"})
                return False
            if mutating and self.headers.get("X-Bells") != "1":
                self._json(403, {"error": "forbidden"})
                return False
            return True

        def do_GET(self):
            if not self._guard(False):
                return
            url = urllib.parse.urlparse(self.path)
            path = url.path
            if path.startswith("/api/"):
                return self._api("GET", path, {}, urllib.parse.parse_qs(url.query))
            m = re.fullmatch(r"/media/(ringtone|upload)/(\d+)", path)
            if m:
                try:
                    get = api.svc.get_ringtone if m.group(1) == "ringtone" else api.svc.get_upload
                    p = get(int(m.group(2)))["abs_path"]
                    return self._send_media(p)
                except Exception:
                    return self._json(404, {"error": "not found"})
            name = "index.html" if path in ("/", "") else path.lstrip("/")
            f = (STATIC / name).resolve()
            if STATIC not in f.parents or not f.is_file():
                return self._json(404, {"error": "not found"})
            ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype.endswith("javascript"):
                ctype += "; charset=utf-8"
            self._send(200, f.read_bytes(), ctype)

        def do_POST(self):
            if not self._guard(True):
                return
            length = int(self.headers.get("Content-Length") or 0)
            if length > MAX_UPLOAD:
                return self._json(413, {"error": "הקובץ גדול מדי (עד 60MB)"})
            raw = self.rfile.read(length) if length else b""
            path = urllib.parse.urlparse(self.path).path
            if path in ("/api/ringtones/upload", "/api/uploads"):
                return self._upload(raw, staged=path == "/api/uploads")
            if path == "/api/update/install":
                return self._update_upload(raw)
            if path == "/api/holidays/import":
                return self._holiday_import(raw)
            try:
                body = json.loads(raw or b"{}")
            except json.JSONDecodeError:
                return self._json(400, {"error": "bad json"})
            self._api("POST", path, body, {})

        def _update_upload(self, raw: bytes):
            inc = api.svc.updates_dir / "incoming"
            inc.mkdir(parents=True, exist_ok=True)
            for old in inc.glob("*.zip"):
                old.unlink(missing_ok=True)
            tmp = inc / f"{uuid.uuid4().hex}.zip"
            tmp.write_bytes(raw)
            try:  # fire-and-forget: a verified package is installed right away
                info = api.svc.inspect_update(tmp, UI_ACTOR)
                self._json(200, api.svc.apply_update(info["token"], UI_ACTOR))
            except ValueError as e:
                tmp.unlink(missing_ok=True)
                self._json(400, {"error": str(e)})

        def _holiday_import(self, raw: bytes):
            name = urllib.parse.unquote(self.headers.get("X-Filename", "") or "file.csv")
            try:
                self._json(200, api.svc.import_holidays(name, raw, UI_ACTOR))
            except ValueError as e:
                self._json(400, {"error": str(e)})

        def _upload(self, raw: bytes, staged: bool = False):
            name = urllib.parse.unquote(self.headers.get("X-Filename", "") or "צלצול")
            ext = Path(name).suffix.lower()[:6] or ".mp3"
            tmp = api.svc.media_dir / f"up_{uuid.uuid4().hex}{ext}"
            try:
                tmp.write_bytes(raw)
                if staged:   # X-Library: 0 = uploaded only to make a ringtone (not kept in the song library)
                    u = api.svc.stage_upload(tmp, Path(name).stem, UI_ACTOR,
                                             library=self.headers.get("X-Library", "1") != "0")
                    return self._json(200, {"id": u["id"], "name": u["name"], "duration": u["duration"]})
                rt = api.svc.import_ringtone(tmp, Path(name).stem, UI_ACTOR)
                self._json(200, {"id": rt["id"], "name": rt["name"], "duration": rt["duration"]})
            except Exception as e:
                log.exception("upload failed")
                self._json(400, {"error": str(e)})
            finally:
                tmp.unlink(missing_ok=True)

        def _api(self, method: str, path: str, body: dict, q: dict):
            for m, rx, fname in ROUTES:
                if m != method:
                    continue
                mt = rx.match(path)
                if mt:
                    try:
                        res = getattr(api, fname)(body, q, *mt.groups())
                        return self._json(200, res if res is not None else {"ok": True})
                    except (ValueError, KeyError) as e:
                        return self._json(400, {"error": str(e).strip("'")})
                    except Exception as e:
                        log.exception("api error")
                        return self._json(500, {"error": f"שגיאה: {e}"})
            self._json(404, {"error": "not found"})

    return Handler


class WebServer:
    def __init__(self, svc: BellService, port: int):
        self.port = port
        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(Api(svc), port))
        self.httpd.daemon_threads = True

    def start(self):
        threading.Thread(target=self.httpd.serve_forever, name="web-ui", daemon=True).start()
        log.info("web UI on http://127.0.0.1:%d/", self.port)

    def stop(self):
        self.httpd.shutdown()
