"""Thread-safe outgoing notifications (health check, alerts) with retry while offline."""
from __future__ import annotations

import json
import logging
import queue
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable

from .. import net

log = logging.getLogger(__name__)
TELEGRAM_BOT_API = "https://api.telegram.org/bot"


class TelegramNotifier:
    def __init__(self, get_token: Callable[[], str], get_chat_ids: Callable[[], list[int]],
                 max_age_seconds: int = 3 * 3600, get_api_base: Callable[[], str] | None = None):
        """Token, server and recipients are read on every send, so changes from the UI apply immediately.
        get_api_base: e.g. 'https://api.telegram.org/bot' or the private relay's '<url>/bot'."""
        self.get_token = get_token
        self.get_api_base = get_api_base or (lambda: TELEGRAM_BOT_API)
        self.get_chat_ids = get_chat_ids
        self.max_age = max_age_seconds
        self._q: queue.Queue = queue.Queue()
        threading.Thread(target=self._worker, name="notifier", daemon=True).start()

    def send(self, text: str) -> None:
        if not self.get_token():
            return
        for cid in self.get_chat_ids():
            self._q.put((time.time(), cid, text))

    def send_to(self, chat_id: int, text: str) -> None:
        if self.get_token():
            self._q.put((time.time(), chat_id, text))

    MAX_BACKOFF = 900  # seconds

    def _post(self, chat_id: int, text: str) -> float | None:
        """None = sent. Otherwise seconds to wait before retrying (Telegram's retry_after when it gave one)."""
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
        req = urllib.request.Request(f"{self.get_api_base()}{self.get_token()}/sendMessage", data=data)
        try:
            with net.urlopen(req, timeout=15) as r:
                return None if json.loads(r.read()).get("ok") else 0.0
        except urllib.error.HTTPError as e:
            retry_after = _retry_after(e)
            log.warning("notify failed: HTTP %s%s", e.code, f" (retry_after {retry_after:.0f}s)" if retry_after else "")
            if e.code in (400, 403):     # chat gone / bot blocked by that user: retrying won't help
                return -1.0
            return retry_after or 0.0
        except Exception as e:
            log.warning("notify failed: %s", net.describe(e)[1])
            return 0.0

    def _worker(self):
        while True:
            self._deliver(*self._q.get())

    def _deliver(self, created: float, cid: int, text: str, sleep=time.sleep) -> bool:
        backoff = 30.0
        while True:
            wait = self._post(cid, text)
            if wait is None:
                return True
            if wait < 0 or time.time() - created > self.max_age:
                log.error("dropping notification")
                return False
            sleep(max(wait + 1, backoff))   # honour retry_after; otherwise a growing delay
            backoff = min(self.MAX_BACKOFF, backoff * 2)


def _retry_after(e: "urllib.error.HTTPError") -> float | None:
    try:
        body = json.loads(e.read() or b"{}")
        ra = (body.get("parameters") or {}).get("retry_after")
        return float(ra) if ra is not None else None
    except Exception:
        h = e.headers.get("Retry-After") if e.headers else None
        return float(h) if h and h.isdigit() else None


_last_check: dict = {"t": 0.0, "until": 0.0}


def check_token(token: str, timeout: int = 10, api_base: str = TELEGRAM_BOT_API) -> tuple[bool, str]:
    """Calls getMe once (rate-limited locally). Returns (ok, bot username or a Hebrew error with the real code)."""
    now = time.time()
    if now < _last_check["until"]:
        return False, f"טלגרם מגביל את קצב הבקשות (429) – נסו שוב בעוד {_last_check['until'] - now:.0f} שניות"
    if now - _last_check["t"] < 5:
        return False, "בדיקה כבר רצה – נסו שוב בעוד כמה שניות"
    _last_check["t"] = now
    try:
        with net.urlopen(f"{api_base}{token}/getMe", timeout=timeout) as r:
            data = json.loads(r.read())
            return data.get("ok", False), "@" + data.get("result", {}).get("username", "?")
    except urllib.error.HTTPError as e:
        if e.code in (401, 404):
            return False, ("הטוקן שגוי – טלגרם דחה אותו (401)" if api_base == TELEGRAM_BOT_API
                           else "המפתח שגוי או מושבת – השרת דחה אותו (401)")
        if e.code == 429:
            ra = _retry_after(e) or 30
            _last_check["until"] = time.time() + ra
            return False, f"טלגרם מגביל את קצב הבקשות (429) – נסו שוב בעוד {ra:.0f} שניות"
        if e.code == 409:
            return False, "הבוט פועל במקום אחר עם אותו טוקן (409)"
        return False, f"שגיאת טלגרם {e.code}"
    except Exception as e:
        why, detail = net.describe(e)
        server = "טלגרם" if api_base == TELEGRAM_BOT_API else "השרת הפרטי"
        return False, f"אין חיבור ל{server}: {why} ({detail[:200]})"
