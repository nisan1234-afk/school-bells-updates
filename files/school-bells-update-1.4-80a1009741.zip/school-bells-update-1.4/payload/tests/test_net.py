"""HTTPS behind a filter that inspects HTTPS (NetFree / Rimon / antivirus): the filter's root certificate is in
the operating-system store but not in Python's certifi bundle. Reproduced with our own root CA that only the
"system store" knows (SSL_CERT_FILE stands in for the Windows certificate store), and a fake Telegram over HTTPS."""
import datetime as dt
import ipaddress
import json
import socket
import ssl
import sys
import threading
import time
from http.server import ThreadingHTTPServer
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

pytest.importorskip("cryptography")
from cryptography import x509  # noqa: E402
from cryptography.hazmat.primitives import hashes, serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric import ec  # noqa: E402
from cryptography.x509.oid import NameOID  # noqa: E402

from bells import net  # noqa: E402


def make_pki(tmp: Path):
    """A 'filter' root CA + a server certificate for 127.0.0.1 signed by it."""
    now = dt.datetime.now(dt.timezone.utc)
    ca_key = ec.generate_private_key(ec.SECP256R1())
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Fake Filter Root CA")])
    ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name).public_key(ca_key.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(now - dt.timedelta(days=1))
          .not_valid_after(now + dt.timedelta(days=30))
          .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
          .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, content_commitment=False,
                                       key_encipherment=False, data_encipherment=False, key_agreement=False,
                                       encipher_only=False, decipher_only=False), critical=True)
          .sign(ca_key, hashes.SHA256()))
    key = ec.generate_private_key(ec.SECP256R1())
    cert = (x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "127.0.0.1")]))
            .issuer_name(ca_name).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(days=1)).not_valid_after(now + dt.timedelta(days=30))
            .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]), critical=False)
            .add_extension(x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .sign(ca_key, hashes.SHA256()))
    (tmp / "ca.pem").write_bytes(ca.public_bytes(serialization.Encoding.PEM))
    (tmp / "srv.pem").write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    (tmp / "srv.key").write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                                    serialization.NoEncryption()))
    return tmp / "ca.pem"


@pytest.fixture
def https_telegram(tmp_path, monkeypatch):
    import test_telegram_resilience as T

    class OkTelegram(T.FakeTelegram):
        def do_POST(self):
            method = self.path.rsplit("/", 1)[-1]
            self.rfile.read(int(self.headers.get("Content-Length") or 0))
            T.FakeTelegram.log.append((time.monotonic(), method))
            if method == "getUpdates":
                time.sleep(0.5)
                return self._send(200, {"ok": True, "result": []})
            return T.FakeTelegram.do_POST(self) if method == "getMe" else self._send(200, {"ok": True, "result": True})
    T.FakeTelegram.mode, T.FakeTelegram.log = "ok", []
    ca = make_pki(tmp_path)
    srv = ThreadingHTTPServer(("127.0.0.1", 0), OkTelegram)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(tmp_path / "srv.pem", tmp_path / "srv.key")
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    # the filter's root CA is in the "system store" only (Windows store <-> SSL_CERT_FILE here), not in certifi
    monkeypatch.setenv("SSL_CERT_FILE", str(ca))
    monkeypatch.delenv("SSL_CERT_DIR", raising=False)
    net.ssl_context.cache_clear()
    yield f"https://127.0.0.1:{srv.server_address[1]}", T
    srv.shutdown()
    getattr(net.ssl_context, "cache_clear", lambda: None)()   # the test may have replaced it


def test_python_bundle_rejects_filter_cert_but_system_store_accepts(https_telegram):
    import certifi
    import httpx
    base, _ = https_telegram
    with pytest.raises(httpx.ConnectError) as ei:        # what the Telegram library did before 1.3.4
        httpx.post(base + "/botX/getMe", verify=ssl.create_default_context(cafile=certifi.where()), timeout=10)
    why, detail = net.describe(ei.value)
    assert "CERTIFICATE_VERIFY_FAILED" in detail and "CERTIFICATE_VERIFY_FAILED" in why
    r = httpx.post(base + "/botX/getMe", verify=net.ssl_context(), timeout=10)   # 1.3.4: system store
    assert r.json()["ok"] is True
    import urllib.request
    with net.urlopen(urllib.request.Request(base + "/botX/getMe", data=b""), timeout=10) as resp:   # urllib paths too
        assert json.loads(resp.read())["ok"] is True


def test_bot_connects_through_filter_and_reports_ssl_error_otherwise(https_telegram, tmp_path, monkeypatch):
    from datetime import datetime as DT

    from bells.bot import telegram_bot as tb
    from bells.config import load_config
    from bells.core.service import BellService
    from bells.player.audio_tools import AudioProcessor
    from bells.player.player import NullPlayer
    from bells.storage.db import Storage
    base, T = https_telegram
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path / "d"
    svc = BellService(cfg, Storage(tmp_path / "s.db"), NullPlayer(), AudioProcessor(None), clock=DT.now)
    svc.seed()
    svc.set_bot_token("8123456789:AAH" + "Q" * 32, ("1", "t"))
    bot = tb.BellBot(svc)
    bot.api_base_url = base + "/bot"
    monkeypatch.setattr(tb, "_BOT_LOOP_LOCK", threading.Lock())
    threading.Thread(target=bot.run_forever, daemon=True).start()
    for _ in range(40):
        if svc.bot_status["state"] == "online":
            break
        time.sleep(0.25)
    assert svc.bot_status["state"] == "online", svc.bot_status       # through the "filter", like Chrome
    svc.bot_changed.set()                                            # reconnect with certifi only (old behaviour)
    import certifi
    monkeypatch.setattr(tb.net, "ssl_context", lambda: ssl.create_default_context(cafile=certifi.where()))
    for _ in range(60):
        if svc.bot_status["state"] == "error":
            break
        time.sleep(0.25)
    st = svc.bot_status
    assert st["code"] == "ssl" and "CERTIFICATE_VERIFY_FAILED" in st["detail"], st   # the real error is shown
    assert "8123456789" not in st["detail"]                           # no token in the UI


def test_describe_common_failures():
    assert "DNS" in net.describe(socket.gaierror(11001, "getaddrinfo failed"))[0]
    assert "חומת האש" in net.describe(PermissionError(10013, "An attempt was made to access a socket in a way "
                                                               "forbidden by its access permissions"))[0]
    assert "נדחה" in net.describe(ConnectionRefusedError(10061, "refused"))[0]
    assert "פרוקסי" in net.describe(OSError("Tunnel connection failed: 407 Proxy Authentication Required"))[0]
    e = ssl.SSLCertVerificationError(1, "[SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed")
    import urllib.error
    assert "CERTIFICATE_VERIFY_FAILED" in net.describe(urllib.error.URLError(e))[0]
    leaked = net.describe(OSError("GET https://api.telegram.org/bot8123456789:AAH" + "Q" * 32 + "/getMe failed"))[1]
    assert "8123456789" not in leaked and "QQQQ" not in leaked


def test_windows_system_proxy_is_used(monkeypatch):
    from bells.bot import telegram_bot as tb
    monkeypatch.setattr(net.urllib.request, "getproxies", lambda: {"https": "10.0.0.5:3128", "http": "10.0.0.5:3128"})
    monkeypatch.setattr(net.urllib.request, "proxy_bypass", lambda host: False)
    assert net.proxy_for("https://api.telegram.org") == "http://10.0.0.5:3128"
    seen = {}

    class Rec:
        def __init__(self, **kw):
            seen.update(kw)
    monkeypatch.setattr(tb, "HTTPXRequest", Rec)
    bot = tb.BellBot.__new__(tb.BellBot)
    bot.api_base_url = None
    bot.svc = type("S", (), {"bot_server": lambda self: "https://api.telegram.org"})()
    bot._http()
    assert seen["proxy"] == "http://10.0.0.5:3128" and isinstance(seen["httpx_kwargs"]["verify"], ssl.SSLContext)
