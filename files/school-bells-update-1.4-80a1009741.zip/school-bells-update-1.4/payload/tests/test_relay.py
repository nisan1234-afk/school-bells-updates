"""End to end: our own Bot-API server (relay/ on Cloudflare Workers, run locally with `wrangler dev`), the real
bot code (python-telegram-bot) connected to it, and "phones" – over HTTP and in a real browser.

Needs wrangler (npm) – set SB_WRANGLER=/path/to/wrangler, or have `wrangler` on PATH. Skipped otherwise
(e.g. on the school computer during installation)."""
import base64
import http.cookiejar
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import wave
from datetime import datetime
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

WRANGLER = os.environ.get("SB_WRANGLER") or shutil.which("wrangler")
pytestmark = pytest.mark.skipif(not WRANGLER or not Path(WRANGLER).exists(), reason="wrangler not installed")
pytest.importorskip("cryptography")
from cryptography.hazmat.primitives import hashes, serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric import padding, rsa  # noqa: E402

CLIENT_ID = "test-client.apps.googleusercontent.com"
SETUP = "setup-" + "x" * 20


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


class Google:
    """Stands in for Google sign-in: our own RSA key, published to the worker as its JWKS."""

    def __init__(self):
        self.key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        n = self.key.public_key().public_numbers()
        self.jwks = {"keys": [{"kty": "RSA", "kid": "k1", "alg": "RS256", "use": "sig",
                               "n": b64u(n.n.to_bytes((n.n.bit_length() + 7) // 8, "big")), "e": b64u(n.e.to_bytes(3, "big"))}]}

    def token(self, sub, email, name, aud=CLIENT_ID, exp_in=600, verified=True, key=None):
        header = b64u(json.dumps({"alg": "RS256", "kid": "k1", "typ": "JWT"}).encode())
        now = int(time.time())
        claims = b64u(json.dumps({"iss": "https://accounts.google.com", "aud": aud, "sub": sub, "email": email,
                                  "email_verified": verified, "name": name, "iat": now, "exp": now + exp_in}).encode())
        sig = (key or self.key).sign(f"{header}.{claims}".encode(), padding.PKCS1v15(), hashes.SHA256())
        return f"{header}.{claims}.{b64u(sig)}"


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


@pytest.fixture(scope="module")
def relay(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("relay")
    src = tmp / "relay"
    shutil.copytree(ROOT / "relay", src, ignore=shutil.ignore_patterns("node_modules", ".wrangler", ".dev.vars"))
    g = Google()
    (src / ".dev.vars").write_text(
        f'SESSION_SECRET="{b64u(os.urandom(32))}"\nSETUP_CODE="{SETUP}"\nGOOGLE_CLIENT_ID="{CLIENT_ID}"\n'
        f"GOOGLE_JWKS='{json.dumps(g.jwks)}'\nIDLE_RECHECK_SEC=\"1\"\n")
    port = free_port()
    log = open(tmp / "wrangler.log", "w")
    proc = subprocess.Popen([WRANGLER, "dev", "--port", str(port), "--ip", "127.0.0.1", "--persist-to", str(tmp / "state")],
                            cwd=src, stdout=log, stderr=subprocess.STDOUT, env={**os.environ, "CI": "1"})
    url = f"http://127.0.0.1:{port}"
    for _ in range(120):
        try:
            urllib.request.urlopen(url + "/", timeout=2)
            break
        except Exception:
            time.sleep(0.5)
    else:
        proc.kill()
        raise RuntimeError("wrangler dev did not start: " + (tmp / "wrangler.log").read_text()[-2000:])
    yield {"url": url, "google": g, "log": tmp / "wrangler.log"}
    proc.terminate()
    try:
        proc.wait(10)
    except subprocess.TimeoutExpired:
        proc.kill()


class Client:
    """A signed-in browser, minus the browser."""

    def __init__(self, base):
        self.base = base
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def call(self, path, body=None, raw=None, headers=None, method=None):
        h = {"x-sb": "1", **(headers or {})}
        data = None
        if raw is not None:
            data = raw
        elif body is not None:
            data = json.dumps(body).encode()
            h["content-type"] = "application/json"
        req = urllib.request.Request(self.base + path, data=data, headers=h, method=method)
        try:
            with self.op.open(req, timeout=30) as r:
                return r.status, (json.loads(r.read()) if "json" in r.headers.get("content-type", "") else r.read())
        except urllib.error.HTTPError as e:
            body = e.read()
            try:
                return e.code, json.loads(body)
            except ValueError:
                return e.code, body

    def login(self, token):
        st, r = self.call("/api/login", {"credential": token})
        assert st == 200, r
        for c in self.jar:          # the local server is http: let the Secure cookie be sent anyway
            c.secure = False
        return r


def bot_api(url, key, method, **params):
    req = urllib.request.Request(f"{url}/bot{key}/{method}", data=json.dumps(params).encode(),
                                 headers={"content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


def wait_for(fn, timeout=30, what="condition"):
    end = time.time() + timeout
    while time.time() < end:
        v = fn()
        if v:
            return v
        time.sleep(0.3)
    raise AssertionError("timeout waiting for " + what)


def wav_bytes(seconds=1.0):
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(8000)
        w.writeframes(b"\x00\x10" * int(8000 * seconds))
    return buf.getvalue()


@pytest.fixture(scope="module")
def school(relay):
    owner = Client(relay["url"])
    owner.login(relay["google"].token("owner-1", "owner@example.com", "בעל השרת"))
    st, me = owner.call("/admin/api/me")
    assert me["needs_setup"] and not me["owner"]
    assert owner.call("/admin/api/claim", {"code": "wrong"})[1]["ok"] is False
    assert owner.call("/admin/api/claim", {"code": SETUP})[1]["ok"] is True
    stranger = Client(relay["url"])
    stranger.login(relay["google"].token("x-9", "x@example.com", "זר"))
    assert stranger.call("/admin/api/claim", {"code": SETUP})[1]["ok"] is False      # only one owner, once
    assert stranger.call("/admin/api/create", {"name": "פריצה"})[0] == 403
    st, r = owner.call("/admin/api/create", {"name": "ישיבת בדיקה"})
    assert r["ok"] and r["key"].startswith(r["sid"] + ":")
    return {"owner": owner, "sid": r["sid"], "key": r["key"]}


@pytest.fixture(scope="module")
def app(relay, school, tmp_path_factory):
    """The real bell service + bot, switched to the relay from the settings API like a user would."""
    from bells.bot import telegram_bot as tb
    from bells.bot.notifier import TelegramNotifier
    from bells.config import load_config
    from bells.core.service import BellService
    from bells.player.audio_tools import AudioProcessor
    from bells.player.player import NullPlayer
    from bells.storage.db import Storage
    from bells.web.server import Api
    tmp = tmp_path_factory.mktemp("app")
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp / "d"
    svc = BellService(cfg, Storage(tmp / "s.db"), NullPlayer(), AudioProcessor(shutil.which("ffmpeg")), clock=datetime.now)
    svc.seed()
    api = Api(svc)
    with pytest.raises(ValueError):            # wrong key: refused before saving
        api.settings_relay({"url": relay["url"], "key": school["sid"] + ":" + "A" * 40}, {})
    from bells.bot import notifier
    notifier._last_check["t"] = 0                  # the key check is rate-limited to one per 5 s
    r = api.settings_relay({"url": relay["url"] + "/", "key": school["key"]}, {})
    assert r["checked"], r
    assert r["info"] == f"@bells_{school['sid']}_bot"
    s = api.settings({}, {})
    assert s["relay"]["mode"] == "relay" and school["key"] not in json.dumps(s, ensure_ascii=False)
    assert s["relay"]["phone_link"] == f"{relay['url']}/s/{school['sid']}/"
    svc.notifier = TelegramNotifier(svc.bot_token, svc.authorized_ids, get_api_base=svc.bot_api_base)
    bot = tb.BellBot(svc)
    tb._BOT_LOOP_LOCK = threading.Lock()
    threading.Thread(target=bot.run_forever, daemon=True).start()
    wait_for(lambda: svc.bot_status["state"] == "online", 40, "bot online via relay")
    assert svc.bot_status["username"] == f"@bells_{school['sid']}_bot"
    return {"svc": svc, "api": api, "bot": bot}


def history(phone, sid):
    st, r = phone.call(f"/s/{sid}/api/history")
    assert st == 200, r
    return r


def last_bot_text(phone, sid):
    msgs = [m for m in history(phone, sid)["messages"] if not m["out"]]
    return msgs[-1] if msgs else None


def test_phone_flow_through_real_bot(relay, school, app):
    sid, svc = school["sid"], app["svc"]
    g = relay["google"]
    phone = Client(relay["url"])
    st, me = phone.call(f"/s/{sid}/api/me")
    assert me["school"] == "ישיבת בדיקה" and me["signed_in"] is False
    assert phone.call(f"/s/{sid}/api/send", {"text": "/start"})[0] == 401          # not signed in
    bad = Client(relay["url"])                                                    # forged / foreign tokens
    assert bad.call("/api/login", {"credential": g.token("a", "a@x.com", "a", aud="other-app")})[0] == 401
    assert bad.call("/api/login", {"credential": g.token("a", "a@x.com", "a", verified=False)})[0] == 401
    other_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    assert bad.call("/api/login", {"credential": g.token("a", "a@x.com", "a", key=other_key)})[0] == 401

    phone.login(g.token("u-1", "teacher@example.com", "מורה דוגמה"))
    me = phone.call(f"/s/{sid}/api/me")[1]
    assert me["signed_in"] and me["email"] == "teacher@example.com"
    assert time.time() * 1000 - me["bot_seen"] < 60_000                          # "school computer connected"

    # 1) unknown user -> the bot refuses and the request shows up on the computer ("asked for access")
    t0 = time.time()
    assert phone.call(f"/s/{sid}/api/send", {"text": "/start"})[1]["ok"]
    m = wait_for(lambda: (last_bot_text(phone, sid) or {}).get("text", "").startswith("⛔"), 20, "no-access reply")
    assert time.time() - t0 < 10
    req = wait_for(lambda: svc.access_requests(), 10, "access request")[0]
    assert "teacher@example.com" in req["name"]
    svc.approve_request(req["key"], ("ui", "מחשב"))

    # 2) the main menu (reply keyboard) arrives and works
    phone.call(f"/s/{sid}/api/send", {"text": "/start"})
    kb = wait_for(lambda: history(phone, sid)["kb"], 20, "reply keyboard")
    labels = [b["text"] if isinstance(b, dict) else b for row in kb["keyboard"] for b in row]
    from bells.bot.telegram_bot import BTN_MUTE, BTN_RING
    assert BTN_RING in labels
    rings = len([c for c in svc.player.calls if c[0] == "bell"])
    phone.call(f"/s/{sid}/api/send", {"text": BTN_RING})
    wait_for(lambda: len([c for c in svc.player.calls if c[0] == "bell"]) > rings, 20, "ring through relay")
    log = svc.db.recent_actions(svc.sid, 20) if hasattr(svc.db, "recent_actions") else None
    if log is not None:
        assert any("teacher@example.com" in (r["actor_name"] or "") for r in log)

    # 3) inline buttons (callback queries) + message edits
    phone.call(f"/s/{sid}/api/send", {"text": BTN_MUTE})
    menu = wait_for(lambda: next((m for m in reversed(history(phone, sid)["messages"]) if m.get("buttons")), None), 20, "mute menu")
    button = next(b for row in menu["buttons"] for b in row if b["data"] and "today" in b["data"]) \
        if any("today" in (b["data"] or "") for row in menu["buttons"] for b in row) else menu["buttons"][0][0]
    assert phone.call(f"/s/{sid}/api/send", {"message_id": menu["id"], "callback_data": button["data"]})[1]["ok"]
    assert phone.call(f"/s/{sid}/api/send", {"message_id": menu["id"], "callback_data": "made-up"})[0] == 400
    wait_for(lambda: next((m for m in history(phone, sid)["messages"] if m["id"] == menu["id"]), {}).get("edited")
             or len(history(phone, sid)["messages"]) > 0 and svc.mute_state().describe(svc.now().date()), 20, "callback handled")

    # 4) an audio file from the phone: the bot downloads it, the server deletes it right after
    st, up = phone.call(f"/s/{sid}/api/upload", raw=wav_bytes(2.0),
                        headers={"content-type": "audio/wav", "x-kind": "audio", "x-name": "song.wav", "x-duration": "2"})
    assert st == 200, up
    file_id = up["message"]["file"]["id"]
    wait_for(lambda: any(m.get("buttons") and m["id"] > up["message"]["id"] for m in history(phone, sid)["messages"]),
             30, "bot menu for the uploaded file")
    gone = urllib.request.Request(f"{relay['url']}/file/bot{school['key']}/{file_id}/song.wav")
    with pytest.raises(urllib.error.HTTPError) as ei:
        urllib.request.urlopen(gone, timeout=10)
    assert ei.value.code in (400, 404)                                            # nothing left on the server

    # 5) a voice recording = announcement on the speakers
    played = len([c for c in svc.player.calls if c[0] == "media"])
    st, up = phone.call(f"/s/{sid}/api/upload", raw=wav_bytes(1.0),
                        headers={"content-type": "audio/wav", "x-kind": "voice", "x-name": "rec.wav", "x-duration": "1"})
    assert st == 200
    wait_for(lambda: len([c for c in svc.player.calls if c[0] == "media"]) > played, 30, "announcement played")

    # 6) alerts from the computer (notifier) reach the phone through the relay too
    chat_id = svc.authorized_ids()[0]
    svc.notifier.send_to(chat_id, "בדיקת התראה")
    wait_for(lambda: any(m.get("text") == "בדיקת התראה" for m in history(phone, sid)["messages"]), 20, "notification")


def test_isolation_between_users_and_schools(relay, school, app):
    sid = school["sid"]
    g = relay["google"]
    a = Client(relay["url"])
    a.login(g.token("u-1", "teacher@example.com", "מורה דוגמה"))
    b = Client(relay["url"])
    b.login(g.token("u-2", "other@example.com", "אחר"))
    msgs_a = history(a, sid)["messages"]
    assert msgs_a and history(b, sid)["messages"] == []                         # B sees nothing of A
    with_buttons = next(m for m in reversed(msgs_a) if m.get("buttons") and m["buttons"][0][0]["data"])
    assert b.call(f"/s/{sid}/api/send", {"message_id": with_buttons["id"],
                                         "callback_data": with_buttons["buttons"][0][0]["data"]})[0] == 400
    out_file = next((m["file"]["id"] for m in msgs_a if m.get("file")), None)
    if out_file:
        assert b.call(f"/s/{sid}/file/{out_file}", method="GET")[0] == 404
    # another school's key can't read this school's updates, and the page of an unknown school is a 404
    st, r = school["owner"].call("/admin/api/create", {"name": "בית ספר שני"})
    other = r["key"]
    assert bot_api(relay["url"], other.split(":")[0] + ":" + school["key"].split(":")[1], "getMe")["error_code"] == 401
    assert bot_api(relay["url"], sid + ":" + other.split(":")[1], "getMe")["error_code"] == 401
    assert a.call("/s/9999999999/api/me")[0] == 404
    # a stranger can't burn the free quotas: messages are rate-limited per user
    spam = Client(relay["url"])
    spam.login(g.token("u-spam", "spam@example.com", "ספאם"))
    codes = [spam.call(f"/s/{sid}/api/send", {"text": f"x{i}"})[0] for i in range(45)]
    assert codes.count(200) == 40 and codes[-1] == 429
    # cross-site POST (no custom header) is refused
    req = urllib.request.Request(f"{relay['url']}/s/{sid}/api/send", data=b'{"text":"x"}',
                                 headers={"content-type": "application/json"})
    a.op.addheaders = []
    with pytest.raises(urllib.error.HTTPError) as ei:
        a.op.open(req, timeout=10)
    assert ei.value.code == 403


def test_second_computer_gets_409_and_revoke_rotate(relay, school, app):
    sid, svc = school["sid"], app["svc"]
    r = bot_api(relay["url"], school["key"], "getUpdates", timeout=0)
    # the running bot polls from 127.0.0.1 too, so locally both look like the same computer; with another address:
    req = urllib.request.Request(f"{relay['url']}/bot{school['key']}/getUpdates", data=b"{}",
                                 headers={"content-type": "application/json", "cf-connecting-ip": "203.0.113.9"})
    try:
        urllib.request.urlopen(req, timeout=20)
        conflict = None
    except urllib.error.HTTPError as e:
        conflict = e.code
    assert r["ok"] is True
    if conflict is not None:            # wrangler dev may not pass cf-connecting-ip through
        assert conflict == 409

    owner = school["owner"]
    assert owner.call("/admin/api/revoke", {"sid": sid, "revoked": True})[1]["ok"]
    wait_for(lambda: svc.bot_status["state"] == "error" and svc.bot_status["code"] == "401", 60, "bot sees revoke")
    assert "המפתח" in svc.bot_status["error"] and "BotFather" not in svc.bot_status["error"]
    phone = Client(relay["url"])
    phone.login(relay["google"].token("u-1", "teacher@example.com", "מורה דוגמה"))
    assert phone.call(f"/s/{sid}/api/send", {"text": "/start"})[0] == 403        # the school is disabled

    new_key = owner.call("/admin/api/rotate", {"sid": sid})[1]["key"]
    assert new_key != school["key"] and bot_api(relay["url"], school["key"], "getMe")["error_code"] == 401
    app["api"].settings_relay_delete({}, {})
    from bells.bot import notifier
    notifier._last_check["t"] = 0
    app["api"].settings_relay({"url": relay["url"], "key": new_key}, {})
    wait_for(lambda: svc.bot_status["state"] == "online", 60, "bot back online with the new key")
    school["key"] = new_key
    # switching back to Telegram keeps both credentials
    app["api"].settings_botmode({"mode": "telegram"}, {})
    assert svc.bot_api_base() == "https://api.telegram.org/bot"
    app["api"].settings_botmode({"mode": "relay"}, {})
    assert svc.bot_token() == new_key
    wait_for(lambda: not svc.bot_changed.is_set(), 30, "reconnect started")
    time.sleep(1)
    wait_for(lambda: svc.bot_status["state"] == "online", 60, "online again")


BROWSER_SCRIPT = r"""
const { chromium } = require("playwright");
(async () => {
  const [url, token, shot] = process.argv.slice(2);
  const browser = await chromium.launch({ args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, permissions: ["microphone"] });
  const page = await ctx.newPage();
  await page.route("https://accounts.google.com/**", (r) => r.abort());   // no real Google here; the test signs in itself
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  const step = (s) => console.log("STEP " + s);
  global.__page = page;
  await page.goto(url);
  await page.waitForSelector("#signin:not([hidden])");
  step("signin-shown");
  await page.evaluate((t) => window.__sbLogin(t), token);
  await page.waitForSelector("#log:not([hidden]) .msg");
  step("history:" + (await page.innerText("#school")));
  await page.waitForSelector("#pc.on");
  step("pc-online");
  await page.waitForSelector("#kb button");
  const n0 = await page.locator("#log .msg").count();
  await page.click("#kb button:has-text('צלצול עכשיו')");
  await page.waitForFunction((n) => document.querySelectorAll("#log .msg").length >= n + 2, n0, { timeout: 20000 });
  step("ring-answered");
  await page.fill("#text", "/status");
  await page.click("#send");
  await page.waitForFunction((n) => document.querySelectorAll("#log .msg").length >= n + 4, n0, { timeout: 20000 });
  step("status-answered");
  await page.click("#mic");
  await page.waitForSelector("#rec:not([hidden])");
  await page.waitForTimeout(1500);
  await page.click("#recsend");
  await page.waitForSelector("#composer:not([hidden])");
  await page.waitForFunction(() => [...document.querySelectorAll("#log .msg.out audio")].length > 0, null, { timeout: 20000 });
  await page.waitForFunction(() => /כריזה|📣/.test(document.querySelector("#log .msg:last-child")?.innerText || ""), null, { timeout: 30000 });
  step("voice-answered");
  await page.screenshot({ path: shot });
  if (errors.length) { console.log("ERRORS " + JSON.stringify(errors)); process.exit(1); }
  await browser.close();
})().catch(async (e) => {
  console.log("FAIL " + e);
  try { console.log("LOG " + JSON.stringify(await global.__page.$$eval("#log .msg", (els) => els.map((x) => x.innerText.slice(0, 80))))); } catch {}
  process.exit(1);
});
"""


def test_phone_page_in_a_browser(relay, school, app, tmp_path):
    """The real page in Chromium: sign-in, history, the bot's keyboard, a typed command, a microphone recording."""
    node = shutil.which("node")
    probe = subprocess.run([node, "-e", "require('playwright')"], capture_output=True) if node else None
    if not probe or probe.returncode:
        pytest.skip("node playwright not available")
    sid, svc = school["sid"], app["svc"]
    token = relay["google"].token("u-1", "teacher@example.com", "מורה דוגמה")
    script = tmp_path / "phone.js"
    script.write_text(BROWSER_SCRIPT)
    shot = Path(os.environ.get("SB_SCREENSHOTS", tmp_path)) / "relay-phone.png"
    rings = len([c for c in svc.player.calls if c[0] == "bell"])
    media = len([c for c in svc.player.calls if c[0] == "media"])
    r = subprocess.run([node, str(script), f"{relay['url']}/s/{sid}/", token, str(shot)], capture_output=True,
                       text=True, timeout=180, cwd=tmp_path)
    assert r.returncode == 0, r.stdout + r.stderr
    for step in ("signin-shown", "history:ישיבת בדיקה", "pc-online", "ring-answered", "status-answered", "voice-answered"):
        assert "STEP " + step in r.stdout, r.stdout
    assert len([c for c in svc.player.calls if c[0] == "bell"]) > rings              # the button rang the bell
    assert len([c for c in svc.player.calls if c[0] == "media"]) > media             # the recording was announced
