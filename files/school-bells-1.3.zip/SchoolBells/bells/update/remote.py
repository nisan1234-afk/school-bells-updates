"""Remote update source: a small JSON manifest that names the latest signed package per channel.

{
  "app": "school-bells", "format": 1,
  "channels": {
    "beta":   {"version": "1.3", "file": "files/school-bells-update-1.3.zip", "sha256": "...", "min_from": "1.1"},
    "stable": {"version": "1.2", "file": "files/school-bells-update-1.2.zip", "sha256": "...", "min_from": "1.1"}
  }
}
"file" may be relative to the manifest URL. The manifest is not trusted for safety: the package itself must
carry a valid vendor signature, and a version that is not newer is never installed.
"""
from __future__ import annotations

import hashlib
import json
import urllib.parse
import urllib.request
from pathlib import Path

CHANNELS = ("stable", "beta")
MAX_PACKAGE = 80 * 1024 * 1024


class SourceError(Exception):
    """Could not read the update source (network / bad manifest) – not a fault of the installed system."""


def check_url(url: str) -> str:
    url = url.strip()
    p = urllib.parse.urlparse(url)
    local = p.hostname in ("127.0.0.1", "localhost")
    if p.scheme != "https" and not (p.scheme == "http" and local):
        raise ValueError("כתובת מקור העדכונים חייבת להתחיל ב-https://")
    return url


def _get(url: str, limit: int, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "school-bells-updater", "Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(limit + 1)
    except Exception as e:
        raise SourceError(f"{type(e).__name__}") from e
    if len(data) > limit:
        raise SourceError("too large")
    return data


def fetch_entry(manifest_url: str, channel: str) -> dict:
    try:
        man = json.loads(_get(manifest_url, 1_000_000))
    except ValueError as e:
        raise SourceError("manifest is not valid JSON") from e
    if man.get("app") != "school-bells":
        raise SourceError("not a School Bells manifest")
    entry = (man.get("channels") or {}).get(channel)
    if not entry or not entry.get("version") or not entry.get("file"):
        raise SourceError(f"channel '{channel}' not found in manifest")
    return {**entry, "url": urllib.parse.urljoin(manifest_url, entry["file"])}


def download(entry: dict, dest: Path) -> Path:
    data = _get(entry["url"], MAX_PACKAGE, timeout=120)
    if entry.get("sha256") and hashlib.sha256(data).hexdigest() != entry["sha256"]:
        raise ValueError("קובץ העדכון שהורד פגום (sha256 לא תואם)")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return dest
