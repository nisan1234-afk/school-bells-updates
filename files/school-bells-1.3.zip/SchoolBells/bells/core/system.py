"""OS helpers (Windows): clock sync, single-instance lock."""
from __future__ import annotations

import os
import socket
import subprocess

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def sync_clock() -> tuple[bool, str]:
    if os.name != "nt":
        return False, "not windows"
    try:
        r = subprocess.run(["w32tm", "/resync", "/force"], capture_output=True, timeout=60,
                           creationflags=_NO_WINDOW)
        out = r.stdout.decode("cp1255", "ignore") + r.stderr.decode("cp1255", "ignore")
        return r.returncode == 0, out.strip()
    except Exception as e:
        return False, str(e)


def acquire_single_instance(port: int) -> socket.socket | None:
    """Binds a localhost port; returns None if another instance holds it."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    if os.name == "nt":
        s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", 0x4), 1)
    try:
        s.bind(("127.0.0.1", port))
        s.listen(1)
        return s
    except OSError:
        s.close()
        return None
