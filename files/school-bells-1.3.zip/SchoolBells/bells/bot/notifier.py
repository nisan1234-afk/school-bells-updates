"""Thread-safe outgoing notifications (health check, alerts) with retry while offline."""
from __future__ import annotations

import json
import logging
import queue
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable

log = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, get_token: Callable[[], str], get_chat_ids: Callable[[], list[int]],
                 max_age_seconds: int = 3 * 3600):
        """Token and recipients are read on every send, so changes from the UI apply immediately."""
        self.get_token = get_token
        self.get_chat_ids = get_chat_ids
        self.max_age = max_age_seconds
        self._q: queue.Queue = queue.Queue()
        threading.Thread(target=self._worker, name="notifier", daemon=True).start()

    def send(self, text: str) -> None:
        if not self.get_token():
            return
        for cid in self.get_chat_ids():
            self._q.put((time.time(), cid, text))

    def send_to(self, chat_id: int, text: str) -> None:
        if self.get_token():
            self._q.put((time.time(), chat_id, text))

    def _post(self, chat_id: int, text: str) -> bool:
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
        req = urllib.request.Request(f"https://api.telegram.org/bot{self.get_token()}/sendMessage", data=data)
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read()).get("ok", False)
        except Exception as e:
            log.warning("notify failed (%s)", type(e).__name__)
            return False

    def _worker(self):
        while True:
            created, cid, text = self._q.get()
            while not self._post(cid, text):
                if time.time() - created > self.max_age:
                    log.error("dropping notification after retries")
                    break
                time.sleep(60)


def check_token(token: str, timeout: int = 10) -> tuple[bool, str]:
    """Calls getMe. Returns (ok, bot username or error text)."""
    try:
        with urllib.request.urlopen(f"https://api.telegram.org/bot{token}/getMe", timeout=timeout) as r:
            data = json.loads(r.read())
            return data.get("ok", False), "@" + data.get("result", {}).get("username", "?")
    except urllib.error.HTTPError as e:
        return False, "הטוקן שגוי (טלגרם דחה אותו)" if e.code in (401, 404) else f"שגיאת טלגרם {e.code}"
    except Exception:
        return False, "אין חיבור לאינטרנט – לא ניתן לבדוק כרגע"
