"""Generates assets/bells.ico (desktop shortcut icon). Dev-only: needs Pillow."""
from pathlib import Path
from PIL import Image, ImageDraw

S = 256
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle([0, 0, S - 1, S - 1], radius=64, fill=(31, 95, 139, 255))
gold = (255, 209, 102, 255)
d.ellipse([80, 52, 176, 148], fill=gold)                       # dome
d.polygon([(80, 100), (176, 100), (196, 176), (60, 176)], fill=gold)  # body
d.rounded_rectangle([44, 168, 212, 188], radius=10, fill=gold)  # rim
d.ellipse([110, 186, 146, 222], fill=gold)                     # clapper
d.ellipse([118, 40, 138, 60], fill=gold)                       # top knob
out = Path(__file__).resolve().parent.parent / "assets" / "bells.ico"
img.save(out, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print(out)
