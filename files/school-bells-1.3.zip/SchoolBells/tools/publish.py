"""Publish School Bells updates to an update site (a folder that is served as static files, e.g. a GitHub repo).

  # 1) build a signed package from HEAD and put it on the BETA channel (your test computer gets it tonight)
  python tools/publish.py beta    --site ../school-bells-updates --key ~/school-bells-signing/private_key.hex --push

  # 2) after it ran fine on the test computer: promote the same package to STABLE (all schools)
  python tools/publish.py promote --site ../school-bells-updates --push

  python tools/publish.py status  --site ../school-bells-updates

The site folder holds manifest.json + files/. Each school's computer reads manifest.json once a night
(Settings -> Software update -> source URL) and installs the newest version of its channel.
Packages are cumulative from --base (default: the oldest version still installed somewhere, v1.1),
so a school that skipped versions still updates in one step.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT))
import build_update  # noqa: E402
from bells.version import vtuple  # noqa: E402

EMPTY = {"app": "school-bells", "format": 1, "channels": {}}


def load(site: Path) -> dict:
    p = site / "manifest.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else json.loads(json.dumps(EMPTY))


def save(site: Path, man: dict):
    man["updated"] = datetime.now().isoformat(timespec="seconds")
    (site / "manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def push(site: Path, message: str):
    if not (site / ".git").exists():
        print("(site is not a git repo – upload the folder yourself)")
        return
    for cmd in (["git", "add", "-A"], ["git", "commit", "-m", message], ["git", "push"]):
        subprocess.run(cmd, cwd=site, check=cmd[1] != "commit")
    print("pushed")


def publish_beta(site: Path, key_hex: str, base: str, min_from: str | None, require_clean: bool = True) -> dict:
    files = site / "files"
    pkg = build_update.build(base, key_hex, min_from, files, require_clean=require_clean)
    version = pkg.stem.rsplit("-", 1)[-1]
    man = load(site)
    stable = man["channels"].get("stable")
    if stable and vtuple(version) <= vtuple(stable["version"]):
        sys.exit(f"version {version} is not newer than stable {stable['version']} – bump VERSION first")
    man["channels"]["beta"] = {
        "version": version, "file": f"files/{pkg.name}", "sha256": hashlib.sha256(pkg.read_bytes()).hexdigest(),
        "min_from": min_from, "full_installer": f"files/school-bells-{version}.zip",
        "published": datetime.now().isoformat(timespec="seconds"),
    }
    save(site, man)
    print(f"beta -> {version}")
    return man


def promote(site: Path) -> dict:
    man = load(site)
    beta = man["channels"].get("beta")
    if not beta:
        sys.exit("nothing on the beta channel")
    stable = man["channels"].get("stable")
    if stable and vtuple(beta["version"]) <= vtuple(stable["version"]):
        sys.exit(f"stable already has {stable['version']}")
    man["channels"]["stable"] = {**beta, "promoted": datetime.now().isoformat(timespec="seconds")}
    save(site, man)
    print(f"stable -> {beta['version']}")
    return man


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["beta", "promote", "status"])
    ap.add_argument("--site", required=True, help="folder of the update site (served as static files)")
    ap.add_argument("--key", help="private signing key (hex) – needed for 'beta'")
    ap.add_argument("--base", default="v1.1", help="oldest installed version to support (git tag)")
    ap.add_argument("--min-from", default=None, help="defaults to the version of --base")
    ap.add_argument("--push", action="store_true", help="git commit + push the site folder")
    a = ap.parse_args()
    site = Path(a.site).expanduser().resolve()
    site.mkdir(parents=True, exist_ok=True)
    if a.action == "beta":
        if not a.key:
            sys.exit("--key is required")
        min_from = a.min_from or a.base.lstrip("v")
        man = publish_beta(site, Path(a.key).expanduser().read_text().strip(), a.base, min_from)
        if a.push:
            push(site, f"beta {man['channels']['beta']['version']}")
    elif a.action == "promote":
        man = promote(site)
        if a.push:
            push(site, f"stable {man['channels']['stable']['version']}")
    else:
        print(json.dumps(load(site).get("channels", {}), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
