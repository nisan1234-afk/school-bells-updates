"""Generates assets/default_bell.wav – a temporary chime (replace via the bot)."""
import math
import struct
import wave
from pathlib import Path

RATE = 44100
NOTES = [(659.25, 0.0), (523.25, 0.45), (587.33, 0.9), (392.00, 1.35),
         (392.00, 2.3), (587.33, 2.75), (659.25, 3.2), (523.25, 3.65)]
LENGTH = 6.0


def main(out: Path):
    n = int(RATE * LENGTH)
    buf = [0.0] * n
    for freq, start in NOTES:
        s0 = int(start * RATE)
        for i in range(int(RATE * 2.2)):
            if s0 + i >= n:
                break
            t = i / RATE
            env = math.exp(-2.2 * t) * min(1.0, t / 0.005)
            v = (math.sin(2 * math.pi * freq * t) + 0.4 * math.sin(2 * math.pi * 2 * freq * t)
                 + 0.15 * math.sin(2 * math.pi * 3.01 * freq * t))
            buf[s0 + i] += v * env
    peak = max(abs(x) for x in buf) or 1
    out.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(x / peak * 0.85 * 32767)) for x in buf))


if __name__ == "__main__":
    main(Path(__file__).resolve().parent.parent / "assets" / "default_bell.wav")
