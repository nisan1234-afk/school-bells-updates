# Stops all running copies of the bell system and starts it again via Task Scheduler.
param([string]$TaskName = "SchoolBells", [switch]$StopOnly)
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $extra = if ($StopOnly) { " -StopOnly" } else { "" }
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -TaskName $TaskName$extra"
    exit
}
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -Filter "Name like 'python%'" |
    Where-Object { $_.CommandLine -and $_.CommandLine -like "*$AppDir*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 2
if (-not $StopOnly) {
    Start-ScheduledTask -TaskName $TaskName
    Write-Host "Started task $TaskName"
} else {
    Write-Host "Stopped"
}
