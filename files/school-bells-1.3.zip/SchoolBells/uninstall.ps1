# Removes the scheduled task and stops the system. Data folder is kept.
param([string]$TaskName = "SchoolBells")
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
& "$AppDir\restart.ps1" -TaskName $TaskName -StopOnly
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Write-Host "Uninstalled (the data folder was kept)."
Read-Host "Press Enter to close"
