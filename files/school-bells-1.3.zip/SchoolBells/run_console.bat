@echo off
rem Manual run with a console window (for debugging). Stop the background task first: restart.ps1 -StopOnly
cd /d "%~dp0"
".venv\Scripts\python.exe" main.py
pause
