"""Telegram bot (long polling). UI only – all logic goes through BellService."""
from __future__ import annotations

import asyncio
import functools
import logging
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from telegram import (InlineKeyboardButton as B, InlineKeyboardMarkup as IKM, ReplyKeyboardMarkup,
                      Update)
from telegram.error import BadRequest
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler, ContextTypes,
                          MessageHandler, filters)

from ..core.labels import ACTION_HE
from ..core.redact import redact
from ..core.logic import DAY_NAMES_HE, fmt_secs, parse_dates, parse_range
from ..core.service import BellService

log = logging.getLogger(__name__)

BTN_RING = "🔔 צלצול עכשיו"
BTN_MUTE = "🔇 השתקה"
BTN_NEXT = "⏭ הצלצול הבא"
BTN_STATUS = "📊 סטטוס"
BTN_SCHED = "🗓 מערכות שעות"
BTN_HOLI = "🏖 ימי חופש"
BTN_SONG = "🎵 ניגון שיר"
BTN_STOP = "⏹ עצור השמעה"
BTN_STOP_OLD = "⏹ עצור ניגון"   # keyboards sent by older versions
BTN_RT = "🎼 החלפת צלצול"
BTN_VOL = "🔊 עוצמה"
BTN_ANN = "📣 כריזה"
BTN_LOG = "📜 יומן"

MAIN_KB = ReplyKeyboardMarkup(
    [[BTN_RING, BTN_MUTE], [BTN_NEXT, BTN_STATUS], [BTN_SCHED, BTN_HOLI],
     [BTN_SONG, BTN_STOP], [BTN_RT, BTN_VOL], [BTN_ANN, BTN_LOG]],
    resize_keyboard=True, is_persistent=True)

BATCH_WAIT = 2.5  # seconds to wait for more files before deciding single vs playlist
AUDIO_EXTS = {".mp3", ".wav", ".ogg", ".oga", ".m4a", ".aac", ".flac", ".opus", ".wma", ".mp4", ".webm"}
CANCEL = [B("❌ ביטול", callback_data="cancel")]


def _d(d: date) -> str:
    return f"{d:%d/%m} (יום {DAY_NAMES_HE[d.weekday()]})"


WD_SHORT = ["ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳", "א׳"]  # index = Python weekday (Mon=0)


def _days(days: list[int]) -> str:
    return " ".join(WD_SHORT[d] for d in days)


def _chunks(items, n):
    return [items[i:i + n] for i in range(0, len(items), n)]


def authorized(fn):
    @functools.wraps(fn)
    async def wrapper(self: "BellBot", update: Update, context: ContextTypes.DEFAULT_TYPE):
        chat = update.effective_chat
        if not chat or not self.svc.is_authorized(chat.id):
            user = update.effective_user
            self.svc.log_unauthorized(chat.id if chat else "?", user.full_name if user else "?",
                                      (update.effective_message.text or "") if update.effective_message else "")
            if update.callback_query:
                await update.callback_query.answer("אין הרשאה")
            elif update.effective_message:
                await update.effective_message.reply_text(f"⛔ אין הרשאה.\nמזהה הצ'אט שלך: {chat.id if chat else '?'}")
            return
        try:
            return await fn(self, update, context)
        except ValueError as e:
            await self._reply(update, f"⚠️ {e}")
        except Exception as e:
            log.exception("handler error")
            await self._reply(update, f"❌ שגיאה: {e}")
    return wrapper


class BellBot:
    def __init__(self, service: BellService):
        self.svc = service
        self.cfg = service.cfg
        self.incoming = self.cfg.data_dir / "incoming"
        self.incoming.mkdir(parents=True, exist_ok=True)
        self._tasks: set = set()

    # ---------- helpers ----------
    @staticmethod
    def actor(update: Update):
        u = update.effective_user
        return (str(u.id), u.full_name) if u else (str(update.effective_chat.id), "?")

    async def _reply(self, update: Update, text: str, markup=None):
        msg = update.effective_message
        if msg:
            await msg.reply_text(text, reply_markup=markup)

    async def _show(self, update: Update, text: str, markup=None):
        """Edit the inline message when coming from a button, else send a new one."""
        q = update.callback_query
        if q:
            try:
                await q.edit_message_text(text, reply_markup=markup)
                return
            except BadRequest as e:
                if "not modified" in str(e).lower():
                    return
        await self._reply(update, text, markup)

    def _too_late(self, update: Update) -> bool:
        msg = update.effective_message
        if not msg or update.callback_query:
            return False
        age = (datetime.now(timezone.utc) - msg.date).total_seconds()
        return age > self.cfg.late_command_seconds

    @staticmethod
    def _await(context, kind: str | None, **data):
        if kind is None:
            context.chat_data.pop("await", None)
        else:
            context.chat_data["await"] = {"kind": kind, **data}

    # ---------- build ----------
    def build(self, token: str | None = None) -> Application:
        app = Application.builder().token(token or self.svc.bot_token()).build()
        app.add_handler(CommandHandler("myid", self.cmd_myid))
        app.add_handler(CommandHandler(["start", "menu", "help"], self.cmd_start))
        app.add_handler(CommandHandler("status", self.cmd_status))
        app.add_handler(CommandHandler(["version", "about"], self.cmd_version))
        app.add_handler(CommandHandler("stop", self.cmd_stop))
        app.add_handler(CommandHandler("update", self.cmd_update))
        app.add_handler(CallbackQueryHandler(self.on_callback))
        app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO | filters.Document.ALL | filters.VIDEO_NOTE,
                                       self.on_file))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.on_text))
        app.add_error_handler(self.on_error)
        return app

    async def on_error(self, update, context):
        log.warning("telegram error: %s", context.error)

    async def _run_async(self, token: str):
        app = self.build(token)
        self.svc.set_bot_status("connecting")
        async with app:
            await app.start()
            await app.updater.start_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)
            self.svc.set_bot_status("online", "@" + app.bot.username)
            log.info("telegram bot polling as @%s", app.bot.username)
            while not self.svc.bot_changed.is_set():
                await asyncio.sleep(1)
            log.info("bot token changed – reconnecting")
            await app.updater.stop()
            await app.stop()

    def run_forever(self):
        """Never raises: waits for a token, retries without internet, reconnects when the token changes.
        Bells keep working regardless."""
        while True:
            self.svc.bot_changed.clear()
            token = self.svc.bot_token()
            if not token:
                self.svc.set_bot_status("off", error="לא הוגדר טוקן")
                self.svc.bot_changed.wait(5)
                continue
            try:
                asyncio.run(self._run_async(token))
                continue  # token changed – restart immediately
            except Exception as e:
                msg = str(e)
                bad = "unauthorized" in msg.lower() or "invalid token" in msg.lower() or "not found" in msg.lower()
                self.svc.set_bot_status("error", error="הטוקן שגוי" if bad else "אין חיבור לטלגרם – מנסה שוב")
                log.warning("bot stopped (%s), retrying in 30s", e)
            self.svc.bot_changed.wait(30)

    # ---------- commands ----------
    async def cmd_myid(self, update: Update, context):
        await update.effective_message.reply_text(f"מזהה הצ'אט: {update.effective_chat.id}")

    @authorized
    async def cmd_start(self, update: Update, context):
        self._await(context, None)
        await self._reply(update, f"🔔 מערכת הצלצולים – {self.cfg.school_name} (גרסה {self.svc.version})\n"
                                  "בחרו פעולה מהתפריט למטה.\n"
                                  "📣 הודעה קולית שתשלחו תושמע מיד ברמקולים.", MAIN_KB)

    @authorized
    async def cmd_update(self, update: Update, context):
        """'Update now': check the update source and install a newer signed version (admins only)."""
        if not self.svc.is_admin(update.effective_chat.id):
            return await self._reply(update, "⛔ רק מנהל יכול לעדכן את התוכנה.")
        status = await update.effective_message.reply_text("🔄 בודק אם יש גרסה חדשה...")
        res = await asyncio.to_thread(self.svc.check_for_update, self.actor(update), True, True)
        icon_ = {"installing": "⏳", "up_to_date": "✅", "error": "❌"}.get(res["status"], "ℹ️")
        extra = "\nאם משהו ייכשל – חוזרים לבד לגרסה הקודמת." if res["status"] == "installing" else ""
        await status.edit_text(f"{icon_} {res['message']}{extra}")

    @authorized
    async def cmd_stop(self, update: Update, context):
        await self.do_stop(update, context)

    @authorized
    async def cmd_version(self, update: Update, context):
        from ..version import changelog
        items = "\n".join("• " + c for c in changelog(self.cfg.app_dir).get(self.svc.version, []))
        ch = "בדיקה" if self.svc.update_settings()["channel"] == "beta" else "יציב"
        await self._reply(update, f"🏷 גרסה {self.svc.version} · ערוץ {ch}\n🆔 מזהה מכשיר: {self.svc.device_id}\n\n"
                                  f"מה חדש:\n{items}\n\n"
                                  "לעדכון: מנהל שולח לכאן את קובץ school-bells-update-X.zip")

    @authorized
    async def cmd_status(self, update: Update, context):
        await self.do_status(update, context)

    async def do_status(self, update: Update, context):
        await self._reply(update, self.svc.status_text(), MAIN_KB)

    # ---------- text ----------
    @authorized
    async def on_text(self, update: Update, context):
        text = update.effective_message.text.strip()
        main = {BTN_RING: self.do_ring, BTN_MUTE: self.menu_mute, BTN_NEXT: self.do_next,
                BTN_STATUS: self.do_status, BTN_SCHED: self.menu_schedules,
                BTN_HOLI: self.menu_holidays, BTN_SONG: self.ask_song, BTN_STOP: self.do_stop, BTN_STOP_OLD: self.do_stop,
                BTN_RT: self.menu_ringtone, BTN_VOL: self.menu_volume, BTN_ANN: self.ask_announce,
                BTN_LOG: self.do_log}
        if text in ("עדכן עכשיו", "🔄 עדכן עכשיו"):
            self._await(context, None)
            return await self.cmd_update.__wrapped__(self, update, context)
        if text in main:
            self._await(context, None)
            return await main[text](update, context)
        aw = context.chat_data.get("await")
        if aw:
            return await self.on_await_text(update, context, aw, text)
        await self._reply(update, "בחרו פעולה מהתפריט 👇", MAIN_KB)

    async def on_await_text(self, update: Update, context, aw: dict, text: str):
        kind, actor, svc = aw["kind"], self.actor(update), self.svc
        today = svc.now().date()
        if kind == "times_add":
            added, existing = svc.add_bells(aw["sid"], text, actor)
            self._await(context, None)
            msg = f"✅ נוספו: {', '.join(added)}" if added else "לא נוספו שעות חדשות"
            if existing:
                msg += f"\n(כבר היו קיימות: {', '.join(existing)})"
            await self._reply(update, msg)
            return await self.view_schedule(update, context, aw["sid"], new_message=True)
        if kind == "time_move":
            b, new = svc.move_bell(aw["bell_id"], text, actor)
            self._await(context, None)
            await self._reply(update, f"✅ {b['time']} הוזז ל-{new}")
            return await self.view_schedule(update, context, b["schedule_id"], new_message=True)
        if kind in ("sched_new", "sched_dup"):
            new_id = svc.create_schedule(text, actor, copy_from=aw.get("src"))
            self._await(context, None)
            await self._reply(update, f"✅ נוצרה מערכת '{text.strip()}'")
            return await self.view_schedule(update, context, new_id, new_message=True)
        if kind == "sched_rename":
            svc.rename_schedule(aw["sid"], text, actor)
            self._await(context, None)
            return await self.view_schedule(update, context, aw["sid"], new_message=True)
        if kind == "sched_date":
            dates = parse_dates(text, today)
            svc.set_date_schedule(dates, aw["sid"], actor)
            self._await(context, None)
            return await self._reply(update, f"✅ המערכת '{svc.schedule_name(aw['sid'])}' תופעל ב: "
                                             + ", ".join(_d(d) for d in dates) + "\nלמחרת חוזרים אוטומטית לקבועה.")
        if kind == "holiday":
            dates = parse_dates(text, today)
            svc.add_holidays(dates, actor)
            self._await(context, None)
            await self._reply(update, "✅ נוספו ימי חופש: " + ", ".join(_d(d) for d in dates))
            return await self.menu_holidays(update, context, new_message=True)
        if kind == "trim":
            return await self.send_trim_preview(update, context, aw["uid"], text)
        if kind in ("song", "ringtone", "announce"):
            return await self._reply(update, "מחכה לקובץ שמע 🎧 (או לחצו ביטול)", IKM([CANCEL]))
        self._await(context, None)

    # ---------- main actions ----------
    async def do_ring(self, update: Update, context):
        if self._too_late(update):
            return await self._reply(update, "⌛ הבקשה הגיעה באיחור ולא בוצעה.")
        self.svc.ring_now(self.actor(update))
        await self._reply(update, "🔔 צלצל!")

    async def do_next(self, update: Update, context):
        await self._reply(update, "⏭ הצלצול הבא: " + self.svc.next_bell_text(self.svc.next_bell()))

    async def do_stop(self, update: Update, context):
        self.svc.stop_all(self.actor(update))
        await self._reply(update, "⏹ ההשמעה נעצרה. הצלצולים הבאים ייצאו כרגיל.", MAIN_KB)

    async def do_log(self, update: Update, context):
        rows = self.svc.recent_log(25)
        lines = [redact(f"{r['ts'][5:16].replace('T', ' ')} | {r['actor_name']} | "
                        f"{ACTION_HE.get(r['action'], r['action'])} {r['details'] or ''}") for r in rows]
        await self._reply(update, "📜 פעולות אחרונות:\n" + ("\n".join(lines) or "ריק"))

    # ---------- mute ----------
    async def menu_mute(self, update: Update, context):
        st = self.svc.mute_state().describe(self.svc.now().date())
        kb = IKM([[B("🔕 צלצול אחד", callback_data="mute:next"), B("📅 היום", callback_data="mute:today")],
                  [B("⛔ עד שאחזיר", callback_data="mute:forever")],
                  [B("🔔 ביטול השתקה", callback_data="mute:off")]])
        await self._show(update, f"🔇 השתקה\nמצב נוכחי: {st}", kb)

    # ---------- schedules ----------
    async def menu_schedules(self, update: Update, context, new_message: bool = False):
        rows = self.svc.list_schedules()
        text = "🗓 מערכות שעות (באיזה ימים כל אחת מצלצלת)\nבחרו מערכת לצפייה, עריכה ושיוך לימים:"
        kb = [[B(f"{r['name']} ({r['count']})" + (f" · {_days(r['days'])}" if r["days"] else ""),
                 callback_data=f"sv:{r['id']}")] for r in rows]
        kb.append([B("➕ מערכת חדשה", callback_data="snew"), B("📅 מערכות לתאריכים", callback_data="ovr")])
        if new_message:
            return await self._reply(update, text, IKM(kb))
        await self._show(update, text, IKM(kb))

    async def view_schedule(self, update: Update, context, sid: int, new_message: bool = False):
        s = self.svc.get_schedule(sid)
        times = [b["time"] for b in s["bells"]]
        body = "\n".join(" · ".join(c) for c in _chunks(times, 5)) or "(אין שעות)"
        days = f"מצלצלת בימים: {_days(s['days'])}" if s["days"] else "לא משויכת לאף יום (רק לתאריכים)"
        text = f"🗓 מערכת: {s['name']}\n{days}\n{len(times)} צלצולים:\n{body}\n\nשיוך לימים – לחצו על יום (✅ = משויך):"
        order = [6, 0, 1, 2, 3, 4, 5]
        day_btns = [B(("✅" if wd in s["days"] else "") + WD_SHORT[wd], callback_data=f"swd:{sid}:{wd}") for wd in order]
        kb = IKM([
            day_btns,
            [B("➕ הוספת שעות", callback_data=f"sadd:{sid}"), B("➖ מחיקת שעה", callback_data=f"sdm:{sid}")],
            [B("↔️ הזזת שעה", callback_data=f"smm:{sid}")],
            [B("📅 הפעל לתאריך מסוים", callback_data=f"sdt:{sid}")],
            [B("📋 שכפול", callback_data=f"sdup:{sid}"), B("✏️ שינוי שם", callback_data=f"sren:{sid}"),
             B("🗑 מחיקה", callback_data=f"srm:{sid}")],
            [B("⬅️ חזרה", callback_data="slist")]])
        if new_message:
            return await self._reply(update, text, kb)
        await self._show(update, text, kb)

    async def bells_picker(self, update, sid: int, prefix: str, title: str):
        s = self.svc.get_schedule(sid)
        btns = [B(b["time"], callback_data=f"{prefix}:{b['id']}") for b in s["bells"]]
        kb = _chunks(btns, 4) + [[B("⬅️ חזרה", callback_data=f"sv:{sid}")]]
        await self._show(update, f"{title} – {s['name']}", IKM(kb))

    async def menu_overrides(self, update, context):
        rows = self.svc.list_date_schedules()
        text = "📅 מערכות לתאריכים (חוזרות לקבועה למחרת):\n" + (
            "\n".join(f"{_d(r['date'])} – {r['name']}" for r in rows) or "אין")
        kb = [[B(f"❌ {r['date']:%d/%m} {r['name']}", callback_data=f"ovd:{r['date'].isoformat()}")] for r in rows[:20]]
        kb.append([B("⬅️ חזרה", callback_data="slist")])
        await self._show(update, text, IKM(kb))

    # ---------- holidays ----------
    async def menu_holidays(self, update: Update, context, new_message: bool = False):
        rows = self.svc.list_holidays()
        spans = self.svc.upcoming_vacations(days=200)[:8]
        text = "🏖 החופשות הקרובות (אוטומטי לפי לוח החופשות, בלי צלצולים):\n" + ("\n".join(
            f"• {v['name']}: {v['from']:%d/%m}" + (f"–{v['to']:%d/%m}" if v["to"] != v["from"] else "") for v in spans) or "אין")
        text += ("\n\nימים שהוספתם ידנית מופיעים למטה (❌ להסרה)."
                 "\nלהוספה: היום / מחר / תאריך או טווח (24/12-26/12)."
                 "\nייבוא: שלחו לכאן קובץ CSV / Excel / ICS עם תאריכי חופשה."
                 "\nלביטול חופש אוטומטי ביום מסוים – בלוח השנה בממשק במחשב.")
        kb = [[B("🏖 היום", callback_data="hadd:0"), B("מחר", callback_data="hadd:1"),
               B("📅 תאריך/טווח", callback_data="hadd:ask")]]
        kb += _chunks([B(f"❌ {r['date']:%d/%m}", callback_data=f"hdel:{r['date'].isoformat()}") for r in rows[:24]], 4)
        if new_message:
            return await self._reply(update, text, IKM(kb))
        await self._show(update, text, IKM(kb))

    # ---------- volume ----------
    async def menu_volume(self, update: Update, context):
        v = self.svc.volumes()
        kb = IKM([[B("🔔 −10", callback_data="vol:bell:-10"), B(f"🔔 {v['bell']}%", callback_data="vol:test"),
                   B("🔔 +10", callback_data="vol:bell:10")],
                  [B("🎵 −10", callback_data="vol:music:-10"), B(f"🎵 {v['music']}%", callback_data="noop"),
                   B("🎵 +10", callback_data="vol:music:10")],
                  [B("🔊 בדיקת צלצול", callback_data="vol:test")]])
        await self._show(update, f"🔊 עוצמה\n🔔 צלצול: {v['bell']}%\n🎵 שירים וכריזה: {v['music']}%", kb)

    # ---------- ringtones ----------
    async def menu_ringtone(self, update: Update, context):
        svc = self.svc
        rt, up, mode = svc.active_ringtone(), svc.upcoming_ringtone(), svc.ringtone_mode()
        n = len(svc.rotation())
        text = (f"🎼 מצב: {'🔀 אקראי מהסבב' if mode == 'random' else '📌 צלצול קבוע'}\n"
                f"צלצול קבוע: {rt['name'] if rt else 'ברירת מחדל'}\nבסבב: {n} צלצולים\n"
                f"הצלצול הבא יתנגן: {up['name'] if up else 'ברירת מחדל'}")
        if mode == "random" and n == 0:
            text += "\n⚠️ אין צלצולים בסבב – מתנגן הצלצול הקבוע. סמנו צלצולים בספרייה (🔁)."
        kb = IKM([[B("📤 העלאת צלצול חדש", callback_data="rtnew")],
                  [B("📚 ספרייה וסבב", callback_data="rtlib"), B("↩️ חזרה לקודם", callback_data="rtprev")],
                  [B("📌 עבור לצלצול קבוע" if mode == "random" else "🔀 עבור לאקראי",
                     callback_data="rtmode:" + ("fixed" if mode == "random" else "random"))],
                  [B("🔊 השמע את הצלצול הבא", callback_data="vol:test")]])
        await self._show(update, text, kb)

    async def menu_rt_library(self, update: Update, context):
        rows = self.svc.list_ringtones()
        kb = []
        for r in rows[:15]:
            kb.append([B(("✅ " if r["active"] else "▫️ ") + r["name"][:26], callback_data=f"rtset:{r['id']}"),
                       B("🔁" if r["in_rotation"] else "➕", callback_data=f"rtrot:{r['id']}:{0 if r['in_rotation'] else 1}"),
                       B("🔊", callback_data=f"rtplay:{r['id']}"), B("🗑", callback_data=f"rtdel:{r['id']}")])
        kb.append([B("⬅️ חזרה", callback_data="rtmenu")])
        await self._show(update, "📚 ספריית צלצולים\nשם = קביעה כצלצול קבוע · 🔁 בסבב / ➕ הוספה לסבב האקראי · "
                                 "🔊 השמעה ברמקולים", IKM(kb))

    async def ask_song(self, update: Update, context):
        """'Play song' = the song library: tap a song to play it, pick several for a playlist, or upload."""
        self._await(context, None)
        context.chat_data["sel"] = []
        await self.menu_library(update, context, 0, select=False, new_message=True)

    LIB_PAGE = 8

    async def menu_library(self, update, context, page: int, select: bool, new_message: bool = False):
        songs = self.svc.list_songs()
        sel = context.chat_data.setdefault("sel", [])
        pages = max(1, -(-len(songs) // self.LIB_PAGE))
        page = max(0, min(page, pages - 1))
        chunk = songs[page * self.LIB_PAGE:(page + 1) * self.LIB_PAGE]
        if select:
            text = f"☑️ בחירת שירים לפלייליסט – נבחרו {len(sel)}\nלחצו על שירים לסימון, ואז 'נגן נבחרים'."
        else:
            text = (f"🎵 ספריית שירים ({len(songs)})\nלחצו על שיר כדי לנגן אותו ברמקולים."
                    if songs else "🎵 הספרייה ריקה. לחצו 'העלה שיר חדש' ושלחו קובץ שמע.")
        cur = self.svc.playlist_state()["current"]
        if cur:
            text += f"\n▶️ מתנגן עכשיו: {cur['title']}"
        kb = []
        for x in chunk:
            label = (x["name"][:34] + (" ✂️" if x["trim_end"] is not None else ""))
            if select:
                kb.append([B(("✅ " if x["id"] in sel else "▫️ ") + label, callback_data=f"lt:{x['id']}:{page}")])
            else:
                kb.append([B("▶️ " + label, callback_data=f"sp:{x['id']}")])
        mode = "lsel" if select else "lib"
        if pages > 1:
            nav = []
            if page > 0:
                nav.append(B("⬅️ הקודם", callback_data=f"{mode}:{page - 1}"))
            nav.append(B(f"{page + 1}/{pages}", callback_data="noop"))
            if page < pages - 1:
                nav.append(B("הבא ➡️", callback_data=f"{mode}:{page + 1}"))
            kb.append(nav)
        if select:
            kb.append([B(f"▶️ נגן נבחרים ({len(sel)})", callback_data="lps"), B("➕ לתור", callback_data="lpq")])
            kb.append([B("⬅️ חזרה לספרייה", callback_data=f"lib:{page}")])
        else:
            if songs:
                kb.append([B("▶️ נגן הכול", callback_data="lall:0"), B("🔀 ערבוב", callback_data="lall:1")])
                kb.append([B("☑️ בחירה לפלייליסט", callback_data=f"lsel:{page}")])
            kb.append([B("⬆️ העלה שיר חדש", callback_data="lup")] + ([B("🎶 תור", callback_data="pl")] if cur else []))
        if new_message:
            return await self._reply(update, text, IKM(kb))
        await self._show(update, text, IKM(kb))

    async def ask_announce(self, update: Update, context):
        await self._reply(update, "📣 הקליטו ושלחו הודעה קולית (לחיצה ארוכה על המיקרופון) – היא תושמע מיד ברמקולים.")

    # ---------- files ----------
    @authorized
    async def on_file(self, update: Update, context):
        msg = update.effective_message
        aw = context.chat_data.get("await") or {}
        kind = aw.get("kind")
        if msg.voice:
            f, ext, title = msg.voice, ".ogg", "הודעה קולית"
        elif msg.video_note:
            f, ext, title = msg.video_note, ".mp4", "וידאו"
        elif msg.audio:
            f = msg.audio
            ext = Path(f.file_name or "a.mp3").suffix.lower() or ".mp3"
            title = f.title or Path(f.file_name or "שיר").stem
        else:
            f = msg.document
            ext = Path(f.file_name or "").suffix.lower()
            if ext == ".zip" or (f.mime_type or "") in ("application/zip", "application/x-zip-compressed"):
                return await self.handle_update_file(update, context, f)
            if ext in (".csv", ".xlsx", ".ics", ".xls"):
                return await self.handle_holiday_file(update, context, f, ext)
            if not ((f.mime_type or "").startswith("audio") or ext in AUDIO_EXTS):
                return await self._reply(update, "⚠️ זה לא נראה כמו קובץ שמע.")
            title = Path(f.file_name or "קובץ").stem
        if f.file_size and f.file_size > 20 * 1024 * 1024:
            return await self._reply(update, "⚠️ הקובץ גדול מ-20MB (מגבלת טלגרם לבוטים).")

        if (msg.voice or msg.video_note) and kind != "ringtone":
            if self._too_late(update):
                return await self._reply(update, "⌛ הכריזה הגיעה באיחור ולא הושמעה.")
            return await self.handle_announcement(update, context, f, ext)

        # Several files sent together arrive as separate messages: collect them for a moment,
        # then decide: one file -> trim/play/ringtone menu, several -> playlist.
        batch = context.chat_data.setdefault("batch", {"items": [], "gen": 0})
        batch["gen"] += 1
        gen = batch["gen"]
        src = await self._download(context, f.file_id, ext)
        try:
            u = await asyncio.to_thread(self.svc.stage_upload, src, title, self.actor(update), kind != "ringtone")
        finally:
            src.unlink(missing_ok=True)
        batch["items"].append(u)
        if batch["gen"] == gen:
            task = asyncio.create_task(self._flush_batch(update, context, gen))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    async def _flush_batch(self, update, context, gen: int):
        await asyncio.sleep(BATCH_WAIT)
        batch = context.chat_data.get("batch") or {}
        if batch.get("gen") != gen or not batch.get("items"):
            return
        items, batch["items"] = batch["items"], []
        kind = (context.chat_data.get("await") or {}).get("kind")
        try:
            await self._handle_uploads(update, context, items, kind)
        except ValueError as e:
            await self._reply(update, f"⚠️ {e}")
        except Exception as e:
            log.exception("upload handling failed")
            await self._reply(update, f"❌ שגיאה: {e}")

    async def _handle_uploads(self, update, context, items: list[dict], kind: str | None):
        actor = self.actor(update)
        if len(items) > 1 and kind != "ringtone":
            self._await(context, None)
            self.svc.play_uploads([u["id"] for u in items], actor)
            return await self._reply(update, self.playlist_text(), self.playlist_kb())
        u = items[0]
        if len(items) > 1:
            await self._reply(update, "לצלצול צריך קובץ אחד – משתמשים בראשון.")
        if kind == "song":
            self._await(context, None)
            self.svc.play_uploads([u["id"]], actor)
            return await self._reply(update, f"▶️ מתנגן: {u['name']}\n(אם יגיע זמן צלצול – השיר ייעצר)",
                                     self.song_kb(u["id"]))
        self._await(context, "trim", uid=u["id"], mode=kind or "any")
        dur = fmt_secs(u["duration"]) if u["duration"] else "?"
        text = (f"🎧 {u['name']} ({dur})\n\n✂️ לחיתוך: שלחו טווח שניות, למשל 20-46 או 0:20-0:46\n"
                "תקבלו את הקטע לשמיעה לפני שבוחרים.")
        if kind == "ringtone":
            kb = [[B("🎼 בלי חיתוך – צלצול מתחילת הקובץ", callback_data=f"urc:{u['id']}")], CANCEL]
        else:
            kb = [[B("▶️ נגן עכשיו", callback_data=f"up:{u['id']}"), B("🎼 קבע כצלצול", callback_data=f"urc:{u['id']}")],
                  CANCEL]
        await self._reply(update, text, IKM(kb))

    async def send_trim_preview(self, update, context, uid: int, text: str):
        u = self.svc.get_upload(uid)
        start, end = parse_range(text, u["duration"] or None)
        status = await update.effective_message.reply_text("⏳ חותך...")
        clip, dur = await asyncio.to_thread(self.svc.make_clip, uid, start, end)
        preview = await asyncio.to_thread(self.svc.audio.make_preview, clip, clip.with_suffix(".mp3"))
        await status.delete()
        rng = f"{start:g}:{end:g}"
        kb = IKM([[B("🎼 שמור כצלצול קבוע", callback_data=f"ur:{uid}:{rng}")],
                  [B("▶️ נגן כשיר עכשיו", callback_data=f"up:{uid}:{rng}")],
                  [B("✂️ חיתוך אחר – פשוט שלחו טווח חדש", callback_data="noop")]])
        cap = f"✂️ {u['name']}: {fmt_secs(start)}–{fmt_secs(end)} ({dur:.1f} שנ')"
        with open(preview or clip, "rb") as fh:
            if preview:
                await update.effective_message.reply_audio(fh, title=f"{u['name']} (קטע)", caption=cap, reply_markup=kb)
            else:
                await update.effective_message.reply_document(fh, caption=cap, reply_markup=kb)

    def song_kb(self, uid: int | None):
        rows = [[B("⏹ עצור", callback_data="stop"), B("🎶 תור", callback_data="pl")]]
        if uid:
            rows.append([B("✂️ חיתוך", callback_data=f"ut:{uid}"), B("🎼 הפוך לצלצול", callback_data=f"urc:{uid}")])
        return IKM(rows)

    def playlist_text(self) -> str:
        st = self.svc.playlist_state()
        if not st["current"]:
            return "🎶 שום דבר לא מתנגן כרגע."
        lines = ["🎶 פלייליסט", f"▶️ עכשיו: {st['current']['title']}"]
        if st["queue"]:
            lines.append("\nבתור:")
            lines += [f"{i}. {t['title']}" for i, t in enumerate(st["queue"][:20], 1)]
        lines.append("\n(צלצול שמגיע עוצר את כל הפלייליסט)")
        return "\n".join(lines)

    def playlist_kb(self):
        st = self.svc.playlist_state()
        rows = [[B("⏭ הבא", callback_data="pln"), B("⏹ עצור הכול", callback_data="stop"), B("🔄", callback_data="pl")]]
        cur = st["current"]
        if cur and cur.get("upload_id"):
            rows.append([B("🎼 השיר הנוכחי לצלצול", callback_data=f"urc:{cur['upload_id']}")])
        return IKM(rows)

    # ---------- software update (admins only) ----------
    async def handle_update_file(self, update, context, f):
        if not self.svc.is_admin(update.effective_chat.id):
            self.svc.log_unauthorized(update.effective_chat.id, update.effective_user.full_name, "ניסיון עדכון תוכנה")
            return await self._reply(update, "⛔ רק מנהל יכול להתקין עדכוני תוכנה.")
        status = await update.effective_message.reply_text("⏳ בודק את קובץ העדכון (חתימה וגרסה)...")
        inc = self.svc.updates_dir / "incoming"
        inc.mkdir(parents=True, exist_ok=True)
        path = inc / f"{uuid.uuid4().hex}.zip"
        await (await context.bot.get_file(f.file_id)).download_to_drive(path)
        try:   # fire-and-forget: a verified package is installed right away
            info = await asyncio.to_thread(self.svc.inspect_update, path, self.actor(update))
            await asyncio.to_thread(self.svc.apply_update, info["token"], self.actor(update))
        except ValueError as e:
            path.unlink(missing_ok=True)
            return await status.edit_text(f"❌ העדכון לא הותקן: {e}")
        await status.edit_text(f"📦 גרסה {info['version']} (מותקנת {info['current']}) – חתימה מקורית ✓\n"
                               "⏳ מתקין עכשיו. אם משהו ייכשל – חוזרים לבד לגרסה הקודמת.")

    async def handle_holiday_file(self, update, context, f, ext):
        src = await self._download(context, f.file_id, ext)
        try:
            res = await asyncio.to_thread(self.svc.import_holidays, f.file_name or f"file{ext}",
                                          src.read_bytes(), self.actor(update))
        except ValueError as e:
            return await self._reply(update, f"⚠️ {e}")
        finally:
            src.unlink(missing_ok=True)
        sample = "\n".join(f"• {date.fromisoformat(i['date']):%d/%m/%y} {i['name']}" for i in res["items"][:12])
        more = f"\n… ועוד {res['count'] - 12}" if res["count"] > 12 else ""
        await self._reply(update, f"✅ יובאו {res['count']} ימי חופש:\n{sample}{more}",
                          IKM([[B("↩️ ביטול הייבוא", callback_data=f"himpu:{res['tag']}")]]))

    async def _download(self, context, file_id: str, ext: str) -> Path:
        tg_file = await context.bot.get_file(file_id)
        path = self.incoming / f"{uuid.uuid4().hex}{ext}"
        await tg_file.download_to_drive(path)
        return path

    async def handle_announcement(self, update, context, f, ext):
        status = await update.effective_message.reply_text("⏳ מכין לניגון...")
        src = await self._download(context, f.file_id, ext)
        try:
            prepared = await asyncio.to_thread(self.svc.prepare_media, src, True)
        finally:
            src.unlink(missing_ok=True)
        self.svc.play_announcement(prepared, self.actor(update))
        await status.edit_text("📣 הכריזה מושמעת ברמקולים", reply_markup=IKM([[B("⏹ עצור", callback_data="stop")]]))

    async def ringtone_confirm(self, update, context, uid: int):
        """Full file (capped) -> normalized preview -> confirm before it becomes the bell."""
        status = await update.effective_message.reply_text("⏳ מעבד: נרמול עוצמה...")
        rt = await asyncio.to_thread(self.svc.ringtone_from_upload, uid, self.actor(update), None, None, None, False)
        await status.delete()
        kb = IKM([[B("✅ קבע כצלצול קבוע", callback_data=f"rtok:{rt['id']}")],
                  [B("🔊 נסה ברמקולים", callback_data=f"rtplay:{rt['id']}"),
                   B("❌ בטל", callback_data=f"rtno:{rt['id']}")]])
        caption = (f"🎧 האזינו לצלצול אחרי עיבוד ({rt['duration']:.1f} שניות).\nלאשר?\n"
                   f"(רוצים קטע אחר? שלחו טווח, למשל 20-46)")
        self._await(context, "trim", uid=uid, mode="ringtone")
        preview = await asyncio.to_thread(self.svc.audio.make_preview, rt["abs_path"],
                                          self.svc.media_dir / f"pv_{rt['id']}.mp3")
        with open(preview or rt["abs_path"], "rb") as fh:
            if preview:
                await update.effective_message.reply_audio(fh, title=rt["name"], caption=caption, reply_markup=kb)
            else:
                await update.effective_message.reply_document(fh, caption=caption, reply_markup=kb)

    # ---------- callbacks ----------
    @authorized
    async def on_callback(self, update: Update, context):
        q = update.callback_query
        data = q.data or ""
        cmd, _, arg = data.partition(":")
        svc, actor = self.svc, self.actor(update)
        today = svc.now().date()
        answer = None

        if cmd == "noop":
            pass
        elif cmd == "cancel":
            self._await(context, None)
            await self._show(update, "בוטל.")
        elif cmd == "stop":
            svc.stop_all(actor)
            answer = "⏹ נעצר"
            try:
                await q.edit_message_reply_markup(None)
            except BadRequest:
                pass
            await update.effective_message.reply_text("⏹ הניגון נעצר (כולל התור)")
        elif cmd == "mute":
            st = svc.set_mute(arg, actor)
            answer = "עודכן"
            await self._show(update, f"🔇 השתקה – מצב נוכחי: {st}")
        # schedules
        elif cmd == "slist":
            await self.menu_schedules(update, context)
        elif cmd == "sv":
            await self.view_schedule(update, context, int(arg))
        elif cmd == "snew":
            self._await(context, "sched_new")
            await self._show(update, "✏️ כתבו שם למערכת החדשה (היא תיווצר ריקה; לשכפול – בחרו מערכת ולחצו 'שכפול')",
                             IKM([CANCEL]))
        elif cmd == "sadd":
            self._await(context, "times_add", sid=int(arg))
            await self._show(update, "➕ כתבו שעה אחת או כמה, למשל:\n08:00 08:45 9:30", IKM([CANCEL]))
        elif cmd == "sdm":
            await self.bells_picker(update, int(arg), "sdel", "➖ בחרו שעה למחיקה")
        elif cmd == "sdel":
            b = svc.delete_bell(int(arg), actor)
            answer = f"נמחק {b['time']}"
            await self.bells_picker(update, b["schedule_id"], "sdel", "➖ בחרו שעה למחיקה")
        elif cmd == "smm":
            await self.bells_picker(update, int(arg), "smv", "↔️ בחרו שעה להזזה")
        elif cmd == "smv":
            b = svc.db.get_bell(svc.sid, int(arg))
            self._await(context, "time_move", bell_id=int(arg))
            await self._show(update, f"↔️ לאיזו שעה להזיז את {b['time']}? (למשל 10:35)", IKM([CANCEL]))
        elif cmd == "swd":
            sid_s, _, wd_s = arg.partition(":")
            sid, wd = int(sid_s), int(wd_s)
            cur = svc.weekday_map().get(wd)
            svc.set_weekday(wd, None if cur == sid else sid, actor)
            answer = "עודכן"
            await self.view_schedule(update, context, sid)
        elif cmd == "sdt":
            sid = int(arg)
            await self._show(update, f"📅 מתי להפעיל את '{svc.schedule_name(sid)}'?\n(למחרת חוזרים לקבועה אוטומטית)",
                             IKM([[B("היום", callback_data=f"sdtd:{sid}:0"), B("מחר", callback_data=f"sdtd:{sid}:1")],
                                  [B("📅 תאריך אחר / טווח", callback_data=f"sdtd:{sid}:ask")],
                                  [B("⬅️ חזרה", callback_data=f"sv:{sid}")]]))
        elif cmd == "sdtd":
            sid_s, _, when = arg.partition(":")
            sid = int(sid_s)
            if when == "ask":
                self._await(context, "sched_date", sid=sid)
                await self._show(update, "כתבו תאריך (24/12) או טווח (24/12-26/12)", IKM([CANCEL]))
            else:
                d = today + timedelta(days=int(when))
                svc.set_date_schedule([d], sid, actor)
                await self._show(update, f"✅ '{svc.schedule_name(sid)}' תופעל ב-{_d(d)}. למחרת – חזרה לקבועה.")
        elif cmd == "sdup":
            self._await(context, "sched_dup", src=int(arg))
            await self._show(update, f"📋 כתבו שם לעותק של '{svc.schedule_name(int(arg))}'", IKM([CANCEL]))
        elif cmd == "sren":
            self._await(context, "sched_rename", sid=int(arg))
            await self._show(update, "✏️ כתבו שם חדש", IKM([CANCEL]))
        elif cmd == "srm":
            await self._show(update, f"🗑 למחוק את '{svc.schedule_name(int(arg))}'?",
                             IKM([[B("כן, מחק", callback_data=f"srmok:{arg}"), B("לא", callback_data=f"sv:{arg}")]]))
        elif cmd == "srmok":
            svc.delete_schedule(int(arg), actor)
            answer = "נמחקה"
            await self.menu_schedules(update, context)
        elif cmd == "ovr":
            await self.menu_overrides(update, context)
        elif cmd == "ovd":
            svc.remove_date_schedule(date.fromisoformat(arg), actor)
            await self.menu_overrides(update, context)
        # holidays
        elif cmd == "hadd":
            if arg == "ask":
                self._await(context, "holiday")
                await self._show(update, "כתבו תאריך (24/12), כמה תאריכים, או טווח (24/12-26/12)", IKM([CANCEL]))
            else:
                svc.add_holidays([today + timedelta(days=int(arg))], actor)
                await self.menu_holidays(update, context)
        elif cmd == "hdel":
            svc.remove_holiday(date.fromisoformat(arg), actor)
            await self.menu_holidays(update, context)
        # volume
        elif cmd == "vol":
            if arg == "test":
                svc.ring_now(actor)
                answer = "🔔"
            else:
                kind, _, delta = arg.partition(":")
                svc.set_volume(kind, svc.volumes()[kind] + int(delta), actor)
                await self.menu_volume(update, context)
        # ringtones
        elif cmd == "rtmode":
            svc.set_ringtone_mode(arg, actor)
            await self.menu_ringtone(update, context)
        elif cmd == "rtrot":
            rid_s, _, on = arg.partition(":")
            svc.set_rotation(int(rid_s), on == "1", actor)
            await self.menu_rt_library(update, context)
        elif cmd == "himpu":
            n = svc.undo_import(arg, actor)
            await self._show(update, f"↩️ הייבוא בוטל ({n} ימים הוסרו).")
        elif cmd == "rtmenu":
            await self.menu_ringtone(update, context)
        elif cmd == "rtnew":
            self._await(context, "ringtone")
            await self._show(update, f"📤 שלחו קובץ שמע (mp3/wav/m4a/הודעה קולית).\n"
                                     "העוצמה תנורמל, והצלצול יתנגן באורך המלא. אפשר לחתוך קטע אחרי ההעלאה.", IKM([CANCEL]))
        elif cmd == "rtlib":
            await self.menu_rt_library(update, context)
        elif cmd == "rtprev":
            rt = svc.revert_ringtone(actor)
            await self._show(update, f"↩️ חזרנו לצלצול: {rt['name']}")
        elif cmd in ("rtok", "rtset"):
            rt = svc.activate_ringtone(int(arg), actor)
            answer = "נקבע"
            if cmd == "rtok":
                await q.edit_message_caption(f"✅ '{rt['name']}' הוא הצלצול הקבוע מעכשיו.")
            else:
                await self.menu_rt_library(update, context)
        elif cmd == "rtplay":
            svc.preview_ringtone(int(arg), actor)
            answer = "🔊 מושמע ברמקולים"
        elif cmd == "rtno":
            svc.delete_ringtone(int(arg), actor)
            await q.edit_message_caption("❌ בוטל. הצלצול הקודם נשאר.")
        elif cmd == "rtdel":
            svc.delete_ringtone(int(arg), actor)
            await self.menu_rt_library(update, context)
        elif cmd == "upd":
            if not svc.is_admin(update.effective_chat.id):
                answer = "רק מנהל"
            else:
                info = svc.apply_update(arg, actor)
                await self._show(update, f"⏳ מתקין את גרסה {info['version']}...\n"
                                         "המערכת תופעל מחדש תוך כחצי דקה. תתקבל כאן הודעה כשהעדכון יסתיים.")
        # uploads: play / ringtone / trim / playlist
        elif cmd in ("up", "ur"):
            parts = arg.split(":")
            uid = int(parts[0])
            start, end = (float(parts[1]), float(parts[2])) if len(parts) == 3 else (None, None)
            if cmd == "up":
                svc.play_uploads([uid], actor, start, end)
                answer = "▶️ מתנגן"
                await update.effective_message.reply_text(
                    f"▶️ מתנגן: {svc.playlist_state()['current']['title']}", reply_markup=self.song_kb(uid))
            else:
                rt = await asyncio.to_thread(svc.ringtone_from_upload, uid, actor, start, end)
                self._await(context, None)
                answer = "נשמר"
                await update.effective_message.reply_text(
                    f"✅ '{rt['name']}' הוא הצלצול הקבוע מעכשיו ({rt['duration']:.1f} שנ').")
        elif cmd == "urc":
            await self.ringtone_confirm(update, context, int(arg))
        elif cmd == "ut":
            u = svc.get_upload(int(arg))
            self._await(context, "trim", uid=u["id"], mode="any")
            await update.effective_message.reply_text(
                f"✂️ {u['name']} ({fmt_secs(u['duration'])})\nשלחו טווח שניות, למשל 20-46 או 0:20-0:46", reply_markup=IKM([CANCEL]))
        # song library
        elif cmd in ("lib", "lsel"):
            await self.menu_library(update, context, int(arg or 0), select=cmd == "lsel")
        elif cmd == "lt":
            sid_s, _, pg = arg.partition(":")
            sel = context.chat_data.setdefault("sel", [])
            i = int(sid_s)
            sel.remove(i) if i in sel else sel.append(i)
            await self.menu_library(update, context, int(pg or 0), select=True)
        elif cmd in ("lps", "lpq"):
            sel = context.chat_data.get("sel") or []
            if not sel:
                answer = "לא נבחרו שירים"
            else:
                st = svc.play_library(actor, sel) if cmd == "lps" else svc.enqueue(sel, actor)
                context.chat_data["sel"] = []
                await self._show(update, self.playlist_text(), self.playlist_kb())
        elif cmd == "lall":
            svc.play_library(actor, shuffle=arg == "1")
            await self._show(update, self.playlist_text(), self.playlist_kb())
        elif cmd == "sp":
            svc.play_uploads([int(arg)], actor)
            answer = "▶️ מתנגן"
            await update.effective_message.reply_text(
                f"▶️ מתנגן: {svc.playlist_state()['current']['title']}", reply_markup=self.song_kb(int(arg)))
        elif cmd == "lup":
            self._await(context, "song")
            await self._show(update, "⬆️ שלחו קובץ שמע (או כמה יחד לפלייליסט). הוא יישמר בספרייה ויתנגן מיד.",
                             IKM([CANCEL]))
        elif cmd == "pl":
            await self._show(update, self.playlist_text(), self.playlist_kb())
        elif cmd == "pln":
            svc.playlist_next(actor)
            await self._show(update, self.playlist_text(), self.playlist_kb())
        try:
            await q.answer(answer)
        except BadRequest:
            pass
