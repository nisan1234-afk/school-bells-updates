import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT))
HAS_GIT = (ROOT / ".git").exists() and shutil.which("git") and subprocess.run(
    ["git", "rev-parse", "-q", "--verify", "v1.1"], cwd=ROOT, capture_output=True).returncode == 0


@pytest.mark.skipif(not HAS_GIT, reason="needs git history (dev machine)")
def test_publish_beta_then_promote(tmp_path):
    import os
    import publish
    from bells.update import ed25519, package
    key = os.urandom(32)
    man = publish.publish_beta(tmp_path, key.hex(), "v1.1", "1.1", require_clean=False)
    beta = man["channels"]["beta"]
    assert (tmp_path / beta["file"]).exists() and (tmp_path / beta["full_installer"]).exists()
    assert "stable" not in man["channels"]
    app = tmp_path / "app"
    (app / "bells" / "web").mkdir(parents=True)
    (app / "main.py").write_text("")
    info = package.inspect(tmp_path / beta["file"], app, [ed25519.public_key(key).hex()])
    assert info["version"] == beta["version"]
    man = publish.promote(tmp_path, key.hex())
    assert man["channels"]["stable"]["version"] == beta["version"]
    with pytest.raises(SystemExit):
        publish.promote(tmp_path, key.hex())            # same version is already stable
    with pytest.raises(SystemExit):
        publish.publish_beta(tmp_path, key.hex(), "v1.1", "1.1", require_clean=False)  # not newer than stable
    assert json.loads((tmp_path / "manifest.json").read_text())["app"] == "school-bells"


def test_signed_manifest_and_beta_devices(tmp_path, monkeypatch):
    import os
    import publish
    from bells.update import ed25519, remote
    key = os.urandom(32)
    pub = [ed25519.public_key(key).hex()]
    man = {"app": "school-bells", "format": 1, "channels": {
        "stable": {"version": "1.3", "file": "files/s.zip"}, "beta": {"version": "1.3.1", "file": "files/b.zip"}}}
    publish.save(tmp_path, man, key.hex())
    publish.device_add(tmp_path, key.hex(), "sb-abcd-efgh-ijkl", "מחשב בדיקה")
    with pytest.raises(SystemExit):
        publish.device_add(tmp_path, key.hex(), "not-an-id")
    files = {"manifest.json": (tmp_path / "manifest.json").read_bytes(),
             "manifest.json.sig": (tmp_path / "manifest.json.sig").read_bytes()}
    assert key.hex() not in (files["manifest.json"] + files["manifest.json.sig"]).decode()   # the key is never written
    monkeypatch.setattr(remote, "_get", lambda url, limit, timeout=30: files[url.rsplit("/", 1)[-1]])
    url = "https://example.org/feed/manifest.json"
    m = remote.fetch_manifest(url, pub)
    assert remote.choose_entry(m, url, "SB-ABCD-EFGH-IJKL")[0] == "beta"
    assert remote.choose_entry(m, url, "SB-ZZZZ-ZZZZ-ZZZZ")[0] == "stable"            # everyone else: stable
    assert remote.choose_entry(m, url, "SB-ABCD-EFGH-IJKL")[1]["url"] == "https://example.org/feed/files/b.zip"
    with pytest.raises(remote.ManifestRejected):
        remote.fetch_manifest(url, [ed25519.public_key(os.urandom(32)).hex()])        # foreign signer
    files["manifest.json"] = files["manifest.json"].replace(b"ABCD", b"WXYZ")        # tampered list
    with pytest.raises(remote.ManifestRejected):
        remote.fetch_manifest(url, pub)
    publish.device_remove(tmp_path, key.hex(), "SB-ABCD-EFGH-IJKL")
    assert publish.load(tmp_path)["beta_devices"] == []
