"""End-to-end: a real 1.1 install (from git) is updated while running, exactly like on the school PC.

1.1 -> 1.2 manually (what update.bat runs), 1.2 -> 1.3 from the UI API (signature checked by the app),
rejections (older / tampered / foreign key), and a broken 1.4 that must roll back by itself.
Linux/dev only: needs git history (skipped on the school PC).
"""
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

HAS_GIT = (ROOT / ".git").exists() and shutil.which("git") and subprocess.run(
    ["git", "rev-parse", "-q", "--verify", "v1.1"], cwd=ROOT, capture_output=True).returncode == 0
pytestmark = pytest.mark.skipif(os.name == "nt" or not HAS_GIT, reason="needs git history (dev machine)")


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def http(port, method, path, body=None, raw=None, ctype="application/json"):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else (b"{}" if method == "POST" else None))
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, method=method,
                                 headers={"X-Bells": "1", "Content-Type": ctype})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")
    except OSError:
        return 0, None


def wait_for(cond, timeout, what):
    end = time.time() + timeout
    while time.time() < end:
        v = cond()
        if v:
            return v
        time.sleep(1)
    raise AssertionError(f"timeout waiting for {what}")


def health(port):
    code, j = http(port, "GET", "/api/health")
    return j.get("version") if code == 200 else None


def test_full_update_cycle(tmp_path, monkeypatch):
    V = (ROOT / "VERSION").read_text().strip()        # the version being shipped (installed over 1.1)
    import build_update as bu
    from bells.update import apply_update as au
    from bells.update import ed25519

    key = os.urandom(32)
    pub = ed25519.public_key(key).hex()
    app = tmp_path / "SchoolBells"
    app.mkdir()
    tar = subprocess.run(["git", "archive", "--format=tar", "v1.1"], cwd=ROOT, capture_output=True, check=True).stdout
    tarfile.open(fileobj=io.BytesIO(tar)).extractall(app, filter="data")
    port, lock_port = free_port(), free_port()
    cfg = (app / "config.example.toml").read_text(encoding="utf-8")
    cfg = cfg.replace("lock_port = 47831", f"lock_port = {lock_port}").replace("port = 8787", f"port = {port}")
    (app / "config.toml").write_text(cfg, encoding="utf-8")
    cfg_bytes = (app / "config.toml").read_bytes()
    monkeypatch.setenv("BELLS_UPDATE_HEALTH_TIMEOUT", "25")
    log = au.Log(tmp_path / "test.log")
    au.start_app(app, log)
    try:
        wait_for(lambda: http(port, "GET", "/api/state")[0] == 200, 40, "1.1 app")
        assert health(port) is None                                    # 1.1 has no /api/health
        assert http(port, "POST", "/api/calendar/day", {"date": "2030-01-02", "mode": "holiday"})[0] == 200
        http(port, "POST", "/api/settings/users", {"chat_id": "777", "name": "המזכירה"})

        # ---- 1) manual update 1.1 -> 1.2 (what update.bat does) ----
        files, deleted = bu.changed_files("v1.1")
        payload = {p: bu.head_bytes(p) for p in files}
        payload["bells/update/keys.py"] = f'TRUSTED_PUBLIC_KEYS = ["{pub}"]\n'.encode()   # vendor = test key
        z12 = bu.write_package(tmp_path / "dist", V, payload, deleted, bu.head_scripts(), key.hex(), "1.1", ["x"])
        with zipfile.ZipFile(z12) as z:
            z.extractall(app)                                          # user extracts into the app folder
        pkg = app / f"school-bells-update-{V}"
        r = subprocess.run([sys.executable, "-I", str(pkg / "apply_update.py"), "--app-dir", str(app),
                            "--package-dir", str(pkg), "--health-timeout", "40"], capture_output=True, text=True)
        assert r.returncode == 0, r.stdout + r.stderr
        assert health(port) == V
        assert (app / "config.toml").read_bytes() == cfg_bytes         # config untouched
        cal = http(port, "GET", "/api/calendar?month=2030-01")[1]
        assert cal["days"][1]["reason"] == "holiday"                   # data kept
        st = http(port, "GET", "/api/settings")[1]
        assert any(u["name"] == "המזכירה" and u["is_admin"] for u in st["users"])  # existing users became admins
        assert "777" == st["users"][0]["masked"][-3:] and len(st["users"][0]["masked"]) >= 6
        wk = http(port, "GET", "/api/weekdays")[1]                     # 1.1 data migrated to per-weekday schedules
        names = {x["id"]: x["name"] for x in wk["schedules"]}
        assert names[wk["map"]["6"]] == "ראשון" and names[wk["map"]["0"]] == "רגילה" and names[wk["map"]["3"]] == "חמישי"
        assert wk["map"]["4"] is None and wk["map"]["5"] is None
        assert json.loads((app / "updates" / "last_result.json").read_text())["status"] == "ok"
        assert list((app / "updates" / "backups").iterdir())

        # school data created on 1.2 that later updates must never touch
        assert http(port, "POST", "/api/settings/token", {"token": "8123456789:AAH" + "Q" * 30 + "k9Zt"})[0] == 200
        sch = {x["name"]: x["id"] for x in http(port, "GET", "/api/weekdays")[1]["schedules"]}
        http(port, "POST", "/api/weekdays", {"weekday": 4, "schedule_id": sch["מבחנים"]})      # Friday bells
        http(port, "POST", "/api/calendar/day", {"date": "2026-12-07", "mode": "school"})     # study on Chanukah
        http(port, "POST", f"/api/schedules/{sch['ראשון']}/bells", {"times": "19:00"})
        school_state = lambda: (http(port, "GET", "/api/weekdays")[1]["map"],                 # noqa: E731
                                http(port, "GET", f"/api/schedules/{sch['ראשון']}")[1]["bells"],
                                http(port, "GET", "/api/calendar?month=2026-12")[1]["days"][6]["reason"],
                                http(port, "GET", "/api/settings")[1]["token"]["last4"],
                                [u["name"] for u in http(port, "GET", "/api/settings")[1]["users"]],
                                [r["name"] for r in http(port, "GET", "/api/ringtones")[1]["items"]])
        before = school_state()
        assert before[2] == "school_day" and before[3] == "k9Zt"

        # ---- 2) in-app update 1.2 -> 1.3 through the UI API ----
        chg = (app / "CHANGELOG.md").read_text(encoding="utf-8").replace("## 1.3", "## 9.1\n- בדיקת עדכון\n\n## 1.3", 1)
        z13 = bu.write_package(tmp_path / "dist", "9.1",
                               {"VERSION": b"9.1\n", "CHANGELOG.md": chg.encode(),
                                "bells/web/static/app.css": (app / "bells/web/static/app.css").read_bytes() + b"\n/*9.1*/\n"},
                               [], bu.head_scripts(), key.hex(), V, ["בדיקת עדכון"])
        code, info = http(port, "POST", "/api/update/install", raw=z13.read_bytes(), ctype="application/zip")
        assert code == 200 and info["version"] == "9.1" and info["current"] == V, info
        wait_for(lambda: health(port) == "9.1", 60, "1.3 up")
        wait_for(lambda: not (app / "updates" / "update.lock").exists(), 30, "updater finished")
        assert json.loads((app / "updates" / "last_result.json").read_text())["to"] == "9.1"
        assert (app / "config.toml").read_bytes() == cfg_bytes

        # ---- 3) rejections: same/older version, tampered, foreign key ----
        code, err = http(port, "POST", "/api/update/install", raw=z13.read_bytes(), ctype="application/zip")
        assert code == 400 and "אינה חדשה" in err["error"]
        z14ok = bu.write_package(tmp_path / "t", "9.2", {"VERSION": b"9.2\n"}, [], bu.head_scripts(), key.hex(), None, [])
        raw = bytearray(z14ok.read_bytes())
        tampered = zipfile.ZipFile(io.BytesIO(raw))
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as out:
            for i in tampered.infolist():
                data = tampered.read(i)
                out.writestr(i, b"9.9\n" if i.filename.endswith("payload/VERSION") else data)
        code, err = http(port, "POST", "/api/update/install", raw=buf.getvalue(), ctype="application/zip")
        assert code == 400 and "פגום" in err["error"]
        foreign = bu.write_package(tmp_path / "f", "9.2", {"VERSION": b"9.2\n"}, [], bu.head_scripts(), os.urandom(32).hex(), None, [])
        code, err = http(port, "POST", "/api/update/install", raw=foreign.read_bytes(), ctype="application/zip")
        assert code == 400 and "החתימה" in err["error"]

        # ---- 4) remote source: nightly / "update now" from a manifest with beta + stable channels ----
        import functools
        import http.server as hs
        import threading
        site = tmp_path / "site"
        (site / "files").mkdir(parents=True)

        def sign_manifest(man):
            data = json.dumps(man).encode()
            (site / "manifest.json").write_bytes(data)
            (site / "manifest.json.sig").write_text(ed25519.sign(key, data).hex())

        def manifest():
            p = site / "manifest.json"
            return json.loads(p.read_text()) if p.exists() else {"app": "school-bells", "format": 1, "channels": {}, "beta_devices": []}

        def publish(version, payload, channel):
            z = bu.write_package(site / "files", version, payload, [], bu.head_scripts(), key.hex(), V, [])
            man = manifest()
            man["channels"][channel] = {"version": version, "file": f"files/{z.name}",
                                        "sha256": __import__("hashlib").sha256(z.read_bytes()).hexdigest(), "min_from": V}
            sign_manifest(man)
        handler = functools.partial(hs.SimpleHTTPRequestHandler, directory=str(site))
        handler.log_message = lambda *a: None
        srv = hs.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        src_url = f"http://127.0.0.1:{srv.server_address[1]}/manifest.json"
        try:
            publish("9.1", {"VERSION": b"9.1\n"}, "stable")
            publish("9.2", {"VERSION": b"9.2\n"}, "beta")
            st = http(port, "POST", "/api/update/settings", {"url": src_url})[1]
            assert st["auto"] is True and st["channel"] == "stable"           # auto on once a URL is set
            assert http(port, "GET", "/api/about")[1]["device_id"].startswith("SB-")
            r = http(port, "POST", "/api/update/check", {"install": True})[1]
            assert r["status"] == "up_to_date", r                             # stable has 1.3 = installed
            # a school can't switch itself to beta: there is no such setting any more
            assert http(port, "POST", "/api/update/settings", {"channel": "beta"})[0] == 400
            r = http(port, "POST", "/api/update/check", {"install": True})[1]
            assert r["status"] == "up_to_date", r                             # still stable
            # an unsigned / tampered manifest is refused (e.g. someone adds their own device to the list)
            dev = http(port, "GET", "/api/about")[1]["device_id"]
            evil = manifest()
            evil["beta_devices"] = [{"id": dev}]
            (site / "manifest.json").write_text(json.dumps(evil))              # signature no longer matches
            r = http(port, "POST", "/api/update/check", {"install": True})[1]
            assert r["status"] == "error" and "נדחה" in r["message"] and health(port) == "9.1", r
            # the vendor (with the private key) adds this computer as a beta device
            sign_manifest(evil)                                                # same list, now signed by the vendor
            r = http(port, "POST", "/api/update/check", {"install": True})[1]
            assert r["status"] == "installing" and r["version"] == "9.2", r
            wait_for(lambda: health(port) == "9.2", 60, "1.4 from beta channel")
            wait_for(lambda: not (app / "updates" / "update.lock").exists(), 30, "updater finished")
            assert school_state() == before                                     # nothing of the school was touched

            # ---- 5) broken 1.5 on beta -> installs, fails health check, rolls back to 1.4 by itself ----
            main_before = (app / "main.py").read_bytes()
            publish("9.3", {"VERSION": b"9.3\n", "main.py": b"raise SystemExit(7)\n"}, "beta")
            r = http(port, "POST", "/api/update/check", {"install": True})[1]
            assert r["status"] == "installing", r

            def rolled_back():
                try:
                    r = json.loads((app / "updates" / "last_result.json").read_text())
                except (OSError, ValueError):
                    return None
                return r if r.get("status") == "rolled_back" and r.get("to") == "9.3" else None
            res = wait_for(rolled_back, 120, "rollback")
            assert res["from"] == "9.2" and res["old_running"] is True
            wait_for(lambda: health(port) == "9.2", 30, "1.4 back")
            assert (app / "main.py").read_bytes() == main_before
            assert (app / "VERSION").read_text().strip() == "9.2"
            assert school_state() == before
            # a package with a foreign signature on the channel is refused (and nothing changes)
            z = bu.write_package(site / "files", "9.4", {"VERSION": b"9.4\n"}, [], bu.head_scripts(), os.urandom(32).hex(), None, [])
            man = manifest()
            man["channels"]["beta"] = {"version": "9.4", "file": f"files/{z.name}"}
            sign_manifest(man)
            r = http(port, "POST", "/api/update/check", {"install": True})[1]
            assert r["status"] == "error" and "החתימה" in r["message"] and health(port) == "9.2"
        finally:
            srv.shutdown()
    finally:
        au.stop_app(app, log)
