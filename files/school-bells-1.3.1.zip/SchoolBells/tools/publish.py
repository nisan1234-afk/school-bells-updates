"""Publish School Bells updates to an update site (a folder that is served as static files, e.g. a GitHub repo).

  # 1) build a signed package from HEAD and put it on the BETA channel (your test computer gets it tonight)
  python tools/publish.py beta    --site ../school-bells-updates --key ~/school-bells-signing/private_key.hex --push

  # 2) after it ran fine on the test computer: promote the same package to STABLE (all schools)
  python tools/publish.py promote --site ../school-bells-updates --key ~/school-bells-signing/private_key.hex --push

  # which computers get the beta channel (device id from Settings -> About on that computer)
  python tools/publish.py device-add SB-ABCD-EFGH-IJKL --name "מחשב בדיקה" --site ... --key ... --push
  python tools/publish.py device-remove SB-ABCD-EFGH-IJKL --site ... --key ... --push

  python tools/publish.py status  --site ../school-bells-updates

manifest.json is signed (manifest.json.sig). Computers accept the manifest only with a valid vendor signature, and
only devices listed in its "beta_devices" get the beta channel – every other computer is always on stable.

The site folder holds manifest.json + files/. Each school's computer reads manifest.json once a night
(Settings -> Software update -> source URL) and installs the newest version of its channel.
Packages are cumulative from --base (default: the oldest version still installed somewhere, v1.1),
so a school that skipped versions still updates in one step.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT))
import build_update  # noqa: E402
from bells.update import ed25519  # noqa: E402
from bells.version import vtuple  # noqa: E402

DEVICE_RE = re.compile(r"^SB-[A-Z2-7]{4}-[A-Z2-7]{4}-[A-Z2-7]{4}$")

EMPTY = {"app": "school-bells", "format": 1, "channels": {}, "beta_devices": []}


def load(site: Path) -> dict:
    p = site / "manifest.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else json.loads(json.dumps(EMPTY))


def save(site: Path, man: dict, key_hex: str):
    """Writes manifest.json and its Ed25519 signature (manifest.json.sig). Never writes the key itself."""
    man.setdefault("beta_devices", [])
    man["updated"] = datetime.now().isoformat(timespec="seconds")
    data = (json.dumps(man, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (site / "manifest.json").write_bytes(data)
    (site / "manifest.json.sig").write_text(ed25519.sign(bytes.fromhex(key_hex), data).hex() + "\n")


def device_add(site: Path, key_hex: str, device: str, name: str = "") -> dict:
    device = device.strip().upper()
    if not DEVICE_RE.match(device):
        sys.exit(f"bad device id '{device}' – expected like SB-ABCD-EFGH-IJKL (Settings -> About)")
    man = load(site)
    devs = [d for d in man.get("beta_devices", []) if d["id"] != device]
    devs.append({"id": device, "name": name, "added": datetime.now().isoformat(timespec="seconds")})
    man["beta_devices"] = devs
    save(site, man, key_hex)
    print(f"beta device added: {device} {name}")
    return man


def device_remove(site: Path, key_hex: str, device: str) -> dict:
    device = device.strip().upper()
    man = load(site)
    before = len(man.get("beta_devices", []))
    man["beta_devices"] = [d for d in man.get("beta_devices", []) if d["id"] != device]
    if len(man["beta_devices"]) == before:
        sys.exit(f"{device} is not a beta device")
    save(site, man, key_hex)
    print(f"beta device removed: {device}")
    return man


def push(site: Path, message: str):
    if not (site / ".git").exists():
        print("(site is not a git repo – upload the folder yourself)")
        return
    for cmd in (["git", "add", "-A"], ["git", "commit", "-m", message], ["git", "push"]):
        subprocess.run(cmd, cwd=site, check=cmd[1] != "commit")
    print("pushed")


def publish_beta(site: Path, key_hex: str, base: str, min_from: str | None, require_clean: bool = True) -> dict:
    files = site / "files"
    pkg = build_update.build(base, key_hex, min_from, files, require_clean=require_clean)
    version = pkg.stem.rsplit("-", 1)[-1]
    man = load(site)
    stable = man["channels"].get("stable")
    if stable and vtuple(version) <= vtuple(stable["version"]):
        sys.exit(f"version {version} is not newer than stable {stable['version']} – bump VERSION first")
    man["channels"]["beta"] = {
        "version": version, "file": f"files/{pkg.name}", "sha256": hashlib.sha256(pkg.read_bytes()).hexdigest(),
        "min_from": min_from, "full_installer": f"files/school-bells-{version}.zip",
        "published": datetime.now().isoformat(timespec="seconds"),
    }
    save(site, man, key_hex)
    print(f"beta -> {version}")
    return man


def promote(site: Path, key_hex: str) -> dict:
    man = load(site)
    beta = man["channels"].get("beta")
    if not beta:
        sys.exit("nothing on the beta channel")
    stable = man["channels"].get("stable")
    if stable and vtuple(beta["version"]) <= vtuple(stable["version"]):
        sys.exit(f"stable already has {stable['version']}")
    man["channels"]["stable"] = {**beta, "promoted": datetime.now().isoformat(timespec="seconds")}
    save(site, man, key_hex)
    print(f"stable -> {beta['version']}")
    return man


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["beta", "promote", "device-add", "device-remove", "status"])
    ap.add_argument("device", nargs="?", help="device id for device-add / device-remove")
    ap.add_argument("--name", default="", help="label for device-add")
    ap.add_argument("--site", required=True, help="folder of the update site (served as static files)")
    ap.add_argument("--key", help="private signing key (hex) – needed for every change")
    ap.add_argument("--base", default="v1.1", help="oldest installed version to support (git tag)")
    ap.add_argument("--min-from", default=None, help="defaults to the version of --base")
    ap.add_argument("--push", action="store_true", help="git commit + push the site folder")
    a = ap.parse_args()
    site = Path(a.site).expanduser().resolve()
    site.mkdir(parents=True, exist_ok=True)
    if a.action == "status":
        man = load(site)
        print(json.dumps({"channels": {k: v["version"] for k, v in man.get("channels", {}).items()},
                          "beta_devices": man.get("beta_devices", [])}, ensure_ascii=False, indent=2))
        return
    if not a.key:
        sys.exit("--key is required (the manifest is signed)")
    key_hex = Path(a.key).expanduser().read_text().strip()
    if a.action == "beta":
        man = publish_beta(site, key_hex, a.base, a.min_from or a.base.lstrip("v"))
        msg = f"beta {man['channels']['beta']['version']}"
    elif a.action == "promote":
        man = promote(site, key_hex)
        msg = f"stable {man['channels']['stable']['version']}"
    elif a.action == "device-add":
        if not a.device:
            sys.exit("device id is required")
        device_add(site, key_hex, a.device, a.name)
        msg = f"beta device {a.device.upper()}"
    else:
        if not a.device:
            sys.exit("device id is required")
        device_remove(site, key_hex, a.device)
        msg = f"remove beta device {a.device.upper()}"
    if a.push:
        push(site, msg)


if __name__ == "__main__":
    main()
