"""OS helpers (Windows): clock sync, single-instance lock."""
from __future__ import annotations

import os
from pathlib import Path
import socket
import subprocess

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def sync_clock() -> tuple[bool, str]:
    if os.name != "nt":
        return False, "not windows"
    try:
        r = subprocess.run(["w32tm", "/resync", "/force"], capture_output=True, timeout=60,
                           creationflags=_NO_WINDOW)
        out = r.stdout.decode("cp1255", "ignore") + r.stderr.decode("cp1255", "ignore")
        return r.returncode == 0, out.strip()
    except Exception as e:
        return False, str(e)


class InstanceLock:
    """Two independent locks; both must be free:
    1. an OS file lock on data/bells.lock (released automatically if the process dies),
    2. an exclusive localhost port (Windows: SO_EXCLUSIVEADDRUSE – never SO_REUSEADDR, which would let a
       second process bind the same port)."""

    def __init__(self, fh, sock):
        self._fh, self._sock = fh, sock


def _lock_file(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(path, "a+")
    try:
        if os.name == "nt":
            import msvcrt
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return None
    fh.seek(0)
    fh.truncate()
    fh.write(str(os.getpid()))
    fh.flush()
    return fh


def _lock_port(port: int):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    if os.name == "nt":
        s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", -5), 1)  # -5 == ~SO_REUSEADDR
    try:
        s.bind(("127.0.0.1", port))
        s.listen(1)
        return s
    except OSError:
        s.close()
        return None


def acquire_single_instance(port: int, lock_file: Path | None = None) -> InstanceLock | None:
    """Returns a lock object to keep for the process lifetime, or None if another instance is running."""
    fh = _lock_file(lock_file) if lock_file else None
    if lock_file and fh is None:
        return None
    sock = _lock_port(port)
    if sock is None:
        if fh:
            fh.close()
        return None
    return InstanceLock(fh, sock)


def running_pid(lock_file: Path) -> str:
    try:
        return lock_file.read_text().strip()
    except OSError:
        return "?"
