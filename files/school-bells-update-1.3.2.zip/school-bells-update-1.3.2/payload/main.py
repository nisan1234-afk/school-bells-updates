"""Entry point: scheduler (always) + Telegram bot (when internet is available)."""
from __future__ import annotations

import logging
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

from bells.config import load_config  # noqa: E402
from bells.core.scheduler import Scheduler  # noqa: E402
from bells.core.service import BellService  # noqa: E402
from bells.core.system import acquire_single_instance  # noqa: E402
from bells.player.audio_tools import AudioProcessor  # noqa: E402
from bells.player.player import create_player  # noqa: E402
from bells.storage.db import Storage  # noqa: E402

EXIT_ALREADY_RUNNING = 3


def setup_logging(log_dir: Path, level: str):
    log_dir.mkdir(parents=True, exist_ok=True)
    handlers = [RotatingFileHandler(log_dir / "bells.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")]
    if sys.stdout and sys.stdout.isatty():
        handlers.append(logging.StreamHandler())
    from bells.core.redact import RedactingFormatter
    fmt = RedactingFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s")  # the bot token never reaches a log
    for h in handlers:
        h.setFormatter(fmt)
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO), handlers=handlers)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)


def main() -> int:
    cfg_path = APP_DIR / "config.toml"
    if not cfg_path.exists():
        print("config.toml missing – copy config.example.toml to config.toml")
        return 2
    cfg = load_config(cfg_path, APP_DIR)
    setup_logging(cfg.data_dir / "logs", cfg.log_level)
    log = logging.getLogger("main")

    lock_file = cfg.data_dir / "bells.lock"
    lock = acquire_single_instance(cfg.lock_port, lock_file)
    if lock is None:
        from bells.core.system import running_pid
        log.info("another instance is running (pid %s) – exiting", running_pid(lock_file))
        return EXIT_ALREADY_RUNNING

    from bells.bot.notifier import TelegramNotifier
    service = BellService(cfg, Storage(cfg.data_dir / "bells.db"), create_player(),
                          AudioProcessor(cfg.ffmpeg_path, cfg.target_lufs))
    service.notifier = TelegramNotifier(service.bot_token, service.authorized_ids)
    service.seed()
    Scheduler(service).start()
    log.info("bell scheduler started (ffmpeg=%s)", cfg.ffmpeg_path)

    if cfg.web_enabled:
        try:
            from bells.web.server import WebServer
            WebServer(service, cfg.web_port).start()
        except OSError as e:
            log.error("web UI could not start on port %s: %s", cfg.web_port, e)

    # fire-and-forget: no "I'm up" message; only faults / answers to commands are sent
    service.report_update_result()

    try:
        from bells.bot.telegram_bot import BellBot
    except ImportError as e:  # bells + UI keep working even if the bot library is broken
        log.error("telegram library unavailable: %s", e)
        while True:
            time.sleep(3600)
    BellBot(service).run_forever()
    return 0


if __name__ == "__main__":
    sys.exit(main())
