"""The bot must never hammer Telegram: honour retry_after, grow delays, stop fighting a second poller (409),
run as a single instance, and report the real error. Uses the real telegram library against a fake server."""
import asyncio
import io
import json
import subprocess
import sys
import threading
import time
import urllib.error
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from telegram.error import Conflict, InvalidToken, NetworkError, RetryAfter, TimedOut  # noqa: E402

from bells.bot import notifier as N  # noqa: E402
from bells.bot import telegram_bot as tb  # noqa: E402
from bells.config import load_config  # noqa: E402
from bells.core import system  # noqa: E402
from bells.core.service import BellService  # noqa: E402
from bells.player.audio_tools import AudioProcessor  # noqa: E402
from bells.player.player import NullPlayer  # noqa: E402
from bells.storage.db import Storage  # noqa: E402

TOKEN = "8123456789:AAH" + "Q" * 32


@pytest.fixture
def svc(tmp_path):
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    s = BellService(cfg, Storage(tmp_path / "t.db"), NullPlayer(), AudioProcessor(None), clock=datetime.now)
    s.seed()
    s.set_bot_token(TOKEN, ("1", "t"))
    return s


def test_classify_errors():
    assert tb.classify_error(RetryAfter(28))[0::2] == ("429", 28)
    assert tb.classify_error(Conflict("terminated by other getUpdates request"))[0] == "409"
    assert tb.classify_error(InvalidToken())[0] == "401"
    assert tb.classify_error(NetworkError("x"))[0] == "network" and tb.classify_error(TimedOut())[0] == "network"
    assert "28" in tb.classify_error(RetryAfter(28))[1]


class Stop(BaseException):
    pass


def test_supervisor_waits_grow_and_respect_retry_after(svc, monkeypatch):
    bot = tb.BellBot(svc)
    errors = [RetryAfter(100), NetworkError("down"), NetworkError("down"), NetworkError("down"), InvalidToken(), Stop()]
    calls, waits, statuses = [], [], []

    async def fake_run(token):
        calls.append(time.monotonic())
        raise errors[len(calls) - 1]
    monkeypatch.setattr(bot, "_run_async", fake_run)
    monkeypatch.setattr(svc.bot_changed, "wait", lambda t=None: waits.append(t) or False)
    orig = svc.set_bot_status
    monkeypatch.setattr(svc, "set_bot_status", lambda *a, **k: (statuses.append((a, k)), orig(*a, **k)))
    monkeypatch.setattr(tb, "_BOT_LOOP_LOCK", threading.Lock())
    with pytest.raises(Stop):
        bot.run_forever()
    assert waits[0] >= 101                                    # honoured retry_after (+1 s)
    assert waits[1] < waits[2] < waits[3]                     # growing
    assert all(w >= bot.BACKOFF_BASE * 0.85 for w in waits)   # never an immediate retry
    assert waits[4] == 1800                                   # wrong token: wait for a new one, don't hammer
    codes = [k.get("code") for a, k in statuses if a and a[0] == "error"]
    assert codes == ["429", "network", "network", "network", "401"]
    assert statuses[-1][1]["retry_at"] is not None


def test_single_bot_loop_per_process(svc, monkeypatch):
    monkeypatch.setattr(tb, "_BOT_LOOP_LOCK", threading.Lock())
    tb._BOT_LOOP_LOCK.acquire()
    assert tb.BellBot(svc).run_forever() is None              # returns at once, no second poller


class FakeTelegram(BaseHTTPRequestHandler):
    """getMe / deleteWebhook OK; getUpdates (or getMe) answer with a configurable error."""
    mode = "conflict"
    log: list = []

    def log_message(self, *a):
        pass

    def do_POST(self):
        method = self.path.rsplit("/", 1)[-1]
        self.rfile.read(int(self.headers.get("Content-Length") or 0))
        FakeTelegram.log.append((time.monotonic(), method))
        if method == "getMe" and FakeTelegram.mode == "ratelimit":
            return self._send(429, {"ok": False, "error_code": 429, "description": "Too Many Requests: retry after 3",
                                    "parameters": {"retry_after": 3}})
        if method == "getMe":
            return self._send(200, {"ok": True, "result": {"id": 1, "is_bot": True, "first_name": "b", "username": "test_bot",
                                                           "can_join_groups": False, "can_read_all_group_messages": False,
                                                           "supports_inline_queries": False}})
        if method == "getUpdates":
            return self._send(409, {"ok": False, "error_code": 409,
                                    "description": "Conflict: terminated by other getUpdates request"})
        return self._send(200, {"ok": True, "result": True})

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


@pytest.fixture
def fake_tg():
    FakeTelegram.log = []
    srv = ThreadingHTTPServer(("127.0.0.1", 0), FakeTelegram)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}/bot"
    srv.shutdown()


def run_bot(svc, base, seconds, monkeypatch):
    bot = tb.BellBot(svc)
    bot.api_base_url = base
    monkeypatch.setattr(tb, "_BOT_LOOP_LOCK", threading.Lock())
    t = threading.Thread(target=bot.run_forever, daemon=True)
    t.start()
    time.sleep(seconds)
    return bot


def test_second_poller_409_stops_instead_of_flooding(svc, fake_tg, monkeypatch):
    FakeTelegram.mode = "conflict"
    run_bot(svc, fake_tg, 8, monkeypatch)
    updates = [t for t, m in FakeTelegram.log if m == "getUpdates"]
    getme = [t for t, m in FakeTelegram.log if m == "getMe"]
    # 3 conflicts -> stop polling and back off (>= 12 s), so within 8 s: few requests, one getMe
    assert 3 <= len(updates) <= 5, len(updates)
    assert len(getme) == 1
    assert svc.bot_status["code"] == "409" and svc.bot_status["retry_at"]
    assert "במקום אחר" in svc.bot_status["error"]


def test_429_on_getme_waits_retry_after(svc, fake_tg, monkeypatch):
    FakeTelegram.mode = "ratelimit"
    monkeypatch.setattr(tb.BellBot, "BACKOFF_BASE", 0.5)     # so retry_after is what decides the wait
    run_bot(svc, fake_tg, 6, monkeypatch)
    getme = [t for t, m in FakeTelegram.log if m == "getMe"]
    assert len(getme) == 2, len(getme)                       # first try + one retry after ~4 s, not a loop
    assert getme[1] - getme[0] >= 3.9
    assert svc.bot_status["code"] == "429"


def test_notifier_honours_retry_after_and_grows(monkeypatch):
    n = N.TelegramNotifier(lambda: TOKEN, lambda: [1])
    answers = [429, 429, 500, None]

    def fake_urlopen(req, timeout=15):
        code = answers.pop(0)
        if code is None:
            return io.BytesIO(b'{"ok": true}')
        body = json.dumps({"ok": False, "parameters": {"retry_after": 7}} if code == 429 else {"ok": False}).encode()
        raise urllib.error.HTTPError(req.full_url, code, "x", {}, io.BytesIO(body))
    monkeypatch.setattr(N.urllib.request, "urlopen", fake_urlopen)
    sleeps = []
    assert n._deliver(time.time(), 1, "hi", sleep=sleeps.append) is True
    assert sleeps[0] >= 30 and sleeps[1] >= 60 and sleeps[2] >= 120   # >= retry_after+1 and growing
    assert all(s >= 8 for s in sleeps)


def test_check_token_does_not_retry_during_429(monkeypatch):
    calls = []

    def fake_urlopen(url, timeout=10):
        calls.append(url)
        raise urllib.error.HTTPError(url, 429, "x", {}, io.BytesIO(b'{"parameters": {"retry_after": 28}}'))
    monkeypatch.setattr(N.urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setitem(N._last_check, "t", 0.0)
    monkeypatch.setitem(N._last_check, "until", 0.0)
    ok, msg = N.check_token(TOKEN)
    assert not ok and "429" in msg and "28" in msg
    ok, msg = N.check_token(TOKEN)
    assert not ok and "429" in msg and len(calls) == 1     # no second request inside retry_after


def test_single_instance_lock(tmp_path):
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    lock_file = tmp_path / "bells.lock"
    first = system.acquire_single_instance(port, lock_file)
    assert first is not None
    code = ("import sys; sys.path.insert(0, %r); from pathlib import Path; from bells.core import system; "
            "print(system.acquire_single_instance(%d, Path(%r)) is None)") % (str(ROOT), port, str(lock_file))
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True).stdout.strip()
    assert out == "True"                                     # a second process is refused
