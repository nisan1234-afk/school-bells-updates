# School Bells - Windows installer (run via install.bat)
# Installs Python (if needed), dependencies, ffmpeg, config, clock sync, power settings,
# and a Task Scheduler task that starts the system at logon and restarts it if it stops.
param(
    [string]$TimeZone = "Israel Standard Time",
    [string]$TaskName = "SchoolBells",
    [string]$PythonVersion = "3.12.8"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ---- elevate ----
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Requesting administrator rights..."
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppDir
Get-ChildItem -Path $AppDir -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

function Step($msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }

try {
# ---- 1. Python ----
Step "Checking Python"
function Find-Python {
    foreach ($v in @("3.13", "3.12", "3.11")) {
        try {
            $p = & py "-$v" -c "import sys;print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() }
        } catch {}
    }
    foreach ($p in @("$env:ProgramFiles\Python313\python.exe", "$env:ProgramFiles\Python312\python.exe",
                     "$env:ProgramFiles\Python311\python.exe")) {
        if (Test-Path $p) { return $p }
    }
    return $null
}
$py = Find-Python
if (-not $py) {
    Step "Downloading Python $PythonVersion"
    $inst = Join-Path $env:TEMP "python-$PythonVersion-amd64.exe"
    Invoke-WebRequest -UseBasicParsing "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-amd64.exe" -OutFile $inst
    Start-Process $inst -Wait -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_launcher=1 Include_test=0"
    $py = Find-Python
    if (-not $py) { throw "Python installation failed" }
}
Write-Host "Python: $py"

# ---- 2. venv + packages ----
Step "Creating virtual environment and installing packages"
if (-not (Test-Path "$AppDir\.venv\Scripts\python.exe")) { & $py -m venv "$AppDir\.venv" }
$vpy = "$AppDir\.venv\Scripts\python.exe"
$vpyw = "$AppDir\.venv\Scripts\pythonw.exe"
& $vpy -m pip install --upgrade pip --quiet
& $vpy -m pip install -r "$AppDir\requirements.txt" --quiet
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

# ---- 3. ffmpeg ----
Step "Checking ffmpeg (audio normalization)"
$ffDir = "$AppDir\tools\ffmpeg\bin"
if (-not (Test-Path "$ffDir\ffmpeg.exe")) {
    $zip = Join-Path $env:TEMP "ffmpeg-essentials.zip"
    $tmp = Join-Path $env:TEMP "ffmpeg-extract"
    Invoke-WebRequest -UseBasicParsing "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" -OutFile $zip
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    Expand-Archive $zip -DestinationPath $tmp -Force
    $bin = Get-ChildItem $tmp -Recurse -Filter ffmpeg.exe | Select-Object -First 1
    New-Item -ItemType Directory -Force -Path $ffDir | Out-Null
    Copy-Item (Join-Path $bin.DirectoryName "*") $ffDir -Force
    Remove-Item $zip, $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host "ffmpeg: $ffDir\ffmpeg.exe"

# ---- 4. config ----
Step "Configuration"
$cfgPath = "$AppDir\config.toml"
$utf8 = New-Object System.Text.UTF8Encoding $false
if (-not (Test-Path $cfgPath)) {
    $text = [IO.File]::ReadAllText("$AppDir\config.example.toml", [Text.Encoding]::UTF8)
    Write-Host "Tip: you can skip both questions and set the bot + users later in the desktop app (Settings)."
    $token = Read-Host "Paste the Telegram bot token from BotFather (Enter = set later in the app)"
    $ids = Read-Host "Authorized chat IDs, comma separated (Enter = add later in the app)"
    if ($token) { $text = $text.Replace('bot_token = "PUT_BOT_TOKEN_HERE"', "bot_token = `"$($token.Trim())`"") }
    if ($ids) {
        $clean = ($ids -split "[,; ]+" | Where-Object { $_ -match '^-?\d+$' }) -join ", "
        $text = $text.Replace("authorized_chat_ids = []", "authorized_chat_ids = [$clean]")
    }
    [IO.File]::WriteAllText($cfgPath, $text, $utf8)
    Write-Host "Created config.toml (edit it any time with Notepad, then run restart.bat)"
} else {
    Write-Host "config.toml already exists - kept"
}

# ---- 5. tests ----
Step "Running schedule self-test"
& $vpy -m pip install pytest --quiet
& $vpy -m pytest -q "$AppDir\tests"
if ($LASTEXITCODE -ne 0) { Write-Warning "Some tests failed - see output above" }

# ---- 5b. firewall: let the app's Python reach the internet (Telegram, updates) ----
Step "Windows Firewall rules for the app's Python"
$basePy = & $vpy -c "import sys; print(sys._base_executable)"
$exes = @($vpy, $vpyw, $basePy, (Join-Path (Split-Path $basePy) "pythonw.exe")) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
foreach ($exe in $exes) {
    $name = "School Bells - " + (Split-Path (Split-Path $exe) -Leaf) + " " + (Split-Path $exe -Leaf)
    netsh advfirewall firewall delete rule name="$name" | Out-Null
    netsh advfirewall firewall add rule name="$name" dir=out action=allow program="$exe" enable=yes profile=any | Out-Null
    Write-Host "  allowed: $exe"
}

# ---- 6. time zone + clock sync ----
Step "Time zone and clock sync (w32tm)"
try { Set-TimeZone -Id $TimeZone } catch { Write-Warning "Could not set time zone: $_" }
Set-Service w32time -StartupType Automatic
Start-Service w32time -ErrorAction SilentlyContinue
w32tm /config /manualpeerlist:"time.windows.com,0x9 pool.ntp.org,0x9" /syncfromflags:manual /reliable:no /update | Out-Null
w32tm /resync /force | Out-Null
Write-Host "Clock: $(Get-Date)"

# ---- 7. power: never sleep ----
Step "Disabling sleep on AC power"
powercfg /change standby-timeout-ac 0
powercfg /change hibernate-timeout-ac 0

# ---- 8. scheduled task ----
Step "Registering Task Scheduler task '$TaskName'"
$user = (Get-CimInstance Win32_ComputerSystem).UserName
if (-not $user) { $user = "$env:USERDOMAIN\$env:USERNAME" }
$action = New-ScheduledTaskAction -Execute $vpyw -Argument "`"$AppDir\launcher.py`"" -WorkingDirectory $AppDir
$tLogon = New-ScheduledTaskTrigger -AtLogOn -User $user
$tRepeat = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
if (-not $tRepeat.Repetition.Duration) {
    $tRepeat = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
}
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Seconds 0) `
    -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($tLogon, $tRepeat) -Settings $settings `
    -Principal $principal -Force | Out-Null
Write-Host "Task registered for user $user"

# ---- 9. desktop shortcut (app window over the local UI) ----
Step "Creating desktop shortcut"
$port = 8787
$cfgText = [IO.File]::ReadAllText($cfgPath, [Text.Encoding]::UTF8)
$m = [regex]::Match($cfgText, '(?ms)^\[web\].*?^port\s*=\s*(\d+)')
if ($m.Success) { $port = [int]$m.Groups[1].Value }
$url = "http://127.0.0.1:$port/"
$browser = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
             "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
             "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
             "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") |
           Where-Object { Test-Path $_ } | Select-Object -First 1
# shortcut name in Hebrew, built from code points so this file can stay ASCII
$name = -join (@(0x05DE,0x05E2,0x05E8,0x05DB,0x05EA,0x20,0x05E6,0x05DC,0x05E6,0x05D5,0x05DC,0x05D9,0x05DD) | ForEach-Object { [char]$_ })
$desktop = [Environment]::GetFolderPath("CommonDesktopDirectory")
$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut((Join-Path $desktop "$name.lnk"))
if ($browser) {
    $lnk.TargetPath = $browser
    $lnk.Arguments = "--app=$url --window-size=1366,900"
} else {
    $lnk.TargetPath = "$env:WINDIR\explorer.exe"
    $lnk.Arguments = $url
}
$lnk.IconLocation = "$AppDir\assets\bells.ico"
$lnk.WorkingDirectory = $AppDir
$lnk.Save()
$openBat = "@echo off`r`nstart `"`" " + $(if ($browser) { "`"$browser`" --app=$url --window-size=1366,900" } else { $url }) + "`r`n"
[IO.File]::WriteAllText("$AppDir\open_ui.bat", $openBat, (New-Object System.Text.UTF8Encoding $false))
Write-Host "Shortcut created on the desktop ($url)"

# ---- 10. start ----
Step "Starting"
& "$AppDir\restart.ps1" -TaskName $TaskName
Write-Host ""
Start-Sleep -Seconds 6
Start-Process (Join-Path $desktop "$name.lnk")
Write-Host "DONE. The bell system is running and the app window was opened." -ForegroundColor Green
Write-Host "Open it any time from the desktop shortcut."
Write-Host "Logs: $AppDir\data\logs\bells.log"
} catch {
    Write-Host ""
    Write-Host "INSTALL FAILED: $_" -ForegroundColor Red
}
Read-Host "Press Enter to close"
