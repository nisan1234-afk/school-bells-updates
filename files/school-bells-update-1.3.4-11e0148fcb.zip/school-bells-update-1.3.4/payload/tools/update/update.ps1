# School Bells - applies this update package to the installed system.
# Finds the app folder, then runs apply_update.py (backup, stop, replace, restart, health check, auto-rollback).
# Never touches data\ or config.toml, never asks for the bot token.
param([string]$AppDir = "")
$ErrorActionPreference = "Stop"
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $a = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    if ($AppDir) { $a += " -AppDir `"$AppDir`"" }
    Start-Process powershell -Verb RunAs -ArgumentList $a
    exit
}
$PkgDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-App([string]$d) {
    return $d -and (Test-Path (Join-Path $d "main.py")) -and (Test-Path (Join-Path $d "bells"))
}
if (-not (Test-App $AppDir)) {
    $p1 = Split-Path -Parent $PkgDir
    $p2 = if ($p1) { Split-Path -Parent $p1 } else { "" }
    $AppDir = @($p1, $p2, "C:\SchoolBells", "C:\SchoolBells\SchoolBells") |
              Where-Object { Test-App $_ } | Select-Object -First 1
}
while (-not (Test-App $AppDir)) {
    $AppDir = Read-Host "Could not find the School Bells folder. Type its path (the folder with install.bat)"
}
$py = Join-Path $AppDir ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Host "Python environment not found in $AppDir - run install.bat once instead." -ForegroundColor Red
    Read-Host "Press Enter to close"; exit 1
}
Write-Host "Updating School Bells in $AppDir ..." -ForegroundColor Cyan
& $py -I (Join-Path $PkgDir "apply_update.py") --app-dir $AppDir --package-dir $PkgDir
$code = $LASTEXITCODE
Write-Host ""
if ($code -eq 0) {
    Write-Host "UPDATE DONE. You can delete this update folder." -ForegroundColor Green
} elseif ($code -eq 1) {
    Write-Host "Update FAILED - the previous version was restored automatically." -ForegroundColor Red
    Write-Host "Details: $AppDir\updates\logs"
} else {
    Write-Host "Update NOT applied (see the message above). Nothing was changed." -ForegroundColor Yellow
}
Read-Host "Press Enter to close"
