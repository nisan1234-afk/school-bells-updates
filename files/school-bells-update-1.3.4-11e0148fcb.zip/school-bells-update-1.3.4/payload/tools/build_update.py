"""Builds a signed update package with only the files changed since a base git ref.

  python tools/build_update.py --base v1.1 --key ~/school-bells-signing/private_key.hex [--min-from 1.1]

Output: dist/school-bells-update-<VERSION>.zip (and dist/school-bells-<VERSION>.zip, the full installer).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from bells.update import ed25519  # noqa: E402
from bells.update.apply_update import APP_ID, FORMAT, is_allowed_path  # noqa: E402
from bells.version import changelog, current_version, vtuple  # noqa: E402


def git(*args) -> str:
    return subprocess.run(["git", *args], cwd=ROOT, check=True, capture_output=True, text=True).stdout


def changed_files(base: str) -> tuple[list[str], list[str]]:
    files, deleted = set(), set()
    out = git("diff", "--name-status", "--no-renames", base, "HEAD")
    for line in out.splitlines():
        status, _, path = line.partition("\t")
        if status.startswith("D"):
            deleted.add(path)
        else:
            files.add(path)
    files |= {"VERSION", "CHANGELOG.md"}
    return sorted(p for p in files if is_allowed_path(p)), sorted(p for p in deleted if is_allowed_path(p))


def head_bytes(path: str) -> bytes:
    return subprocess.run(["git", "show", f"HEAD:{path}"], cwd=ROOT, check=True, capture_output=True).stdout


README_HE = ("עדכון מערכת הצלצולים לגרסה {v}\r\n\r\n"
             "דרך 1 (מומלץ): בממשק במחשב הצלצולים ⬅ הגדרות ⬅ עדכון תוכנה ⬅ גוררים את קובץ ה-zip הזה.\r\n"
             "דרך 2: שולחים את קובץ ה-zip לבוט (רק מנהל).\r\n"
             "דרך 3: מחלצים את ה-zip לתוך תיקיית התוכנה ולוחצים פעמיים על update.bat.\r\n\r\n"
             "העדכון לא נוגע בתיקייה data ובקובץ config.toml, ואם משהו נכשל – חוזר לבד לגרסה הקודמת.\r\n")


def write_package(out_dir: Path, version: str, payload: dict[str, bytes], deleted: list[str],
                  scripts: dict[str, bytes], key_hex: str, min_from: str | None, changes: list[str],
                  base: str = "") -> Path:
    """Writes school-bells-update-<version>.zip with a signed manifest."""
    vtuple(version)
    bad = [p for p in list(payload) + list(deleted) if not is_allowed_path(p)]
    if bad:
        raise ValueError(f"forbidden paths: {bad}")
    manifest = {
        "app": APP_ID, "format": FORMAT, "version": version, "min_from": min_from,
        "created": datetime.now().isoformat(timespec="seconds"), "base": base, "changes": changes,
        "requirements_changed": any(p.startswith("requirements") for p in payload),
        "files": {p: hashlib.sha256(b).hexdigest() for p, b in sorted(payload.items())},
        "delete": sorted(deleted),
        "scripts": {n: hashlib.sha256(b).hexdigest() for n, b in scripts.items()},
    }
    man_bytes = json.dumps(manifest, ensure_ascii=False, indent=1).encode("utf-8")
    sig = ed25519.sign(bytes.fromhex(key_hex), man_bytes)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"school-bells-update-{version}.zip"
    top = f"school-bells-update-{version}/"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(top + "manifest.json", man_bytes)
        z.writestr(top + "manifest.sig", sig.hex())
        z.writestr(top + "קרא אותי.txt", "\ufeff" + README_HE.format(v=version))
        for n, b in scripts.items():
            z.writestr(top + n, b)
        for p, b in sorted(payload.items()):
            z.writestr(top + "payload/" + p, b)
    return out


def head_scripts() -> dict[str, bytes]:
    return {"apply_update.py": head_bytes("bells/update/apply_update.py"),
            "update.ps1": head_bytes("tools/update/update.ps1"),
            "update.bat": head_bytes("tools/update/update.bat")}


def build(base: str, key_hex: str, min_from: str | None, out_dir: Path, require_clean: bool = True) -> Path:
    if require_clean and git("status", "--porcelain", "--untracked-files=no").strip():
        sys.exit("commit your changes first (the package is built from HEAD)")
    untracked = [p for p in git("ls-files", "--others", "--exclude-standard").splitlines() if is_allowed_path(p)]
    ignored = [p for p in git("ls-files", "--others", "--ignored", "--exclude-standard").splitlines()
               if is_allowed_path(p) and "__pycache__" not in p and not p.endswith(".pyc")]
    if require_clean and (untracked or ignored):
        sys.exit(f"app files are not in git (would be missing from the package): {(untracked + ignored)[:10]}")
    version = head_bytes("VERSION").decode().strip()
    files, deleted = changed_files(base)
    changes = changelog(text=head_bytes("CHANGELOG.md").decode("utf-8")).get(version, [])
    out = write_package(out_dir, version, {p: head_bytes(p) for p in files}, deleted, head_scripts(),
                        key_hex, min_from, changes, base)
    full = out_dir / f"school-bells-{version}.zip"
    subprocess.run(["git", "archive", "--format=zip", "--prefix=SchoolBells/", "-o", str(full), "HEAD"],
                   cwd=ROOT, check=True)
    print(f"{out.name}: {len(files)} files, {len(deleted)} deleted, {out.stat().st_size // 1024} KB")
    print(f"{full.name}: full installer")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True, help="git ref of the version installed at the customer (e.g. v1.1)")
    ap.add_argument("--key", required=True, help="path to the private signing key (hex)")
    ap.add_argument("--min-from", default=None, help="oldest installed version this package can update")
    ap.add_argument("--out", default=str(ROOT / "dist"))
    a = ap.parse_args()
    build(a.base, Path(a.key).expanduser().read_text().strip(), a.min_from or None, Path(a.out))
