"""Creates the vendor signing key pair (run once, on the developer's machine).

The PRIVATE key signs update packages – keep it secret and backed up, never inside the app folder.
The PUBLIC key goes into bells/update/keys.py so installed systems can verify updates.
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bells.update import ed25519  # noqa: E402

out = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "school-bells-signing" / "private_key.hex")
if out.exists():
    sys.exit(f"{out} already exists – refusing to overwrite a signing key")
out.parent.mkdir(parents=True, exist_ok=True)
secret = os.urandom(32)
out.write_text(secret.hex() + "\n")
try:
    os.chmod(out, 0o600)
except OSError:
    pass
print("private key:", out)
print("PUBLIC_KEY_HEX =", ed25519.public_key(secret).hex())
