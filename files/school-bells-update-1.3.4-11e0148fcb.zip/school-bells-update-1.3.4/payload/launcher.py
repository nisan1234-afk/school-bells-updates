"""Watchdog: runs main.py and restarts it if it crashes. Started by Windows Task Scheduler (pythonw)."""
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
EXIT_ALREADY_RUNNING = 3
LOG = APP_DIR / "data" / "logs" / "launcher.log"


def note(msg: str):
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")


def main():
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    fails = 0
    while True:
        started = time.time()
        err_log = LOG.parent / "main-stderr.log"
        LOG.parent.mkdir(parents=True, exist_ok=True)
        try:
            if err_log.exists() and err_log.stat().st_size > 1_000_000:
                err_log.replace(err_log.with_suffix(".log.1"))
        except OSError:
            pass
        with open(err_log, "a", encoding="utf-8", errors="replace") as err:   # tracebacks used to be lost
            err.write(f"--- {datetime.now():%Y-%m-%d %H:%M:%S} start ---\n")
            err.flush()
            code = subprocess.call([sys.executable, str(APP_DIR / "main.py")], cwd=str(APP_DIR), creationflags=flags,
                                   stdout=subprocess.DEVNULL, stderr=err)
        if code == EXIT_ALREADY_RUNNING:
            note("already running – launcher exits")
            return
        fails = fails + 1 if time.time() - started < 60 else 0
        note(f"main.py exited with code {code}; restarting")
        time.sleep(min(60, 5 * max(1, fails)))


if __name__ == "__main__":
    main()
