"""Audio conversion via ffmpeg: format conversion, loudness normalization, length limit."""
from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import wave
from pathlib import Path

log = logging.getLogger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
_DUR_RE = re.compile(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)")
NATIVE_EXTS = {".wav", ".mp3", ".ogg"}


def wav_duration(path: Path) -> float:
    try:
        with wave.open(str(path), "rb") as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return 0.0


class AudioProcessor:
    def __init__(self, ffmpeg_path: str | None, target_lufs: float = -14):
        self.ffmpeg = ffmpeg_path
        self.lufs = target_lufs

    @property
    def available(self) -> bool:
        return bool(self.ffmpeg)

    def _run(self, args: list[str], timeout: int = 300) -> subprocess.CompletedProcess:
        return subprocess.run([self.ffmpeg, "-hide_banner", *args], capture_output=True,
                              timeout=timeout, creationflags=_NO_WINDOW)

    def probe_duration(self, src: Path) -> float:
        r = self._run(["-i", str(src)], timeout=60)
        m = _DUR_RE.search(r.stderr.decode("utf-8", "ignore"))
        if not m:
            return 0.0
        h, mi, s = m.groups()
        return int(h) * 3600 + int(mi) * 60 + float(s)

    def convert(self, src: Path, dst_wav: Path, *, normalize: bool, max_seconds: float | None,
                fade: bool = True, start: float | None = None, end: float | None = None) -> tuple[Path, float]:
        """Returns (output_path, duration_seconds). Without ffmpeg, copies natively playable files.
        start/end (seconds) cut a segment; max_seconds still caps the result."""
        dst_wav.parent.mkdir(parents=True, exist_ok=True)
        trimming = bool(start) or end is not None
        if trimming:
            if not self.available:
                raise ValueError("חיתוך דורש ffmpeg (מותקן אוטומטית ב-install.bat)")
            start = max(0.0, start or 0.0)
            seg = (end - start) if end is not None else None
            if seg is not None and seg <= 0:
                raise ValueError("סוף הקטע חייב להיות אחרי ההתחלה")
            length = min(x for x in (seg, max_seconds) if x) if (seg or max_seconds) else None
            filters = [f"afade=t=in:d={min(0.08, (length or 1) / 4):.2f}"]
            if normalize:
                filters.append(f"loudnorm=I={self.lufs}:TP=-1.5:LRA=11")
            if fade and length:
                fd = min(1.0, length / 4)
                filters.append(f"afade=t=out:st={length - fd:.2f}:d={fd:.2f}")
            args = ["-y", "-loglevel", "error", "-ss", f"{start:.2f}", "-i", str(src), "-vn"]
            if length:
                args += ["-t", f"{length:.2f}"]
            args += ["-af", ",".join(filters), "-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le", str(dst_wav)]
            r = self._run(args)
            if r.returncode != 0 or not dst_wav.exists() or wav_duration(dst_wav) <= 0:
                raise RuntimeError("חיתוך השמע נכשל: " + r.stderr.decode("utf-8", "ignore")[-300:])
            return dst_wav, wav_duration(dst_wav)
        if not self.available:
            if src.suffix.lower() not in NATIVE_EXTS:
                raise RuntimeError("ffmpeg לא מותקן – אפשר לשלוח רק mp3/wav/ogg")
            out = dst_wav.with_suffix(src.suffix.lower())
            shutil.copyfile(src, out)
            return out, wav_duration(out)

        filters = []
        if normalize:
            filters.append(f"loudnorm=I={self.lufs}:TP=-1.5:LRA=11")
        args = ["-y", "-loglevel", "error", "-i", str(src), "-vn"]
        if max_seconds:
            src_dur = self.probe_duration(src)
            if fade and src_dur > max_seconds:
                fd = min(2.0, max_seconds / 4)
                filters.append(f"afade=t=out:st={max_seconds - fd:.2f}:d={fd:.2f}")
            args += ["-t", f"{max_seconds:.2f}"]
        if filters:
            args += ["-af", ",".join(filters)]
        args += ["-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le", str(dst_wav)]
        r = self._run(args)
        if r.returncode != 0 or not dst_wav.exists():
            raise RuntimeError("המרת השמע נכשלה: " + r.stderr.decode("utf-8", "ignore")[-300:])
        return dst_wav, wav_duration(dst_wav)

    def encode_song(self, src: Path, dst: Path, max_seconds: float | None) -> tuple[Path, float]:
        """Stores a song compressed (OGG Vorbis ~1 MB/min) – a library of hundreds of songs stays small.
        Without ffmpeg the original file is kept as is."""
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not self.available:
            if src.suffix.lower() not in NATIVE_EXTS:
                raise RuntimeError("ffmpeg לא מותקן – אפשר לשלוח רק mp3/wav/ogg")
            out = dst.with_suffix(src.suffix.lower())
            shutil.copyfile(src, out)
            return out, wav_duration(out)
        out = dst.with_suffix(".ogg")
        args = ["-y", "-loglevel", "error", "-i", str(src), "-vn", "-map_metadata", "-1"]
        if max_seconds:
            args += ["-t", f"{max_seconds:.2f}"]
        args += ["-ar", "44100", "-ac", "2", "-c:a", "libvorbis", "-q:a", "5", str(out)]
        r = self._run(args)
        if r.returncode != 0 or not out.exists():
            raise RuntimeError("שמירת השיר נכשלה: " + r.stderr.decode("utf-8", "ignore")[-300:])
        return out, self.probe_duration(out)

    def peaks(self, src: Path, buckets: int = 240) -> list[float]:
        """Rough waveform (0..1) for the trim bar, decoded once at upload time."""
        import array
        if self.available:
            r = subprocess.run([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(src), "-ac", "1",
                                "-ar", "4000", "-f", "s16le", "-"], capture_output=True, timeout=300,
                               creationflags=_NO_WINDOW)
            data = array.array("h", r.stdout[: len(r.stdout) // 2 * 2])
        else:
            try:
                with wave.open(str(src), "rb") as w:
                    if w.getsampwidth() != 2:
                        return []
                    data = array.array("h", w.readframes(w.getnframes()))
            except Exception:
                return []
        n = len(data)
        if not n:
            return []
        size = max(1, n // buckets)
        out = [max((abs(v) for v in data[i:i + size]), default=0) for i in range(0, n, size)][:buckets]
        top = max(out) or 1
        return [round(v / top, 3) for v in out]

    def make_preview(self, src: Path, dst_mp3: Path) -> Path | None:
        if not self.available:
            return None
        r = self._run(["-y", "-loglevel", "error", "-i", str(src), "-b:a", "128k", str(dst_mp3)])
        return dst_mp3 if r.returncode == 0 and dst_mp3.exists() else None
