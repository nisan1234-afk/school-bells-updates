"""Audio output. Bell has priority: it stops any song/announcement."""
from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Protocol

log = logging.getLogger(__name__)
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")


class Player(Protocol):
    def play_bell(self, path: Path, volume: int) -> None: ...
    def play_media(self, path: Path, volume: int, title: str, kind: str) -> None: ...
    def stop_media(self) -> None: ...
    def stop_all(self) -> None: ...
    def set_media_volume(self, volume: int) -> None: ...
    def now_playing(self) -> dict | None: ...
    def healthy(self) -> bool: ...


class PygamePlayer:
    def __init__(self):
        self._lock = threading.RLock()
        self._ok = False
        self._bell_sound = None
        self._media: dict | None = None
        self._init()

    def _init(self) -> bool:
        try:
            import pygame
            self._pg = pygame
            if pygame.mixer.get_init():
                pygame.mixer.quit()
            pygame.mixer.pre_init(44100, -16, 2, 2048)
            pygame.mixer.init()
            pygame.mixer.set_num_channels(8)
            self._ok = True
            log.info("audio initialized")
        except Exception as e:  # no device etc.
            log.error("audio init failed: %s", e)
            self._ok = False
        return self._ok

    def _ensure(self) -> bool:
        return self._ok or self._init()

    def _retry(self, fn):
        with self._lock:
            for attempt in range(2):
                if not self._ensure():
                    raise RuntimeError("אין התקן שמע זמין")
                try:
                    return fn()
                except Exception as e:
                    log.error("playback error (attempt %d): %s", attempt + 1, e)
                    self._ok = False
                    time.sleep(0.3)
            raise RuntimeError("ניגון נכשל")

    def play_bell(self, path: Path, volume: int) -> None:
        def go():
            pg = self._pg
            pg.mixer.music.stop()
            self._media = None
            snd = pg.mixer.Sound(str(path))
            snd.set_volume(max(0, min(100, volume)) / 100)
            snd.play()
            self._bell_sound = snd
        self._retry(go)

    def play_media(self, path: Path, volume: int, title: str, kind: str) -> None:
        def go():
            pg = self._pg
            pg.mixer.music.stop()
            try:
                pg.mixer.music.unload()
            except Exception:
                pass
            pg.mixer.music.load(str(path))
            pg.mixer.music.set_volume(max(0, min(100, volume)) / 100)
            pg.mixer.music.play()
            self._media = {"title": title, "kind": kind, "started": time.time()}
        self._retry(go)

    def stop_media(self) -> None:
        with self._lock:
            if self._ok:
                try:
                    self._pg.mixer.music.stop()
                    self._pg.mixer.music.unload()
                except Exception as e:
                    log.warning("stop failed: %s", e)
            self._media = None

    def stop_all(self) -> None:
        """Silences the speakers right now: bell sound, song, playlist track or announcement."""
        with self._lock:
            if self._ok:
                try:
                    self._pg.mixer.stop()          # every Sound channel (bells)
                    self._pg.mixer.music.stop()    # streamed media (songs / announcements)
                    self._pg.mixer.music.unload()
                except Exception as e:
                    log.warning("stop_all failed: %s", e)
            self._media = None

    def set_media_volume(self, volume: int) -> None:
        with self._lock:
            if self._ok:
                self._pg.mixer.music.set_volume(volume / 100)

    def now_playing(self) -> dict | None:
        with self._lock:
            if self._media and self._ok and self._pg.mixer.music.get_busy():
                return self._media
            self._media = None
            return None

    def healthy(self) -> bool:
        with self._lock:
            return self._ensure()


class NullPlayer:
    """Used in tests / machines without audio. Records calls."""

    def __init__(self):
        self.calls: list[tuple] = []
        self._media = None

    def play_bell(self, path, volume):
        self.calls.append(("bell", str(path), volume))
        self._media = None

    def play_media(self, path, volume, title, kind):
        self.calls.append(("media", str(path), volume, kind))
        self._media = {"title": title, "kind": kind, "started": time.time()}

    def stop_media(self):
        self.calls.append(("stop",))
        self._media = None

    def stop_all(self):
        self.calls.append(("stop_all",))
        self._media = None

    def set_media_volume(self, volume):
        self.calls.append(("media_volume", volume))

    def now_playing(self):
        return self._media

    def healthy(self):
        return True

    def finish(self):
        """Test helper: the current song ended by itself."""
        self._media = None


def create_player() -> Player:
    try:
        import pygame  # noqa: F401
        return PygamePlayer()
    except ImportError:
        log.error("pygame missing – using silent player")
        return NullPlayer()
