"""SQLite storage. Every row carries school_id so the same DB/API can serve many schools later."""
from __future__ import annotations

import sqlite3
import threading
from datetime import date, datetime
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS schools(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, created_at TEXT);
CREATE TABLE IF NOT EXISTS settings(
    school_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT,
    PRIMARY KEY(school_id, key));
CREATE TABLE IF NOT EXISTS schedules(
    id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL,
    name TEXT NOT NULL, created_at TEXT, UNIQUE(school_id, name));
CREATE TABLE IF NOT EXISTS bells(
    id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL,
    schedule_id INTEGER NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
    time TEXT NOT NULL, UNIQUE(schedule_id, time));
CREATE TABLE IF NOT EXISTS date_overrides(
    school_id INTEGER NOT NULL, date TEXT NOT NULL,
    schedule_id INTEGER NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
    PRIMARY KEY(school_id, date));
CREATE TABLE IF NOT EXISTS holidays(
    school_id INTEGER NOT NULL, date TEXT NOT NULL, note TEXT,
    PRIMARY KEY(school_id, date));
CREATE TABLE IF NOT EXISTS ringtones(
    id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL,
    name TEXT NOT NULL, path TEXT NOT NULL, duration REAL,
    created_at TEXT, created_by TEXT);
CREATE TABLE IF NOT EXISTS action_log(
    id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL,
    ts TEXT NOT NULL, actor_id TEXT, actor_name TEXT, action TEXT NOT NULL, details TEXT);
CREATE TABLE IF NOT EXISTS authorized_users(
    school_id INTEGER NOT NULL, chat_id INTEGER NOT NULL, name TEXT, added_at TEXT, added_by TEXT,
    PRIMARY KEY(school_id, chat_id));
CREATE TABLE IF NOT EXISTS uploads(
    id INTEGER PRIMARY KEY AUTOINCREMENT, school_id INTEGER NOT NULL,
    name TEXT NOT NULL, path TEXT NOT NULL, duration REAL, created_at TEXT, created_by TEXT);
CREATE TABLE IF NOT EXISTS school_days(
    school_id INTEGER NOT NULL, date TEXT NOT NULL, PRIMARY KEY(school_id, date));
CREATE INDEX IF NOT EXISTS ix_log_school_ts ON action_log(school_id, ts);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class Storage:
    def __init__(self, db_path: Path | str):
        if str(db_path) != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys=ON")
        if str(db_path) != ":memory:":
            self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(SCHEMA)
        self._migrate()

    def _columns(self, table: str) -> set[str]:
        return {r["name"] for r in self._q(f"PRAGMA table_info({table})")}

    def _migrate(self):
        if "source" not in self._columns("holidays"):
            self._x("ALTER TABLE holidays ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'")
        ucols = self._columns("uploads")
        if "in_library" not in ucols:   # 1.3: uploads become the song library (kept until deleted)
            self._x("ALTER TABLE uploads ADD COLUMN in_library INTEGER NOT NULL DEFAULT 1")
            self._x("ALTER TABLE uploads ADD COLUMN trim_start REAL")
            self._x("ALTER TABLE uploads ADD COLUMN trim_end REAL")
            self._x("ALTER TABLE uploads ADD COLUMN peaks TEXT")
        if "in_rotation" not in self._columns("ringtones"):
            self._x("ALTER TABLE ringtones ADD COLUMN in_rotation INTEGER NOT NULL DEFAULT 0")
        cols = {r["name"] for r in self._q("PRAGMA table_info(authorized_users)")}
        if "is_admin" not in cols:  # 1.2: admin role. Users that existed before become admins.
            self._x("ALTER TABLE authorized_users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
            self._x("UPDATE authorized_users SET is_admin=1")

    def _q(self, sql: str, params=()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def _x(self, sql: str, params=()) -> sqlite3.Cursor:
        with self._lock:
            return self._conn.execute(sql, params)

    def close(self):
        with self._lock:
            self._conn.close()

    # ----- schools / settings -----
    def ensure_school(self, sid: int, name: str):
        self._x("INSERT OR IGNORE INTO schools(id,name,created_at) VALUES(?,?,?)", (sid, name, _now()))
        self._x("UPDATE schools SET name=? WHERE id=?", (name, sid))

    def get_setting(self, sid: int, key: str, default: str | None = None) -> str | None:
        rows = self._q("SELECT value FROM settings WHERE school_id=? AND key=?", (sid, key))
        return rows[0]["value"] if rows else default

    def set_setting(self, sid: int, key: str, value) -> None:
        self._x("INSERT INTO settings(school_id,key,value) VALUES(?,?,?) "
                "ON CONFLICT(school_id,key) DO UPDATE SET value=excluded.value",
                (sid, key, None if value is None else str(value)))

    # ----- schedules / bells -----
    def list_schedules(self, sid: int) -> list[dict]:
        return self._q("SELECT s.id, s.name, COUNT(b.id) AS count FROM schedules s "
                       "LEFT JOIN bells b ON b.schedule_id=s.id WHERE s.school_id=? "
                       "GROUP BY s.id ORDER BY s.id", (sid,))

    def get_schedule(self, sid: int, schedule_id: int) -> dict | None:
        rows = self._q("SELECT id,name FROM schedules WHERE school_id=? AND id=?", (sid, schedule_id))
        return rows[0] if rows else None

    def get_schedule_by_name(self, sid: int, name: str) -> dict | None:
        rows = self._q("SELECT id,name FROM schedules WHERE school_id=? AND name=?", (sid, name))
        return rows[0] if rows else None

    def create_schedule(self, sid: int, name: str) -> int:
        try:
            return self._x("INSERT INTO schedules(school_id,name,created_at) VALUES(?,?,?)",
                           (sid, name, _now())).lastrowid
        except sqlite3.IntegrityError:
            raise ValueError(f"כבר קיימת מערכת בשם '{name}'")

    def rename_schedule(self, sid: int, schedule_id: int, name: str):
        try:
            self._x("UPDATE schedules SET name=? WHERE school_id=? AND id=?", (name, sid, schedule_id))
        except sqlite3.IntegrityError:
            raise ValueError(f"כבר קיימת מערכת בשם '{name}'")

    def delete_schedule(self, sid: int, schedule_id: int):
        self._x("DELETE FROM schedules WHERE school_id=? AND id=?", (sid, schedule_id))

    def list_bells(self, sid: int, schedule_id: int) -> list[dict]:
        return self._q("SELECT id,time FROM bells WHERE school_id=? AND schedule_id=? ORDER BY time",
                       (sid, schedule_id))

    def get_bell(self, sid: int, bell_id: int) -> dict | None:
        rows = self._q("SELECT id,schedule_id,time FROM bells WHERE school_id=? AND id=?", (sid, bell_id))
        return rows[0] if rows else None

    def add_bell(self, sid: int, schedule_id: int, hhmm: str) -> bool:
        cur = self._x("INSERT OR IGNORE INTO bells(school_id,schedule_id,time) VALUES(?,?,?)",
                      (sid, schedule_id, hhmm))
        return cur.rowcount > 0

    def delete_bell(self, sid: int, bell_id: int):
        self._x("DELETE FROM bells WHERE school_id=? AND id=?", (sid, bell_id))

    def move_bell(self, sid: int, bell_id: int, hhmm: str):
        try:
            self._x("UPDATE bells SET time=? WHERE school_id=? AND id=?", (hhmm, sid, bell_id))
        except sqlite3.IntegrityError:
            raise ValueError(f"השעה {hhmm} כבר קיימת במערכת")

    # ----- date overrides / holidays -----
    def set_override(self, sid: int, d: date, schedule_id: int):
        self._x("INSERT INTO date_overrides(school_id,date,schedule_id) VALUES(?,?,?) "
                "ON CONFLICT(school_id,date) DO UPDATE SET schedule_id=excluded.schedule_id",
                (sid, d.isoformat(), schedule_id))

    def delete_override(self, sid: int, d: date):
        self._x("DELETE FROM date_overrides WHERE school_id=? AND date=?", (sid, d.isoformat()))

    def list_overrides(self, sid: int, from_date: date | None = None) -> list[dict]:
        rows = self._q("SELECT o.date, o.schedule_id, s.name FROM date_overrides o "
                       "JOIN schedules s ON s.id=o.schedule_id WHERE o.school_id=? AND o.date>=? "
                       "ORDER BY o.date", (sid, (from_date or date.min).isoformat()))
        for r in rows:
            r["date"] = date.fromisoformat(r["date"])
        return rows

    def add_holiday(self, sid: int, d: date, note: str = "", source: str = "manual"):
        self._x("INSERT OR REPLACE INTO holidays(school_id,date,note,source) VALUES(?,?,?,?)",
                (sid, d.isoformat(), note, source))

    def delete_holidays_by_source(self, sid: int, source: str) -> int:
        return self._x("DELETE FROM holidays WHERE school_id=? AND source=?", (sid, source)).rowcount

    def holidays_map(self, sid: int, start: date, end: date) -> dict:
        rows = self._q("SELECT date, note, source FROM holidays WHERE school_id=? AND date BETWEEN ? AND ?",
                       (sid, start.isoformat(), end.isoformat()))
        return {date.fromisoformat(r["date"]): r for r in rows}

    # ----- school days (cancel an automatic holiday) -----
    def set_school_day(self, sid: int, d: date, on: bool):
        if on:
            self._x("INSERT OR IGNORE INTO school_days(school_id,date) VALUES(?,?)", (sid, d.isoformat()))
        else:
            self._x("DELETE FROM school_days WHERE school_id=? AND date=?", (sid, d.isoformat()))

    def school_days_between(self, sid: int, start: date, end: date) -> set:
        rows = self._q("SELECT date FROM school_days WHERE school_id=? AND date BETWEEN ? AND ?",
                       (sid, start.isoformat(), end.isoformat()))
        return {date.fromisoformat(r["date"]) for r in rows}

    def delete_holiday(self, sid: int, d: date):
        self._x("DELETE FROM holidays WHERE school_id=? AND date=?", (sid, d.isoformat()))

    def list_holidays(self, sid: int, from_date: date | None = None) -> list[dict]:
        rows = self._q("SELECT date, note, source FROM holidays WHERE school_id=? AND date>=? ORDER BY date",
                       (sid, (from_date or date.min).isoformat()))
        for r in rows:
            r["date"] = date.fromisoformat(r["date"])
        return rows

    def is_holiday(self, sid: int, d: date) -> bool:
        return bool(self._q("SELECT 1 FROM holidays WHERE school_id=? AND date=?", (sid, d.isoformat())))

    def get_override(self, sid: int, d: date) -> int | None:
        rows = self._q("SELECT schedule_id FROM date_overrides WHERE school_id=? AND date=?", (sid, d.isoformat()))
        return rows[0]["schedule_id"] if rows else None

    # ----- ringtones -----
    def add_ringtone(self, sid: int, name: str, path: str, duration: float, created_by: str) -> int:
        return self._x("INSERT INTO ringtones(school_id,name,path,duration,created_at,created_by) "
                       "VALUES(?,?,?,?,?,?)", (sid, name, path, duration, _now(), created_by)).lastrowid

    def list_ringtones(self, sid: int) -> list[dict]:
        return self._q("SELECT * FROM ringtones WHERE school_id=? ORDER BY id DESC", (sid,))

    def get_ringtone(self, sid: int, rid: int) -> dict | None:
        rows = self._q("SELECT * FROM ringtones WHERE school_id=? AND id=?", (sid, rid))
        return rows[0] if rows else None

    def rename_ringtone(self, sid: int, rid: int, name: str):
        self._x("UPDATE ringtones SET name=? WHERE school_id=? AND id=?", (name, sid, rid))

    def set_rotation(self, sid: int, rid: int, on: bool):
        self._x("UPDATE ringtones SET in_rotation=? WHERE school_id=? AND id=?", (int(on), sid, rid))

    def delete_ringtone(self, sid: int, rid: int):
        self._x("DELETE FROM ringtones WHERE school_id=? AND id=?", (sid, rid))

    # ----- uploaded audio (songs / sources for ringtones) -----
    def add_upload(self, sid: int, name: str, path: str, duration: float, created_by: str,
                   in_library: bool = True, peaks: str | None = None) -> int:
        return self._x("INSERT INTO uploads(school_id,name,path,duration,created_at,created_by,in_library,peaks) "
                       "VALUES(?,?,?,?,?,?,?,?)",
                       (sid, name, path, duration, _now(), created_by, int(in_library), peaks)).lastrowid

    def update_upload(self, sid: int, uid: int, **fields):
        allowed = {"name", "trim_start", "trim_end", "in_library", "peaks"}
        cols = [k for k in fields if k in allowed]
        if cols:
            self._x(f"UPDATE uploads SET {', '.join(c + '=?' for c in cols)} WHERE school_id=? AND id=?",
                    tuple(fields[c] for c in cols) + (sid, uid))

    def list_songs(self, sid: int, query: str = "") -> list[dict]:
        return self._q("SELECT * FROM uploads WHERE school_id=? AND in_library=1 AND name LIKE ? "
                       "ORDER BY name COLLATE NOCASE", (sid, f"%{query}%"))

    def get_upload(self, sid: int, uid: int) -> dict | None:
        rows = self._q("SELECT * FROM uploads WHERE school_id=? AND id=?", (sid, uid))
        return rows[0] if rows else None

    def list_uploads(self, sid: int, limit: int = 30) -> list[dict]:
        return self._q("SELECT * FROM uploads WHERE school_id=? ORDER BY id DESC LIMIT ?", (sid, limit))

    def old_uploads(self, sid: int, before_iso: str) -> list[dict]:
        return self._q("SELECT * FROM uploads WHERE school_id=? AND created_at<? AND in_library=0", (sid, before_iso))

    def delete_upload(self, sid: int, uid: int):
        self._x("DELETE FROM uploads WHERE school_id=? AND id=?", (sid, uid))

    # ----- authorized users -----
    def list_users(self, sid: int) -> list[dict]:
        return self._q("SELECT chat_id, name, added_at, added_by, is_admin FROM authorized_users WHERE school_id=? "
                       "ORDER BY added_at", (sid,))

    def add_user(self, sid: int, chat_id: int, name: str, added_by: str, is_admin: bool = False):
        self._x("INSERT INTO authorized_users(school_id,chat_id,name,added_at,added_by,is_admin) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(school_id,chat_id) DO UPDATE SET name=excluded.name",
                (sid, chat_id, name, _now(), added_by, int(is_admin)))

    def set_admin(self, sid: int, chat_id: int, is_admin: bool):
        self._x("UPDATE authorized_users SET is_admin=? WHERE school_id=? AND chat_id=?", (int(is_admin), sid, chat_id))

    def is_admin(self, sid: int, chat_id: int) -> bool:
        return bool(self._q("SELECT 1 FROM authorized_users WHERE school_id=? AND chat_id=? AND is_admin=1",
                            (sid, chat_id)))

    def delete_user(self, sid: int, chat_id: int):
        self._x("DELETE FROM authorized_users WHERE school_id=? AND chat_id=?", (sid, chat_id))

    def is_user(self, sid: int, chat_id: int) -> bool:
        return bool(self._q("SELECT 1 FROM authorized_users WHERE school_id=? AND chat_id=?", (sid, chat_id)))

    def overrides_between(self, sid: int, start: date, end: date) -> dict:
        rows = self._q("SELECT o.date, o.schedule_id, s.name FROM date_overrides o JOIN schedules s "
                       "ON s.id=o.schedule_id WHERE o.school_id=? AND o.date BETWEEN ? AND ?",
                       (sid, start.isoformat(), end.isoformat()))
        return {date.fromisoformat(r["date"]): r for r in rows}

    def holidays_between(self, sid: int, start: date, end: date) -> set:
        rows = self._q("SELECT date FROM holidays WHERE school_id=? AND date BETWEEN ? AND ?",
                       (sid, start.isoformat(), end.isoformat()))
        return {date.fromisoformat(r["date"]) for r in rows}

    def recent_unauthorized(self, sid: int, limit: int = 50) -> list[dict]:
        return self._q("SELECT actor_id, actor_name, MAX(ts) AS ts, details FROM action_log "
                       "WHERE school_id=? AND action='unauthorized' GROUP BY actor_id ORDER BY ts DESC LIMIT ?",
                       (sid, limit))

    # ----- action log -----
    def log_action(self, sid: int, actor_id: str, actor_name: str, action: str, details: str = ""):
        self._x("INSERT INTO action_log(school_id,ts,actor_id,actor_name,action,details) VALUES(?,?,?,?,?,?)",
                (sid, _now(), actor_id, actor_name, action, details))

    def recent_actions(self, sid: int, limit: int = 20) -> list[dict]:
        return self._q("SELECT * FROM action_log WHERE school_id=? ORDER BY id DESC LIMIT ?", (sid, limit))
