"""Single source of truth for the app version: the VERSION file at the app root."""
from __future__ import annotations

import re
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent


def _read(path: Path, default: str) -> str:
    try:
        return path.read_text(encoding="utf-8-sig").strip() or default
    except OSError:
        return default


def current_version(app_dir: Path = APP_DIR) -> str:
    # installs from before 1.2 had no VERSION file
    return _read(app_dir / "VERSION", "1.1" if (app_dir / "bells" / "web").is_dir() else "1.0")


def vtuple(v: str) -> tuple[int, ...]:
    if not re.fullmatch(r"\d+(\.\d+){0,3}", v.strip()):
        raise ValueError(f"מספר גרסה לא תקין: {v}")
    return tuple(int(x) for x in v.strip().split("."))


def changelog(app_dir: Path = APP_DIR, text: str | None = None) -> dict[str, list[str]]:
    """{'1.2': ['...', ...], ...} parsed from CHANGELOG.md (## <version> headings, '- ' bullets)."""
    text = text if text is not None else _read(app_dir / "CHANGELOG.md", "")
    out: dict[str, list[str]] = {}
    cur = None
    for line in text.splitlines():
        m = re.match(r"^##\s+(\d+(?:\.\d+)*)", line)
        if m:
            cur = m.group(1)
            out[cur] = []
        elif cur and line.strip().startswith("- "):
            out[cur].append(line.strip()[2:].strip())
    return out


VERSION = current_version()
