"""All outgoing HTTPS of the app (Telegram, update source, Google Sheet) goes through here.

- Certificates are verified against the operating system's trust store (Windows certificate store) via the
  bundled `truststore`, exactly like Chrome. Filters / antivirus with HTTPS inspection (NetFree, Rimon, ...)
  install their own root certificate in Windows; Python's own bundle (certifi) doesn't know it, which made
  every Telegram request fail with CERTIFICATE_VERIFY_FAILED while Chrome worked.
- The Windows system proxy (Internet Options / Settings -> Proxy, read from the registry) is honoured.
  Note: automatic proxy scripts (PAC / "automatically detect settings") are not supported – set a manual proxy.
- Connection errors are explained with their real cause (SSL / proxy / DNS / firewall / timeout).
"""
from __future__ import annotations

import logging
import socket
import ssl
import urllib.parse
import urllib.request
from functools import lru_cache

log = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def ssl_context() -> ssl.SSLContext:
    try:
        from ._vendor import truststore
        ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        log.info("HTTPS: using the system certificate store (truststore)")
        return ctx
    except Exception as e:  # never block the app: fall back to Python's default (which loads Windows ROOT certs)
        log.warning("truststore unavailable (%s) – using Python's default certificates", e)
        return ssl.create_default_context()


def system_proxies() -> dict:
    """{'https': 'http://host:port', ...} from environment variables, or on Windows from the registry."""
    try:
        return {k: v for k, v in urllib.request.getproxies().items() if k in ("http", "https", "no")}
    except Exception:
        return {}


def proxy_for(url: str) -> str | None:
    host = urllib.parse.urlsplit(url).hostname or ""
    try:
        if host and urllib.request.proxy_bypass(host):
            return None
    except Exception:
        pass
    p = system_proxies()
    proxy = p.get("https") or p.get("http")
    if proxy and "://" not in proxy:
        proxy = "http://" + proxy
    return proxy


def opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(urllib.request.ProxyHandler(system_proxies()),
                                       urllib.request.HTTPSHandler(context=ssl_context()))


def urlopen(req, timeout: float = 30):
    return opener().open(req, timeout=timeout)


def describe(exc: BaseException) -> tuple[str, str]:
    """-> (short Hebrew explanation, the original error text). Walks the cause chain to the root error."""
    chain, e, seen = [], exc, set()
    while e is not None and id(e) not in seen:
        seen.add(id(e))
        chain.append(e)
        reason = getattr(e, "reason", None)          # urllib.error.URLError keeps the root error in .reason
        e = e.__cause__ or e.__context__ or (reason if isinstance(reason, BaseException) else None)
    text = " | ".join(dict.fromkeys(f"{type(x).__name__}: {x}" for x in chain if str(x)))[:600]
    low = text.lower()
    if any(isinstance(x, ssl.SSLCertVerificationError) for x in chain) or "certificate_verify_failed" in low:
        why = ("חיבור מאובטח נחסם: תעודת אבטחה לא מוכרת (CERTIFICATE_VERIFY_FAILED). "
               "בדרך כלל סינון אינטרנט או אנטי-וירוס שבודק HTTPS")
    elif any(isinstance(x, ssl.SSLError) for x in chain) or "ssl" in low:
        why = "שגיאת SSL בחיבור המאובטח"
    elif "proxy" in low or "407" in low or "tunnel" in low:
        why = "שגיאת פרוקסי (שרת מתווך)"
    elif any(isinstance(x, socket.gaierror) for x in chain) or "getaddrinfo" in low or "name or service" in low \
            or "nodename" in low or "11001" in low:
        why = "לא הצלחתי לתרגם את שם השרת (DNS) – אין אינטרנט או שהשם חסום"
    elif "10013" in low or "forbidden by its access permissions" in low or "permission denied" in low:
        why = "חומת האש / האנטי-וירוס חוסמים את התוכנה מלהתחבר"
    elif "refused" in low or "10061" in low:
        why = "החיבור נדחה (חומת אש או סינון)"
    elif "timed out" in low or "timeout" in low or "10060" in low:
        why = "תם הזמן להתחברות (חומת אש / סינון / רשת איטית)"
    else:
        why = "אין חיבור לשרת"
    from .core.redact import redact
    return why, redact(text)
