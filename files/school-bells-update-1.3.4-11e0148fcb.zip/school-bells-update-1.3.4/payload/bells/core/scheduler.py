"""Background thread that drives BellService.tick every second. Independent of the internet/bot."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta

log = logging.getLogger(__name__)


class Scheduler(threading.Thread):
    def __init__(self, service, clock=datetime.now):
        super().__init__(name="bell-scheduler", daemon=True)
        self.service = service
        self.clock = clock
        self._stop_evt = threading.Event()

    def stop(self):
        self._stop_evt.set()

    def run(self):
        # after a restart (crash / update) catch a bell that was due in the last minute and a half;
        # the service remembers the last bell it handled, so nothing rings twice
        prev = self.clock() - timedelta(seconds=self.service.cfg.fire_grace_seconds)
        while not self._stop_evt.is_set():
            now = self.clock()
            if now < prev - timedelta(seconds=2):  # clock moved backwards (sync / DST)
                log.warning("clock moved back %s -> %s", prev, now)
                prev = now
            try:
                self.service.tick(prev, now)
            except Exception:
                log.exception("tick failed")
            prev = now
            time.sleep(max(0.2, 1.0 - (time.time() % 1.0)))
