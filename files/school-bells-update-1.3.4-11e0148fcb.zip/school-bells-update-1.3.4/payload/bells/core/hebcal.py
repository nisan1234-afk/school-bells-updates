"""Hebrew calendar -> Gregorian, computed locally (no internet).

Arithmetic calendar per Reingold & Dershowitz, "Calendrical Calculations" (molad + dechiyot).
Months are numbered from Nisan = 1 ... Adar = 12, Adar II = 13 (leap years); the year starts at Tishrei = 7.
"""
from __future__ import annotations

from datetime import date
from functools import lru_cache

NISAN, IYAR, SIVAN, TAMMUZ, AV, ELUL, TISHREI, HESHVAN, KISLEV, TEVET, SHEVAT, ADAR, ADAR_II = range(1, 14)
_EPOCH = -1373427  # R.D. (= Python ordinal) of 1 Tishrei, year 1


def is_leap(year: int) -> bool:
    return (7 * year + 1) % 19 < 7


def last_month(year: int) -> int:
    return ADAR_II if is_leap(year) else ADAR


@lru_cache(maxsize=None)
def _elapsed_days(year: int) -> int:
    months = (235 * year - 234) // 19
    parts = 12084 + 13753 * months
    day = 29 * months + parts // 25920
    return day + 1 if (3 * (day + 1)) % 7 < 3 else day


@lru_cache(maxsize=None)
def _new_year(year: int) -> int:
    last, present, nxt = _elapsed_days(year - 1), _elapsed_days(year), _elapsed_days(year + 1)
    correction = 2 if nxt - present == 356 else 1 if present - last == 382 else 0
    return _EPOCH + present + correction


def days_in_year(year: int) -> int:
    return _new_year(year + 1) - _new_year(year)


def days_in_month(year: int, month: int) -> int:
    if month in (IYAR, TAMMUZ, ELUL, TEVET, ADAR_II):
        return 29
    if month == ADAR and not is_leap(year):
        return 29
    if month == HESHVAN and days_in_year(year) % 10 != 5:   # long Heshvan only in 355/385-day years
        return 29
    if month == KISLEV and days_in_year(year) % 10 == 3:    # short Kislev in 353/383-day years
        return 29
    return 30


def to_gregorian(year: int, month: int, day: int) -> date:
    if month < TISHREI:
        days = sum(days_in_month(year, m) for m in range(TISHREI, last_month(year) + 1))
        days += sum(days_in_month(year, m) for m in range(NISAN, month))
    else:
        days = sum(days_in_month(year, m) for m in range(TISHREI, month))
    return date.fromordinal(_new_year(year) + days + day - 1)


def purim_month(year: int) -> int:
    return ADAR_II if is_leap(year) else ADAR


def hebrew_year_of(d: date) -> int:
    """Hebrew year that contains Gregorian date d."""
    y = d.year + 3761
    return y if date.fromordinal(_new_year(y)) <= d else y - 1
