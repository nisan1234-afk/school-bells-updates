"""Pure schedule logic (no I/O) – easy to test and to reuse in a future cloud server."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Callable, Iterable

DAY_NAMES_HE = ["שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת", "ראשון"]

_TIME_RE = re.compile(r"(?<!\d)(\d{1,2})\s*[:.]\s*(\d{2})(?!\d)")
_DATE_RE = re.compile(r"(?<!\d)(\d{1,2})([./])(\d{1,2})(?:\2(\d{2,4}))?(?!\d)")
MAX_RANGE_DAYS = 120


# ---------- parsing ----------
def _fmt(h: int, m: int) -> str:
    if not (0 <= h <= 23 and 0 <= m <= 59):
        raise ValueError(f"שעה לא תקינה: {h}:{m:02d}")
    return f"{h:02d}:{m:02d}"


def parse_time(text: str) -> str:
    m = _TIME_RE.fullmatch(text.strip())
    if not m:
        raise ValueError(f"לא הבנתי את השעה: {text}")
    return _fmt(int(m.group(1)), int(m.group(2)))


def parse_times(text: str) -> list[str]:
    found = [_fmt(int(h), int(m)) for h, m in _TIME_RE.findall(text)]
    if not found:
        raise ValueError("לא נמצאו שעות. כתבו למשל 08:00 או 8:05")
    return sorted(set(found))


def to_time(hhmm: str) -> time:
    h, m = hhmm.split(":")
    return time(int(h), int(m))


def _mk_date(d: str, mth: str, y: str | None, today: date) -> date:
    day, month = int(d), int(mth)
    if y:
        year = int(y)
        if year < 100:
            year += 2000
        return date(year, month, day)
    candidate = date(today.year, month, day)
    if candidate < today:
        candidate = date(today.year + 1, month, day)
    return candidate


def parse_dates(text: str, today: date) -> list[date]:
    """Accepts 'היום', 'מחר', 'dd/mm', 'dd/mm/yyyy', several dates, or a range 'dd/mm-dd/mm' / 'dd/mm עד dd/mm'."""
    t = text.strip()
    if t in ("היום", "today"):
        return [today]
    if t in ("מחר", "tomorrow"):
        return [today + timedelta(days=1)]
    matches = list(_DATE_RE.finditer(t))
    if not matches:
        raise ValueError("לא הבנתי את התאריך. כתבו למשל 24/12 או 24/12-26/12")
    try:
        dates = [_mk_date(m.group(1), m.group(3), m.group(4), today) for m in matches]
    except ValueError:
        raise ValueError("תאריך לא קיים")
    if len(matches) == 2:
        between = t[matches[0].end():matches[1].start()].strip()
        if between in ("-", "–", "עד", "עד ל"):
            start, end = dates
            if end < start:
                raise ValueError("סוף הטווח לפני ההתחלה")
            n = (end - start).days
            if n > MAX_RANGE_DAYS:
                raise ValueError("טווח ארוך מדי")
            return [start + timedelta(days=i) for i in range(n + 1)]
    return sorted(set(dates))


# ---------- day resolution ----------
@dataclass(frozen=True)
class DayPlan:
    day: date
    schedule_id: int | None
    reason: str  # override | holiday | auto_holiday | school_day | regular | off_day
    name: str = ""  # holiday name when known


def resolve_day(day: date, weekday_map: dict[int, int | None], overrides: dict[date, int],
                holidays: dict[date, str], school_days: set[date],
                auto_holidays: dict[date, str]) -> DayPlan:
    """Precedence (first match wins):
    1. a schedule set for this exact date
    2. a holiday the school added (manually / imported / Google Sheet)
    3. "school day" – the school cancelled an automatic holiday -> the weekday's schedule
    4. automatic holiday (official table / Hebrew-calendar computation)
    5. the schedule assigned to this weekday (none on Friday/Shabbat by default)
    """
    if day in overrides:
        return DayPlan(day, overrides[day], "override")
    if day in holidays:
        return DayPlan(day, None, "holiday", holidays[day] or "")
    sid = weekday_map.get(day.weekday())
    if day in school_days:
        return DayPlan(day, sid, "school_day" if sid else "off_day")
    if day in auto_holidays:
        return DayPlan(day, None, "auto_holiday", auto_holidays[day])
    return DayPlan(day, sid, "regular" if sid else "off_day")


def due_times(times: Iterable[str], day: date, prev: datetime, now: datetime, grace_seconds: int) -> list[str]:
    """Bells of `day` whose moment falls in (prev, now], never older than grace_seconds."""
    start = max(prev, now - timedelta(seconds=grace_seconds))
    out = []
    for t in sorted(times):
        dt = datetime.combine(day, to_time(t))
        if start < dt <= now:
            out.append(t)
    return out


def next_bell(now: datetime, plan_for: Callable[[date], tuple[DayPlan, list[str]]],
              days_ahead: int = 30) -> tuple[datetime, DayPlan] | None:
    for i in range(days_ahead + 1):
        d = now.date() + timedelta(days=i)
        plan, times = plan_for(d)
        for t in sorted(times):
            dt = datetime.combine(d, to_time(t))
            if dt > now:
                return dt, plan
    return None


# ---------- mute ----------
@dataclass
class MuteState:
    forever: bool = False
    day: date | None = None
    next_once: bool = False

    def reason_for(self, d: date) -> str | None:
        if self.forever:
            return "forever"
        if self.day == d:
            return "today"
        if self.next_once:
            return "next"
        return None

    def describe(self, today: date) -> str:
        if self.forever:
            return "מושתק עד שיוחזר"
        if self.day == today:
            return "מושתק להיום"
        if self.next_once:
            return "הצלצול הבא יושתק"
        return "אין"


# ---------- audio segments ----------
_SEC_RE = re.compile(r"(?:(\d+):)?(\d+(?:[.,]\d+)?)")


def _secs(tok: str) -> float:
    m = _SEC_RE.fullmatch(tok.strip())
    if not m:
        raise ValueError(f"לא הבנתי '{tok}'. כתבו למשל 20-46 או 0:20-0:46")
    return int(m.group(1) or 0) * 60 + float(m.group(2).replace(",", "."))


def parse_range(text: str, duration: float | None = None, min_len: float = 0.5) -> tuple[float, float]:
    """'20-46', '0:20-0:46', '1:05 עד 1:30', '20 46' -> (start, end) in seconds."""
    t = text.strip().replace("–", "-").replace("עד", "-")
    parts = [p for p in re.split(r"\s*-\s*|\s+", t) if p]
    if len(parts) != 2:
        raise ValueError("כתבו התחלה וסוף, למשל 20-46 או 0:20-0:46")
    start, end = _secs(parts[0]), _secs(parts[1])
    if duration:
        end = min(end, duration)
    if start >= end:
        raise ValueError("הסוף חייב להיות אחרי ההתחלה (ובתוך אורך הקובץ)")
    if end - start < min_len:
        raise ValueError("הקטע קצר מדי")
    return round(start, 2), round(end, 2)


def fmt_secs(s: float) -> str:
    s = max(0.0, float(s))
    m, sec = divmod(s, 60)
    return f"{int(m)}:{sec:04.1f}" if sec % 1 else f"{int(m)}:{int(sec):02d}"
