"""Play queue (pure, no audio). The service drives it; the player only plays the current item."""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from pathlib import Path

_keys = itertools.count(1)


@dataclass
class Track:
    title: str
    path: Path | None          # None = prepared just before playing (e.g. a trimmed library song)
    upload_id: int | None = None
    key: int = field(default_factory=lambda: next(_keys))

    def as_dict(self) -> dict:
        return {"key": self.key, "title": self.title, "upload_id": self.upload_id}


class Playlist:
    def __init__(self):
        self.items: list[Track] = []
        self.index = -1

    @property
    def active(self) -> bool:
        return 0 <= self.index < len(self.items)

    @property
    def current(self) -> Track | None:
        return self.items[self.index] if self.active else None

    @property
    def queue(self) -> list[Track]:
        return self.items[self.index + 1:] if self.active else []

    def load(self, tracks: list[Track]) -> Track | None:
        self.items, self.index = list(tracks), 0 if tracks else -1
        return self.current

    def advance(self) -> Track | None:
        if not self.active:
            return None
        self.index += 1
        if not self.active:
            self.clear()
        return self.current

    def extend(self, tracks: list[Track]) -> Track | None:
        """Adds to the end of the queue; starts playing if nothing was playing. Returns the track to start."""
        if not self.active:
            return self.load(tracks)
        self.items.extend(tracks)
        return None

    def clear(self):
        self.items, self.index = [], -1

    def _queued_pos(self, key: int) -> int:
        for i in range(self.index + 1, len(self.items)):
            if self.items[i].key == key:
                return i
        raise ValueError("השיר לא נמצא בתור")

    def remove(self, key: int) -> Track:
        return self.items.pop(self._queued_pos(key))

    def move(self, key: int, delta: int):
        i = self._queued_pos(key)
        j = max(self.index + 1, min(len(self.items) - 1, i + delta))
        self.items.insert(j, self.items.pop(i))

    def state(self) -> dict:
        return {"current": self.current.as_dict() if self.current else None,
                "queue": [t.as_dict() for t in self.queue]}
