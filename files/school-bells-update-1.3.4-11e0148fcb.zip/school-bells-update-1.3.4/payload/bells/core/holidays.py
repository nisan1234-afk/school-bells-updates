"""School vacation calendar: official per-year table (bells/data/holidays_official.json) where available,
otherwise computed locally from the Hebrew calendar in Ministry-of-Education style. Pure, no I/O except
reading the bundled JSON."""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path

from . import hebcal as H

OFFICIAL_FILE = Path(__file__).resolve().parent.parent / "data" / "holidays_official.json"


@dataclass(frozen=True)
class Span:
    key: str
    name: str
    start: date
    end: date
    source: str  # "official" | "computed"

    def days(self):
        d = self.start
        while d <= self.end:
            yield d
            d += timedelta(days=1)


def _atzmaut(year: int) -> date:
    d = H.to_gregorian(year, H.IYAR, 5)
    wd = d.weekday()  # Mon=0 ... Fri=4, Sat=5
    if wd == 4:       # Friday -> Thursday
        return d - timedelta(days=1)
    if wd == 5:       # Shabbat -> Thursday
        return d - timedelta(days=2)
    if wd == 0:       # Monday -> Tuesday (so Yom HaZikaron isn't on Motzaei Shabbat)
        return d + timedelta(days=1)
    return d


def computed_spans(year: int) -> list[Span]:
    """Vacations of Hebrew year `year` (Tishrei..Elul) computed from the Hebrew calendar."""
    g = H.to_gregorian
    rh = g(year, H.TISHREI, 1)
    purim = g(year, H.purim_month(year), 14)
    summer_year = g(year, H.NISAN, 1).year
    spans = [
        ("rosh_hashana", "ראש השנה", rh - timedelta(days=1), rh + timedelta(days=1)),
        ("sukkot", "יום כיפור וסוכות", g(year, H.TISHREI, 9), g(year, H.TISHREI, 23)),   # Erev YK .. Isru Chag
        ("chanukah", "חנוכה", g(year, H.KISLEV, 25), g(year, H.KISLEV, 25) + timedelta(days=7)),
        ("purim", "פורים", purim, purim + timedelta(days=1)),                               # + Shushan Purim
        ("pesach", "פסח", g(year, H.NISAN, 8), g(year, H.NISAN, 22)),                     # week before .. Isru Chag
        ("atzmaut", "יום העצמאות", _atzmaut(year), _atzmaut(year)),
        ("lag_baomer", 'ל"ג בעומר', g(year, H.IYAR, 18), g(year, H.IYAR, 18)),
        ("shavuot", "שבועות", g(year, H.SIVAN, 5), g(year, H.SIVAN, 7)),                  # Erev .. Isru Chag
        ("summer", "החופש הגדול", date(summer_year, 6, 20), date(summer_year, 8, 31)),
    ]
    return [Span(k, n, a, b, "computed") for k, n, a, b in spans]


@lru_cache(maxsize=1)
def _official() -> dict:
    try:
        return json.loads(OFFICIAL_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def official_spans(year: int) -> list[Span]:
    entry = _official().get(str(year)) or {}
    return [Span(s["key"], s["name"], date.fromisoformat(s["from"]), date.fromisoformat(s["to"]), "official")
            for s in entry.get("spans", [])]


def year_spans(year: int) -> list[Span]:
    """Official spans win per key; computed spans fill the keys the official table doesn't list.
    A computed Sukkot span that includes Yom Kippur is dropped when the official table lists both separately."""
    official = official_spans(year)
    keys = {s.key for s in official}
    computed = [s for s in computed_spans(year) if s.key not in keys]
    return sorted(official + computed, key=lambda s: s.start)


def vacation_days(first_year: int, years: int = 50) -> dict[date, tuple[str, str]]:
    """{date: (name, source)} for Hebrew years first_year .. first_year+years-1."""
    out: dict[date, tuple[str, str]] = {}
    for y in range(first_year, first_year + years):
        for s in year_spans(y):
            for d in s.days():
                out.setdefault(d, (s.name, s.source))
    return out
