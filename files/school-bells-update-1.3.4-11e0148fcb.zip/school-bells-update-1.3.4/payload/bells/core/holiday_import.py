"""Reads vacation days from CSV / Excel (.xlsx) / iCalendar (.ics) files or a published Google Sheet (CSV).

Returns [(date, name)]. A row (or event) with one date = that day; two dates = a range (max 120 days).
For Google Sheets (keywords_only) only rows that say it's a vacation are used ("חופש", "חופשה", ...).
Stdlib only.
"""
from __future__ import annotations

import csv
import io
import re
import urllib.request
import zipfile
from datetime import date, datetime, timedelta
from xml.etree import ElementTree as ET

KEYWORDS = ("חופש", "חופשה", "אין לימודים", "holiday", "vacation", "no school")
MAX_SPAN = 120
_ISO = re.compile(r"(?<!\d)(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)")
_DMY = re.compile(r"(?<!\d)(\d{1,2})[./](\d{1,2})[./](\d{2,4})(?!\d)")
_DM = re.compile(r"(?<!\d)(\d{1,2})[./](\d{1,2})(?![\d./])")


def _dates_in(text: str, today: date) -> list[date]:
    out = []
    for m in _ISO.finditer(text):
        out.append(date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
    rest = _ISO.sub(" ", text)
    for m in _DMY.finditer(rest):
        y = int(m.group(3))
        out.append(date(y + 2000 if y < 100 else y, int(m.group(2)), int(m.group(1))))
    rest = _DMY.sub(" ", rest)
    for m in _DM.finditer(rest):
        d = date(today.year, int(m.group(2)), int(m.group(1)))
        out.append(d if d >= today - timedelta(days=180) else date(today.year + 1, d.month, d.day))
    return out


def _rows_to_entries(rows: list[list], today: date, keywords_only: bool) -> list[tuple[date, str]]:
    has_kw = any(any(k in " ".join(map(str, r)).lower() for k in KEYWORDS) for r in rows)
    out: dict[date, str] = {}
    for row in rows:
        dates, words = [], []
        for cell in row:
            if isinstance(cell, date):
                dates.append(cell)
            elif str(cell).strip():
                try:
                    found = _dates_in(str(cell), today)
                except ValueError:
                    found = []
                (dates.extend(found) if found else words.append(str(cell).strip()))
        if not dates:
            continue
        text = " ".join(words)
        if (keywords_only or has_kw) and not any(k in text.lower() for k in KEYWORDS):
            continue
        name = re.sub(r"\s+", " ", text)[:60]
        start, end = min(dates), max(dates)
        if len(dates) >= 2 and 0 <= (end - start).days <= MAX_SPAN:
            d = start
            while d <= end:
                out.setdefault(d, name)
                d += timedelta(days=1)
        else:
            for d in dates:
                out.setdefault(d, name)
    return sorted(out.items())


def _csv_rows(data: bytes) -> list[list[str]]:
    for enc in ("utf-8-sig", "cp1255", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    try:
        dialect = csv.Sniffer().sniff(text[:4000], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    return [r for r in csv.reader(io.StringIO(text), dialect)]


def _xlsx_rows(data: bytes) -> list[list]:
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", ns):
                shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
        sheets = sorted(n for n in z.namelist() if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"))
        if not sheets:
            return []
        root = ET.fromstring(z.read(sheets[0]))
    rows = []
    for r in root.iter("{%s}row" % ns["m"]):
        row = []
        for c in r.findall("m:c", ns):
            t, v = c.get("t"), c.find("m:v", ns)
            if t == "s" and v is not None:
                row.append(shared[int(v.text)])
            elif t == "inlineStr":
                row.append("".join(x.text or "" for x in c.iter("{%s}t" % ns["m"])))
            elif v is not None and v.text:
                try:
                    num = float(v.text)
                    # Excel stores dates as day numbers since 1899-12-30
                    row.append(date(1899, 12, 30) + timedelta(days=int(num)) if 20000 < num < 80000 else v.text)
                except ValueError:
                    row.append(v.text)
        rows.append(row)
    return rows


def _ics_entries(data: bytes) -> list[tuple[date, str]]:
    text = data.decode("utf-8", "ignore").replace("\r\n ", "").replace("\n ", "")
    out: dict[date, str] = {}
    for ev in re.findall(r"BEGIN:VEVENT(.*?)END:VEVENT", text, re.S):
        def field(name):
            m = re.search(rf"^{name}[^:\n]*:(.*)$", ev, re.M)
            return m.group(1).strip() if m else ""
        s, e = field("DTSTART")[:8], field("DTEND")[:8]
        if not re.fullmatch(r"\d{8}", s):
            continue
        start = datetime.strptime(s, "%Y%m%d").date()
        end = datetime.strptime(e, "%Y%m%d").date() - timedelta(days=1) if re.fullmatch(r"\d{8}", e) else start
        end = max(start, end)  # all-day DTEND is exclusive
        if (end - start).days > MAX_SPAN:
            continue
        d = start
        while d <= end:
            out.setdefault(d, field("SUMMARY").replace("\\,", ",")[:60])
            d += timedelta(days=1)
    return sorted(out.items())


def parse(filename: str, data: bytes, today: date, keywords_only: bool = False) -> list[tuple[date, str]]:
    name = filename.lower()
    if name.endswith(".ics") or data[:15].startswith(b"BEGIN:VCALENDAR"):
        return _ics_entries(data)
    if name.endswith((".xlsx", ".xlsm")) or data[:2] == b"PK":
        try:
            return _rows_to_entries(_xlsx_rows(data), today, keywords_only)
        except (zipfile.BadZipFile, ET.ParseError, KeyError):
            raise ValueError("לא הצלחתי לקרוא את קובץ ה-Excel")
    if name.endswith(".xls"):
        raise ValueError("קובץ Excel ישן (.xls) – שמרו אותו כ-.xlsx או כ-CSV")
    return _rows_to_entries(_csv_rows(data), today, keywords_only)


def fetch_url(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "school-bells"})
    from .. import net
    with net.urlopen(req, timeout=timeout) as r:
        data = r.read(5_000_000)
    if data[:200].lstrip().lower().startswith((b"<!doctype", b"<html")):
        raise ValueError("הקישור לא מחזיר CSV – צריך 'פרסום לאינטרנט' בפורמט CSV")
    return data
