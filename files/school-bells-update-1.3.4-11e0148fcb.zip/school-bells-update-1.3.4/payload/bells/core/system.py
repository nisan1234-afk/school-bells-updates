"""OS helpers (Windows): clock sync, single-instance lock."""
from __future__ import annotations

import errno
import logging
import os
from pathlib import Path
import socket
import subprocess

log = logging.getLogger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def sync_clock() -> tuple[bool, str]:
    if os.name != "nt":
        return False, "not windows"
    try:
        r = subprocess.run(["w32tm", "/resync", "/force"], capture_output=True, timeout=60,
                           creationflags=_NO_WINDOW)
        out = r.stdout.decode("cp1255", "ignore") + r.stderr.decode("cp1255", "ignore")
        return r.returncode == 0, out.strip()
    except Exception as e:
        return False, str(e)


class InstanceLock:
    """Single-instance guard. The exclusive localhost port is authoritative (it worked since 1.0); a file lock on
    data/bells.lock is an extra guard for the same folder. The locked file is never written or truncated
    (Windows byte-range locks are mandatory – writing/truncating a locked file is what broke 1.3.2 startup);
    the pid goes to a separate data/bells.pid."""

    def __init__(self, fh, sock):
        self._fh, self._sock = fh, sock


_HELD = {errno.EACCES, errno.EAGAIN, getattr(errno, "EDEADLK", 36), getattr(errno, "EDEADLOCK", 36), 33}


def _lock_file(path: Path):
    """-> (file handle | None, held_by_other: bool). Unexpected errors never block startup."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(path, "a+b")
    except OSError as e:
        log.warning("lock file unavailable (%s) – using the port lock only", e)
        return None, False
    try:
        if os.name == "nt":
            import msvcrt
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return fh, False
    except OSError as e:
        fh.close()
        if e.errno in _HELD:
            return None, True
        log.warning("lock file error (%s) – using the port lock only", e)
        return None, False


def _lock_port(port: int):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name == "nt":
            s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", -5), 1)  # -5 == ~SO_REUSEADDR
        s.bind(("127.0.0.1", port))
        s.listen(1)
        return s
    except OSError:
        s.close()
        return None


def acquire_single_instance(port: int, lock_file: Path | None = None) -> InstanceLock | None:
    """Returns a lock object to keep for the process lifetime, or None if another instance is running."""
    fh, held = _lock_file(lock_file) if lock_file else (None, False)
    if held:
        return None
    sock = _lock_port(port)
    if sock is None:
        if fh:
            fh.close()
        return None
    if lock_file:
        try:
            lock_file.with_suffix(".pid").write_text(str(os.getpid()))
        except OSError:
            pass
    return InstanceLock(fh, sock)


def running_pid(lock_file: Path) -> str:
    try:
        return lock_file.with_suffix(".pid").read_text().strip()
    except OSError:
        return "?"
