"""Keeps secrets out of logs, the action log and the UI: bot tokens never, chat ids only partially."""
from __future__ import annotations

import logging
import re

_TOKEN_RE = re.compile(r"\d{5,}:[A-Za-z0-9_-]{30,}")
_LONG_ID_RE = re.compile(r"(?<![\d:.\-/])-?\d{6,}(?![\d:.\-/])")


def mask_id(chat_id) -> str:
    s = str(chat_id)
    return "•" * max(3, len(s) - 3) + s[-3:]


def redact(text: str) -> str:
    """Removes bot tokens completely and masks long numeric ids (chat ids)."""
    if not text:
        return text
    text = _TOKEN_RE.sub("[טוקן מוסתר]", str(text))
    text = re.sub(r"bot[^/\s]*:[^/\s]+", "bot[טוקן מוסתר]", text)   # .../bot<token>/... in URLs
    return _LONG_ID_RE.sub(lambda m: mask_id(m.group(0)), text)


class RedactingFormatter(logging.Formatter):
    """Applied to every log handler: even exception text from libraries can't leak the token."""

    def format(self, record: logging.LogRecord) -> str:
        return _TOKEN_RE.sub("[טוקן מוסתר]", super().format(record))
