"""Loading configuration from config.toml (no hard-coded values elsewhere)."""
from __future__ import annotations

import json
import shutil
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

TEMPLATES_DIR = Path(__file__).resolve().parent / "data" / "templates"
# installs from before templates existed were all Alonei HaBashan -> that is the fallback when the key is missing
LEGACY_TEMPLATE = "alonei_habashan"
DAY_KEYS = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}


@dataclass
class Config:
    app_dir: Path
    school_id: int = 1
    school_name: str = "School"
    bot_token: str = ""
    authorized_chat_ids: list[int] = field(default_factory=list)
    late_command_seconds: int = 120
    data_dir: Path = Path("data")
    ffmpeg_path: str | None = None
    target_lufs: float = -14
    default_bell_volume: int = 80
    default_music_volume: int = 60
    regular_name: str = "רגילה"
    seed_schedules: dict = field(default_factory=dict)       # name -> ["HH:MM", ...]
    extra_schedules: list[str] = field(default_factory=list)  # created as copies of the regular one
    weekday_seed: dict = field(default_factory=dict)          # weekday (Mon=0) -> schedule name | None
    template: str = "empty"
    morning_check_minutes_before: int = 30
    notify_time: str = "07:30"
    update_check_at: str = "02:00"
    fire_grace_seconds: int = 90
    lock_port: int = 47831
    time_sync_at: str = "03:00"
    log_level: str = "INFO"
    web_enabled: bool = True
    web_port: int = 8787

    @property
    def bot_enabled(self) -> bool:
        return bool(self.bot_token) and "PUT_BOT_TOKEN" not in self.bot_token

    @property
    def assets_dir(self) -> Path:
        return self.app_dir / "assets"


def find_ffmpeg(app_dir: Path, configured: str) -> str | None:
    if configured and Path(configured).exists():
        return configured
    for name in ("ffmpeg.exe", "ffmpeg"):
        local = app_dir / "tools" / "ffmpeg" / "bin" / name
        if local.exists():
            return str(local)
    return shutil.which("ffmpeg")


def load_config(path: Path, app_dir: Path | None = None) -> Config:
    app_dir = app_dir or path.parent
    raw = tomllib.loads(path.read_text(encoding="utf-8-sig"))
    school = raw.get("school", {})
    tg = raw.get("telegram", {})
    paths = raw.get("paths", {})
    audio = raw.get("audio", {})
    sch = raw.get("schedule", {})
    system = raw.get("system", {})
    web = raw.get("web", {})

    data_dir = Path(paths.get("data_dir", "data"))
    if not data_dir.is_absolute():
        data_dir = app_dir / data_dir

    template = str(sch.get("template", LEGACY_TEMPLATE))
    tfile = TEMPLATES_DIR / f"{template}.json"
    if not tfile.exists():
        raise ValueError(f"unknown schedule template '{template}' (see bells/data/templates)")
    defaults = json.loads(tfile.read_text(encoding="utf-8"))
    seeds = dict(defaults["schedules"])
    regular = sch.get("regular_name", defaults["regular"]) if template == LEGACY_TEMPLATE else defaults["regular"]
    if "regular_bells" in sch:
        seeds[regular] = list(sch["regular_bells"])
    seeds.update({k: list(v) for k, v in sch.get("bells", {}).items()})
    wd_names = {**defaults["weekdays"], **sch.get("weekdays", {})}
    weekday_seed = {DAY_KEYS[k[:3].lower()]: (v or None) for k, v in wd_names.items()}

    return Config(
        app_dir=app_dir,
        school_id=int(school.get("id", 1)),
        school_name=school.get("name", "School"),
        bot_token=str(tg.get("bot_token", "")).strip(),
        authorized_chat_ids=[int(x) for x in tg.get("authorized_chat_ids", [])],
        late_command_seconds=int(tg.get("late_command_seconds", 120)),
        data_dir=data_dir,
        ffmpeg_path=find_ffmpeg(app_dir, paths.get("ffmpeg", "")),
        target_lufs=float(audio.get("target_lufs", -14)),
        default_bell_volume=int(audio.get("default_bell_volume", 80)),
        default_music_volume=int(audio.get("default_music_volume", 60)),
        regular_name=regular,
        seed_schedules=seeds,
        extra_schedules=list(sch.get("extra_schedules", defaults["copies_of_regular"])) if template == LEGACY_TEMPLATE
        else list(defaults["copies_of_regular"]),
        weekday_seed=weekday_seed,
        template=template,
        notify_time=raw.get("notifications", {}).get("time", "07:30"),
        update_check_at=raw.get("updates", {}).get("check_at", "02:00"),
        morning_check_minutes_before=int(sch.get("morning_check_minutes_before", 30)),
        fire_grace_seconds=int(sch.get("fire_grace_seconds", 90)),
        lock_port=int(system.get("lock_port", 47831)),
        time_sync_at=system.get("time_sync_at", "03:00"),
        log_level=system.get("log_level", "INFO"),
        web_enabled=bool(web.get("enabled", True)),
        web_port=int(web.get("port", 8787)),
    )
