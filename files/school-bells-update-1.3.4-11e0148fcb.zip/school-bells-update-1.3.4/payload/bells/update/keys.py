"""Public key(s) of the vendor. Update packages must be signed by the matching private key."""
TRUSTED_PUBLIC_KEYS = [
    "4c6d85aff412d886e3352f4eda6cdd718c483517f27a94e6a570777198ccd40a",
]
