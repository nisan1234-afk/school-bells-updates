"""Inspect (verify signature, version, hashes, paths), stage and launch an update package.

Package layout (zip): school-bells-update-<v>/{manifest.json, manifest.sig, apply_update.py, update.ps1,
update.bat, payload/<files>}. manifest.sig = Ed25519 signature (hex) over manifest.json bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

from ..version import current_version, vtuple
from . import ed25519
from .apply_update import APP_ID, FORMAT, is_allowed_path
from .keys import TRUSTED_PUBLIC_KEYS

MAX_TOTAL = 80 * 1024 * 1024
SCRIPTS = ("apply_update.py", "update.ps1", "update.bat")


class UpdateError(ValueError):
    pass


def _prefix(names: list[str]) -> str:
    mans = [n for n in names if n.endswith("manifest.json") and n.count("/") <= 1]
    if len(mans) != 1:
        raise UpdateError("זה לא קובץ עדכון של מערכת הצלצולים")
    return mans[0][: -len("manifest.json")]


def inspect(zip_path: Path, app_dir: Path, keys: list[str] | None = None) -> dict:
    keys = TRUSTED_PUBLIC_KEYS if keys is None else keys
    try:
        z = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile:
        raise UpdateError("הקובץ אינו zip תקין")
    with z:
        infos = {i.filename: i for i in z.infolist()}
        if sum(i.file_size for i in infos.values()) > MAX_TOTAL:
            raise UpdateError("קובץ העדכון גדול מדי")
        prefix = _prefix(list(infos))
        try:
            man_bytes = z.read(prefix + "manifest.json")
            sig = bytes.fromhex(z.read(prefix + "manifest.sig").decode().strip())
        except (KeyError, ValueError):
            raise UpdateError("לקובץ העדכון חסרה חתימה")
        if not any(ed25519.verify(bytes.fromhex(k), man_bytes, sig) for k in keys):
            raise UpdateError("החתימה לא תקינה – הקובץ אינו עדכון מקורי של המערכת, או שהוא שונה")
        man = json.loads(man_bytes)
        if man.get("app") != APP_ID or man.get("format") != FORMAT:
            raise UpdateError("פורמט עדכון לא מוכר – ייתכן שצריך גרסה חדשה יותר של המערכת")
        cur, new = current_version(app_dir), str(man.get("version", ""))
        if vtuple(new) <= vtuple(cur):
            raise UpdateError(f"הגרסה בקובץ ({new}) אינה חדשה מהגרסה המותקנת ({cur}) – העדכון לא יוחל")
        if man.get("min_from") and vtuple(cur) < vtuple(man["min_from"]):
            raise UpdateError(f"העדכון מתאים רק מגרסה {man['min_from']} ומעלה (מותקנת {cur}) – צריך התקנה מלאה")
        checks = [(prefix + "payload/" + rel, d) for rel, d in man.get("files", {}).items()]
        checks += [(prefix + name, d) for name, d in man.get("scripts", {}).items()]
        for rel in list(man.get("files", {})) + list(man.get("delete", [])):
            if not is_allowed_path(rel):
                raise UpdateError(f"נתיב אסור בעדכון: {rel}")
        if set(man.get("scripts", {})) != set(SCRIPTS):
            raise UpdateError("קובץ העדכון חסר רכיבים")
        for name, digest in checks:
            if name not in infos or hashlib.sha256(z.read(name)).hexdigest() != digest:
                raise UpdateError(f"קובץ פגום בתוך העדכון: {name.split('/', 1)[-1]}")
    return {"version": new, "current": cur, "changes": man.get("changes", []), "files": len(man["files"]),
            "requirements_changed": bool(man.get("requirements_changed")), "prefix": prefix}


def stage(zip_path: Path, info: dict, staging_root: Path) -> Path:
    """Extracts only the verified entries (no zip-slip) to staging_root/<version>."""
    dest = staging_root / info["version"]
    shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True)
    prefix = info["prefix"]
    with zipfile.ZipFile(zip_path) as z:
        man = json.loads(z.read(prefix + "manifest.json"))
        wanted = {"manifest.json": "manifest.json", "manifest.sig": "manifest.sig"}
        wanted.update({s: s for s in SCRIPTS})
        wanted.update({"payload/" + rel: "payload/" + rel for rel in man["files"]})
        for src, rel in wanted.items():
            out = dest / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(prefix + src))
    return dest


def launch(staged: Path, app_dir: Path, python: str | None = None) -> subprocess.Popen:
    """Starts apply_update.py detached, so it survives while it stops and restarts the app."""
    python = python or sys.executable
    args = [python, "-I", str(staged / "apply_update.py"), "--app-dir", str(app_dir), "--package-dir", str(staged),
            "--health-timeout", os.environ.get("BELLS_UPDATE_HEALTH_TIMEOUT", "120")]
    kw = dict(cwd=str(staged), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
    if os.name == "nt":
        base = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
        try:  # leave the Task Scheduler job so stopping the app can't take the updater with it
            return subprocess.Popen(args, creationflags=base | subprocess.CREATE_BREAKAWAY_FROM_JOB, **kw)
        except OSError:
            return subprocess.Popen(args, creationflags=base, **kw)
    return subprocess.Popen(args, start_new_session=True, **kw)
