"""Remote update source: a small JSON manifest that names the latest signed package per channel.

{
  "app": "school-bells", "format": 1,
  "channels": {
    "beta":   {"version": "1.3", "file": "files/school-bells-update-1.3.zip", "sha256": "...", "min_from": "1.1"},
    "stable": {"version": "1.2", "file": "files/school-bells-update-1.2.zip", "sha256": "...", "min_from": "1.1"}
  }
}
"file" may be relative to the manifest URL.

Since 1.3.1 the manifest is signed (manifest.json.sig next to it, Ed25519 by the vendor key) and carries
"beta_devices": [{"id": "SB-XXXX-XXXX-XXXX", "name": "..."}]. A computer gets the beta channel ONLY if its
device id is in that signed list – there is no local setting for the channel, so nobody at a school can switch
to beta by editing settings or files. Every other computer is always on stable. Packages are signed as well.
"""
from __future__ import annotations

import hashlib
import json
import urllib.parse
import urllib.request
from pathlib import Path

from .. import net

MAX_PACKAGE = 80 * 1024 * 1024


class SourceError(Exception):
    """Could not read the update source (network / bad manifest) – not a fault of the installed system."""


def check_url(url: str) -> str:
    url = url.strip()
    p = urllib.parse.urlparse(url)
    local = p.hostname in ("127.0.0.1", "localhost")
    if p.scheme != "https" and not (p.scheme == "http" and local):
        raise ValueError("כתובת מקור העדכונים חייבת להתחיל ב-https://")
    return url


def _get(url: str, limit: int, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "school-bells-updater", "Cache-Control": "no-cache"})
    try:
        with net.urlopen(req, timeout=timeout) as r:
            data = r.read(limit + 1)
    except Exception as e:
        why, detail = net.describe(e)
        raise SourceError(f"{why}: {detail[:200]}") from e
    if len(data) > limit:
        raise SourceError("too large")
    return data


class ManifestRejected(ValueError):
    """The manifest's signature is missing or wrong – possibly tampered with. Nothing is installed."""


def _sig_url(manifest_url: str) -> str:
    p = urllib.parse.urlsplit(manifest_url)
    return urllib.parse.urlunsplit(p._replace(path=p.path + ".sig"))


def _signed_url(manifest_url: str) -> str:
    p = urllib.parse.urlsplit(manifest_url)
    base, _, name = p.path.rpartition("/")
    signed = name[: -len(".json")] + ".signed.json" if name.endswith(".json") else name + ".signed.json"
    return urllib.parse.urlunsplit(p._replace(path=f"{base}/{signed}"))


def fetch_manifest(manifest_url: str, keys: list[str] | None = None) -> dict:
    """Prefers manifest.signed.json (manifest + signature in one file, so a CDN can't mix versions).
    Falls back to manifest.json + manifest.json.sig for sites published before 1.3.4."""
    from . import ed25519
    from .keys import TRUSTED_PUBLIC_KEYS
    keys = TRUSTED_PUBLIC_KEYS if keys is None else keys
    verify = lambda d, s: any(ed25519.verify(bytes.fromhex(k), d, s) for k in keys)  # noqa: E731
    try:
        bundle = json.loads(_get(_signed_url(manifest_url), 1_100_000))
    except (SourceError, ValueError):
        bundle = None
    if isinstance(bundle, dict) and "manifest" in bundle and "sig" in bundle:
        data = str(bundle["manifest"]).encode("utf-8")
        try:
            sig = bytes.fromhex(str(bundle["sig"]).strip())
        except ValueError:
            raise ManifestRejected("חתימת ה-manifest פגומה")
        if not verify(data, sig):
            raise ManifestRejected("חתימת ה-manifest לא תקינה – ייתכן שהקובץ שונה")
    else:
        data = _get(manifest_url, 1_000_000)
        try:
            sig = bytes.fromhex(_get(_sig_url(manifest_url), 1000).decode().strip())
        except SourceError:
            raise ManifestRejected("ל-manifest אין חתימה")
        except ValueError:
            raise ManifestRejected("חתימת ה-manifest פגומה")
        if not verify(data, sig):
            # two separately cached files may briefly disagree right after a publish: try again later
            raise SourceError("ה-manifest והחתימה שלו עדיין מתעדכנים בשרת – ננסה שוב בבדיקה הבאה")
    try:
        man = json.loads(data)
    except ValueError as e:
        raise ManifestRejected("manifest is not valid JSON") from e
    if man.get("app") != "school-bells":
        raise ManifestRejected("not a School Bells manifest")
    return man


def beta_device_ids(man: dict) -> set[str]:
    return {(d.get("id") if isinstance(d, dict) else str(d)).strip().upper() for d in man.get("beta_devices") or []}


def choose_entry(man: dict, manifest_url: str, device: str) -> tuple[str, dict]:
    """beta only for devices listed in the signed manifest; everyone else stable."""
    channels = man.get("channels") or {}
    channel = "beta" if device.upper() in beta_device_ids(man) and channels.get("beta") else "stable"
    entry = channels.get(channel)
    if not entry or not entry.get("version") or not entry.get("file"):
        raise SourceError(f"channel '{channel}' not found in manifest")
    return channel, {**entry, "url": urllib.parse.urljoin(manifest_url, entry["file"])}


def download(entry: dict, dest: Path) -> Path:
    data = _get(entry["url"], MAX_PACKAGE, timeout=120)
    if entry.get("sha256") and hashlib.sha256(data).hexdigest() != entry["sha256"]:
        raise ValueError("קובץ העדכון שהורד פגום (sha256 לא תואם)")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return dest
