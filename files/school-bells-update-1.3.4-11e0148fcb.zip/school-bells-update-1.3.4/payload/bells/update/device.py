"""Stable device id of this computer (shown in Settings -> About).

Derived from the operating system's machine id (Windows: MachineGuid in the registry; Linux: /etc/machine-id),
so it survives reinstalls and can't be changed by editing the app's config or database. Only a hash is shown –
the raw machine id never leaves the computer. Fallback (no machine id readable): a random id kept in data/.
"""
from __future__ import annotations

import base64
import hashlib
import os
import uuid
from functools import lru_cache
from pathlib import Path


def _machine_id() -> str | None:
    if os.name == "nt":
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                 winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0))
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            return str(value)
        except OSError:
            return None
    for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            v = Path(p).read_text().strip()
            if v:
                return v
        except OSError:
            pass
    return None


def _format(raw: str) -> str:
    digest = hashlib.sha256(("school-bells-device:" + raw).encode()).digest()
    code = base64.b32encode(digest).decode()[:12]
    return f"SB-{code[:4]}-{code[4:8]}-{code[8:12]}"


@lru_cache(maxsize=None)
def device_id(data_dir: Path | None = None) -> str:
    raw = _machine_id()
    if not raw and data_dir is not None:
        f = Path(data_dir) / "device_id"
        try:
            raw = f.read_text().strip()
        except OSError:
            raw = uuid.uuid4().hex
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(raw)
    return _format(raw or "unknown")
