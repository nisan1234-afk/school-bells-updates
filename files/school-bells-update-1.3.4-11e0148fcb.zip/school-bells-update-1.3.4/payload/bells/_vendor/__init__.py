"""Third-party code bundled with the app (no pip needed on school computers).

truststore 0.10.5 (MIT) - verify HTTPS with the operating system trust store (Windows certificate store),
so filters / antivirus that install their own root certificate (NetFree, Rimon, ...) work like in Chrome.
"""
