import json
import socket
import sys
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bells.config import load_config  # noqa: E402
from bells.core.service import BellService  # noqa: E402
from bells.player.audio_tools import AudioProcessor  # noqa: E402
from bells.player.player import NullPlayer  # noqa: E402
from bells.storage.db import Storage  # noqa: E402
from bells.web.server import WebServer  # noqa: E402


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


@pytest.fixture
def web(tmp_path):
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    clock = lambda: datetime(2026, 11, 23, 10, 0)  # noqa: E731  Monday 10:00
    svc = BellService(cfg, Storage(tmp_path / "w.db"), NullPlayer(), AudioProcessor(None), clock=clock)
    svc.seed()
    port = free_port()
    srv = WebServer(svc, port)
    srv.start()
    base = f"http://127.0.0.1:{port}"

    def call(method, path, body=None, headers=None, raw=None):
        hdrs = {"Content-Type": "application/json", "X-Bells": "1", **(headers or {})}
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        if method == "POST" and data is None:
            data = b"{}"
        req = urllib.request.Request(base + path, data=data, method=method, headers=hdrs)
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read() or b"null") if "json" in r.headers.get("Content-Type", "") else r.read()
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    yield svc, call
    srv.stop()


def test_security_guards(web):
    svc, call = web
    assert call("POST", "/api/ring", {}, headers={"X-Bells": ""})[0] == 403          # cross-site POST blocked
    assert call("GET", "/api/state", headers={"Host": "evil.example:80"})[0] == 403  # DNS rebinding blocked
    assert not [c for c in svc.player.calls if c[0] == "bell"]
    assert call("GET", "/../config.toml")[0] == 404


def test_state_and_ring(web):
    svc, call = web
    code, st = call("GET", "/api/state")
    assert code == 200 and st["today"]["schedule"] == "רגילה" and len(st["today"]["items"]) == 15
    assert [i["state"] for i in st["today"]["items"]][:5] == ["past", "past", "past", "next", "future"]
    assert st["next"]["at"].endswith("10:30:00")
    assert call("POST", "/api/ring")[0] == 200
    assert svc.player.calls[-1][0] == "bell"
    assert svc.recent_log(1)[0]["actor_name"] == "מחשב הצלצולים"


def test_schedule_editing_is_shared_with_bot(web):
    svc, call = web
    sid = svc.weekday_map()[0]
    code, r = call("POST", f"/api/schedules/{sid}/bells", {"times": "08:15 09:00"})
    assert r == {"added": ["08:15"], "existing": ["09:00"]}
    bell = next(b for b in svc.get_schedule(sid)["bells"] if b["time"] == "08:15")
    assert call("POST", f"/api/bells/{bell['id']}/move", {"time": "8:20"})[0] == 200
    assert "08:20" in svc.day_plan(date(2026, 11, 23))[1]          # the bot sees the same data
    code, err = call("POST", f"/api/bells/{bell['id']}/move", {"time": "25:00"})
    assert code == 400 and "לא תקינה" in err["error"]
    code, r = call("POST", "/api/schedules", {"name": "טיול", "copy_from": sid})
    assert len(svc.get_schedule(r["id"])["bells"]) == 16
    assert call("POST", f"/api/schedules/{sid}/delete")[0] == 400   # assigned to weekdays -> can't delete
    call("POST", "/api/weekdays", {"weekday": 4, "schedule_id": r["id"]})
    assert svc.weekday_map()[4] == r["id"]


def test_calendar_day_modes(web):
    svc, call = web
    d = date(2026, 11, 24)
    short = next(s["id"] for s in svc.list_schedules() if s["name"] == "יום קצר")
    call("POST", "/api/calendar/day", {"date": d.isoformat(), "mode": "holiday"})
    assert svc.day_plan(d)[0].reason == "holiday"
    call("POST", "/api/calendar/day", {"date": d.isoformat(), "mode": "schedule", "schedule_id": short})
    assert svc.day_plan(d)[0].schedule_id == short
    call("POST", "/api/calendar/day", {"date": d.isoformat(), "mode": "auto"})
    assert svc.day_plan(d)[0].reason == "regular"
    code, cal = call("GET", "/api/calendar?month=2026-12")
    dec7 = cal["days"][6]
    assert dec7["reason"] == "auto_holiday" and dec7["auto_source"] == "official" and dec7["name"] == "חנוכה"
    call("POST", "/api/calendar/day", {"date": "2026-12-07", "mode": "school"})
    assert call("GET", "/api/calendar?month=2026-12")[1]["days"][6]["reason"] == "school_day"
    vac = call("GET", "/api/vacations")[1]["upcoming"]
    assert vac[0]["name"] == "חנוכה" and vac[0]["from"] == "2026-12-05"


def test_holiday_import_csv_and_undo(web):
    svc, call = web
    csv_data = "תאריך,סוף,תיאור\n20/01/2027,21/01/2027,חופשת ט\"ו בשבט\n2027-02-15,,יום ספורט – חופש\n".encode("utf-8")
    code, r = call("POST", "/api/holidays/import", raw=csv_data, headers={"X-Filename": "holidays.csv", "Content-Type": "text/csv"})
    assert code == 200 and r["count"] == 3, r
    assert svc.day_plan(date(2027, 1, 21))[0].reason == "holiday"
    call("POST", "/api/holidays/import/undo", {"tag": r["tag"]})
    assert svc.day_plan(date(2027, 1, 21))[0].reason == "regular"


def test_users_and_access_requests(web):
    svc, call = web
    svc.log_unauthorized(555123456, "רחל", "שלום")
    code, st = call("GET", "/api/settings")
    assert [r["name"] for r in st["requests"]] == ["רחל"] and not st["users"]
    assert "555123456" not in json.dumps(st)                          # ids are masked
    call("POST", f"/api/settings/requests/{st['requests'][0]['key']}/approve")
    assert svc.is_authorized(555123456)                                # the bot accepts her immediately
    st = call("GET", "/api/settings")[1]
    assert st["requests"] == [] and st["users"][0]["masked"].endswith("456")
    key = st["users"][0]["key"]
    call("POST", f"/api/settings/users/{key}/admin", {"is_admin": True})
    assert svc.is_admin(555123456)
    assert call("POST", "/api/settings/users", {"chat_id": "abc"})[0] == 400
    call("POST", f"/api/settings/users/{key}/delete")
    assert not svc.is_authorized(555123456)
    log = json.dumps(call("GET", "/api/log")[1], ensure_ascii=False)
    assert "555123456" not in log and "רחל" in log


def test_token_validation_and_hiding(web):
    svc, call = web
    code, err = call("POST", "/api/settings/token", {"token": "not-a-token"})
    assert code == 400 and not svc.bot_token()
    token = "8123456789:AAH" + "Z" * 30 + "wxyz"
    svc.set_bot_token(token, ("1", "x"))
    st = call("GET", "/api/settings")[1]
    assert st["token"] == {"set": True, "last4": "wxyz", "bot": None}
    assert token not in json.dumps(st) and "8123456789" not in json.dumps(st)
    assert call("POST", "/api/settings/token", {"token": token})[0] == 400      # must delete first
    call("POST", "/api/settings/token/delete")
    assert call("GET", "/api/settings")[1]["token"]["set"] is False


def test_ringtone_upload_activate_revert(web):
    svc, call = web
    wav = (ROOT / "assets" / "default_bell.wav").read_bytes()
    code, rt = call("POST", "/api/ringtones/upload", raw=wav,
                    headers={"X-Filename": "Ben_Zur_20-46.wav", "Content-Type": "application/octet-stream"})
    assert code == 200 and rt["name"] == "Ben_Zur_20-46"
    call("POST", f"/api/ringtones/{rt['id']}/activate")
    assert svc.active_ringtone()["id"] == rt["id"]
    code, audio = call("GET", f"/media/ringtone/{rt['id']}")
    assert code == 200 and audio[:4] == b"RIFF"
    call("POST", "/api/ringtones/revert")
    assert svc.active_ringtone()["id"] != rt["id"]


def test_uploads_playlist_and_trim_api(web):
    svc, call = web
    wav = (ROOT / "assets" / "default_bell.wav").read_bytes()
    ids = []
    for n in ("a", "b", "c"):
        code, u = call("POST", "/api/uploads", raw=wav, headers={"X-Filename": f"{n}.wav", "Content-Type": "application/octet-stream"})
        assert code == 200
        ids.append(u["id"])
    code, pl = call("POST", "/api/playlist", {"ids": ids})
    assert pl["current"]["title"] == "a" and [t["title"] for t in pl["queue"]] == ["b", "c"]
    call("POST", "/api/playlist/move", {"key": pl["queue"][1]["key"], "delta": -1})
    code, pl = call("GET", "/api/playlist")
    assert [t["title"] for t in pl["queue"]] == ["c", "b"]
    call("POST", "/api/playlist/remove", {"key": pl["queue"][0]["key"]})
    code, pl = call("POST", "/api/playlist/next")
    assert pl["current"]["title"] == "b" and pl["queue"] == []
    call("POST", "/api/ring")
    assert call("GET", "/api/playlist")[1]["current"] is None          # bell stopped the playlist
    code, peaks = call("GET", f"/api/uploads/{ids[0]}/peaks")
    assert code == 200 and len(peaks["peaks"]) > 50
    code, rt = call("POST", f"/api/uploads/{ids[0]}/ringtone", {})
    assert code == 200 and svc.active_ringtone()["id"] == rt["id"]     # song -> ringtone in one click
    code, body = call("GET", f"/media/upload/{ids[0]}", headers={"Range": "bytes=0-99"})
    assert code == 206 and len(body) == 100


def test_trim_without_ffmpeg_is_explained(web):
    svc, call = web
    wav = (ROOT / "assets" / "default_bell.wav").read_bytes()
    u = call("POST", "/api/uploads", raw=wav, headers={"X-Filename": "x.wav", "Content-Type": "application/octet-stream"})[1]
    code, err = call("POST", f"/api/uploads/{u['id']}/ringtone", {"start": 1, "end": 3})
    assert code == 400 and "ffmpeg" in err["error"]


def test_song_library_api(web):
    svc, call = web
    wav = (ROOT / "assets" / "default_bell.wav").read_bytes()
    up = lambda n, lib="1": call("POST", "/api/uploads", raw=wav,  # noqa: E731
                                 headers={"X-Filename": __import__("urllib.parse").parse.quote(f"{n}.wav"), "X-Library": lib, "Content-Type": "application/octet-stream"})[1]
    a, b = up("שיר א"), up("שיר ב")
    up("רק לצלצול", "0")
    assert [s["name"] for s in call("GET", "/api/songs")[1]] == ["שיר א", "שיר ב"]
    call("POST", f"/api/songs/{a['id']}/rename", {"name": "אאא"})
    st = call("POST", "/api/songs/play", {"ids": [b["id"], a["id"]]})[1]
    assert st["current"]["title"] == "שיר ב" and st["queue"][0]["title"] == "אאא"
    st = call("POST", "/api/songs/enqueue", {"ids": [b["id"]]})[1]
    assert len(st["queue"]) == 2
    assert call("POST", "/api/songs/play", {"shuffle": True})[0] == 200
    call("POST", f"/api/songs/{a['id']}/delete")
    assert [s["name"] for s in call("GET", "/api/songs")[1]] == ["שיר ב"]
    assert call("GET", "/api/songs?q=zzz")[1] == []
