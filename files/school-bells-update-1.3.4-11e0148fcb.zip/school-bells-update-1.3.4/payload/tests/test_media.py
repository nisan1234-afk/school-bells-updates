import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bells.config import load_config  # noqa: E402
from bells.core import logic  # noqa: E402
from bells.core.playlist import Playlist, Track  # noqa: E402
from bells.core.service import BellService  # noqa: E402
from bells.player.audio_tools import AudioProcessor, wav_duration  # noqa: E402
from bells.player.player import NullPlayer  # noqa: E402
from bells.storage.db import Storage  # noqa: E402

FFMPEG = shutil.which("ffmpeg")
needs_ffmpeg = pytest.mark.skipif(not FFMPEG, reason="ffmpeg not installed")
ACTOR = ("1", "טסט")


def test_parse_range():
    assert logic.parse_range("20-46") == (20, 46)
    assert logic.parse_range("0:20-0:46") == (20, 46)
    assert logic.parse_range("1:05 עד 1:30") == (65, 90)
    assert logic.parse_range("12.5 – 20") == (12.5, 20)
    assert logic.parse_range("10-500", duration=60) == (10, 60)       # clamped to file length
    for bad in ("46-20", "20", "abc-def", "10-10.2", "70-80"):
        with pytest.raises(ValueError):
            logic.parse_range(bad, duration=60)
    assert logic.fmt_secs(65) == "1:05" and logic.fmt_secs(20.5) == "0:20.5"


def test_playlist_queue_ops():
    pl = Playlist()
    a, b, c, d = (Track(t, Path(t)) for t in "abcd")
    assert pl.load([a, b, c, d]) is a
    pl.move(d.key, -2)
    assert [t.title for t in pl.queue] == ["d", "b", "c"]
    pl.remove(b.key)
    assert [t.title for t in pl.queue] == ["d", "c"]
    with pytest.raises(ValueError):
        pl.remove(a.key)                       # the current song is not in the queue
    assert pl.advance() is d and pl.advance() is c and pl.advance() is None
    assert not pl.active


@pytest.fixture
def svc(tmp_path):
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    s = BellService(cfg, Storage(tmp_path / "m.db"), NullPlayer(), AudioProcessor(FFMPEG), clock=datetime.now)
    s.seed()
    return s


def tone(path: Path, seconds: int, freq: int = 440) -> Path:
    if FFMPEG:
        subprocess.run([FFMPEG, "-loglevel", "error", "-y", "-f", "lavfi", "-i",
                        f"sine=frequency={freq}:duration={seconds}", str(path)], check=True)
    else:
        shutil.copyfile(ROOT / "assets" / "default_bell.wav", path)
    return path


def media_calls(p):
    return [c for c in p.calls if c[0] == "media"]


def test_playlist_plays_in_order_and_bell_stops_all(svc, tmp_path):
    ids = [svc.stage_upload(tone(tmp_path / f"s{i}.wav", 3, 300 + i * 100), f"שיר {i}", ACTOR)["id"] for i in range(3)]
    st = svc.play_uploads(ids, ACTOR)
    assert st["current"]["title"] == "שיר 0" and [q["title"] for q in st["queue"]] == ["שיר 1", "שיר 2"]
    svc.player.finish()
    svc._track_started -= 5
    svc._playlist_tick()                                    # song ended -> next one starts
    assert svc.playlist_state()["current"]["title"] == "שיר 1"
    assert len(media_calls(svc.player)) == 2
    now = datetime.now()
    svc.ring_now(ACTOR)                                     # a bell interrupts the whole playlist
    assert svc.playlist_state()["current"] is None
    svc.player.finish()
    svc._track_started -= 5
    svc._playlist_tick()
    assert len(media_calls(svc.player)) == 2                # nothing resumed after the bell


def test_scheduled_bell_stops_playlist(svc, tmp_path):
    ids = [svc.stage_upload(tone(tmp_path / f"q{i}.wav", 2), f"q{i}", ACTOR)["id"] for i in range(2)]
    svc.play_uploads(ids, ACTOR)
    day = datetime(2026, 11, 23)                            # Monday
    svc.tick(day.replace(hour=8, minute=59, second=59), day.replace(hour=9))
    assert svc.player.calls[-1][0] == "bell" and not svc.playlist.active


def test_next_and_stop_all(svc, tmp_path):
    ids = [svc.stage_upload(tone(tmp_path / f"n{i}.wav", 2), f"n{i}", ACTOR)["id"] for i in range(2)]
    svc.play_uploads(ids, ACTOR)
    assert svc.playlist_next(ACTOR)["current"]["title"] == "n1"
    assert svc.playlist_next(ACTOR)["current"] is None      # past the end -> stopped
    svc.play_uploads(ids, ACTOR)
    svc.stop_media(ACTOR)
    assert not svc.playlist.active and svc.player.now_playing() is None


@needs_ffmpeg
def test_trim_to_ringtone_and_song(svc, tmp_path):
    u = svc.stage_upload(tone(tmp_path / "long.mp3", 60), "Ben_Zur_20-46", ACTOR)
    assert 59 <= u["duration"] <= 61
    clip, dur = svc.make_clip(u["id"], 20, 46)
    assert 25.5 <= dur <= 26.2
    rt = svc.ringtone_from_upload(u["id"], ACTOR, 20, 46)
    assert svc.active_ringtone()["id"] == rt["id"]
    assert 25.5 <= rt["duration"] <= 26.2                          # the whole segment – no length limit

    svc.play_uploads([u["id"]], ACTOR, start=5, end=15)
    p = svc.playlist.current
    assert 9.5 <= wav_duration(p.path) <= 10.2 and "0:05" in p.title
    with pytest.raises(ValueError):
        svc.make_clip(u["id"], 30, 30.2)
    assert len(svc.upload_peaks(u["id"])) > 100


def test_song_upload_can_become_ringtone(svc, tmp_path):
    u = svc.stage_upload(tone(tmp_path / "x.wav", 5), "שיר", ACTOR)
    svc.play_uploads([u["id"]], ACTOR)
    rt = svc.ringtone_from_upload(svc.playlist.current.upload_id, ACTOR)
    assert svc.active_ringtone()["id"] == rt["id"] and rt["name"] == "שיר"
