import json
import os
import sys
from datetime import datetime
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

import build_update as bu  # noqa: E402
from bells.update import ed25519, package  # noqa: E402
from bells.update.apply_update import is_allowed_path  # noqa: E402

KEY = os.urandom(32)
PUB = [ed25519.public_key(KEY).hex()]
SCRIPTS = {"apply_update.py": (ROOT / "bells/update/apply_update.py").read_bytes(),
           "update.ps1": (ROOT / "tools/update/update.ps1").read_bytes(),
           "update.bat": (ROOT / "tools/update/update.bat").read_bytes()}


def fake_app(tmp_path, version="1.2"):
    app = tmp_path / "app"
    (app / "bells" / "web").mkdir(parents=True)
    (app / "main.py").write_text("")
    if version:
        (app / "VERSION").write_text(version)
    return app


def test_allowed_paths():
    for ok in ("main.py", "bells/core/service.py", "VERSION", "docs/INSTALL_HE.md", "config.example.toml"):
        assert is_allowed_path(ok), ok
    for bad in ("config.toml", "data/bells.db", "../evil.py", "/etc/x", "bells/../data/x", ".venv/x",
                "updates/x", "tools/ffmpeg/bin/ffmpeg.exe", "C:/x", "bells\\x.py", "random.exe", ""):
        assert not is_allowed_path(bad), bad


def test_inspect_rules(tmp_path, monkeypatch):
    app = fake_app(tmp_path)
    good = bu.write_package(tmp_path / "g", "1.3", {"VERSION": b"1.3\n"}, [], SCRIPTS, KEY.hex(), "1.2", ["x"])
    info = package.inspect(good, app, PUB)
    assert info["version"] == "1.3" and info["current"] == "1.2"
    staged = package.stage(good, info, tmp_path / "st")
    assert (staged / "payload" / "VERSION").read_text() == "1.3\n" and (staged / "apply_update.py").exists()
    with pytest.raises(package.UpdateError, match="החתימה"):
        package.inspect(good, app, [ed25519.public_key(os.urandom(32)).hex()])
    old = bu.write_package(tmp_path / "o", "1.1", {"VERSION": b"1.1\n"}, [], SCRIPTS, KEY.hex(), None, [])
    with pytest.raises(package.UpdateError, match="אינה חדשה"):
        package.inspect(old, app, PUB)
    needs = bu.write_package(tmp_path / "n", "1.5", {"VERSION": b"1.5\n"}, [], SCRIPTS, KEY.hex(), "1.4", [])
    with pytest.raises(package.UpdateError, match="רק מגרסה 1.4"):
        package.inspect(needs, app, PUB)
    # a validly signed package that tries to overwrite user data must still be refused
    monkeypatch.setattr(bu, "is_allowed_path", lambda p: True)
    evil = bu.write_package(tmp_path / "e", "1.6", {"data/bells.db": b"x"}, [], SCRIPTS, KEY.hex(), None, [])
    with pytest.raises(package.UpdateError, match="נתיב אסור"):
        package.inspect(evil, app, PUB)
    (tmp_path / "junk.zip").write_bytes(b"not a zip")
    with pytest.raises(package.UpdateError):
        package.inspect(tmp_path / "junk.zip", app, PUB)


def test_version_detection_for_old_installs(tmp_path):
    from bells.version import changelog, current_version
    assert current_version(fake_app(tmp_path, version=None)) == "1.1"
    cl = changelog(ROOT)
    versions = list(cl)
    assert versions[-3:] == ["1.2", "1.1", "1.0"][-3:] or versions[-3:] == ["1.1", "1.0"] or "1.0" == versions[-1]
    assert versions == sorted(versions, key=lambda v: tuple(map(int, v.split("."))), reverse=True) and all(cl.values())
    assert (ROOT / "VERSION").read_text().strip() in cl


def test_update_result_reported_once(tmp_path):
    from bells.config import load_config
    from bells.core.service import BellService
    from bells.player.audio_tools import AudioProcessor
    from bells.player.player import NullPlayer
    from bells.storage.db import Storage
    from bells.version import VERSION
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir, cfg.app_dir = tmp_path / "data", tmp_path
    (tmp_path / "CHANGELOG.md").write_text((ROOT / "CHANGELOG.md").read_text(encoding="utf-8"), encoding="utf-8")
    sent = []

    class N:
        def send(self, t): sent.append(t)
    svc = BellService(cfg, Storage(tmp_path / "x.db"), NullPlayer(), AudioProcessor(None), N(), datetime.now)
    svc.seed()
    (tmp_path / "updates").mkdir()
    (tmp_path / "updates" / "last_result.json").write_text(json.dumps({"status": "ok", "from": "1.1", "to": VERSION}))
    svc.report_update_result()
    assert sent == []                                  # success is routine -> no broadcast (fire and forget)
    (tmp_path / "updates" / "last_result.json").write_text(
        json.dumps({"status": "rolled_back", "from": "1.2", "to": "1.3", "error": "x"}))
    svc.report_update_result()
    svc.report_update_result()
    assert len(sent) == 1 and "נכשל" in sent[0]         # a failed update is a fault -> reported once
