import sys
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bells.config import Config, load_config  # noqa: E402
from bells.core import logic  # noqa: E402
from bells.core.logic import MuteState  # noqa: E402
from bells.core.service import BellService  # noqa: E402
from bells.player.audio_tools import AudioProcessor  # noqa: E402
from bells.player.player import NullPlayer  # noqa: E402
from bells.storage.db import Storage  # noqa: E402

SUNDAY = date(2026, 11, 22)   # יום ראשון
FRIDAY = date(2026, 11, 27)
REGULAR = ["09:00", "09:10", "09:50", "10:30", "10:50", "11:30", "12:10", "12:20",
           "13:00", "13:50", "14:30", "15:10", "15:20", "15:50", "16:30"]
ACTOR = ("1", "טסט")


class Clock:
    def __init__(self, dt): self.dt = dt
    def __call__(self): return self.dt


class Notes:
    def __init__(self): self.sent = []
    def send(self, text): self.sent.append(text)


@pytest.fixture
def env(tmp_path):
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    clock = Clock(datetime.combine(SUNDAY, datetime.min.time()).replace(hour=7))
    player, notes = NullPlayer(), Notes()
    svc = BellService(cfg, Storage(tmp_path / "t.db"), player, AudioProcessor(None), notes, clock)
    svc.seed()
    return svc, clock, player, notes


def run(svc, clock, start: datetime, end: datetime, step=1):
    """Simulates the scheduler loop between two moments."""
    clock.dt = start
    prev = start
    t = start
    while t < end:
        t = t + timedelta(seconds=step)
        clock.dt = t
        svc.tick(prev, t)
        prev = t


def bells(player):
    return [c for c in player.calls if c[0] == "bell"]


# ---------------- pure logic ----------------
def test_parse_times():
    assert logic.parse_times("8:05 09:10, 9.10 23:59") == ["08:05", "09:10", "23:59"]
    assert logic.parse_time(" 7:30 ") == "07:30"
    with pytest.raises(ValueError):
        logic.parse_time("25:00")
    with pytest.raises(ValueError):
        logic.parse_times("שלום")


def test_parse_dates():
    today = date(2026, 11, 23)
    assert logic.parse_dates("היום", today) == [today]
    assert logic.parse_dates("מחר", today) == [date(2026, 11, 24)]
    assert logic.parse_dates("24/12", today) == [date(2026, 12, 24)]
    assert logic.parse_dates("01/01", today) == [date(2027, 1, 1)]          # past -> next year
    assert logic.parse_dates("5.3.2027", today) == [date(2027, 3, 5)]
    rng = logic.parse_dates("30/12-02/01", today)
    assert rng[0] == date(2026, 12, 30) and rng[-1] == date(2027, 1, 2) and len(rng) == 4
    assert len(logic.parse_dates("24/12 עד 26/12", today)) == 3
    assert logic.parse_dates("24/12 26/12", today) == [date(2026, 12, 24), date(2026, 12, 26)]
    with pytest.raises(ValueError):
        logic.parse_dates("31/02", today)


def test_resolve_day_precedence():
    wmap = {6: 10, 0: 1, 1: 1, 2: 1, 3: 11, 4: None, 5: None}
    mon = SUNDAY + timedelta(days=1)
    r = lambda d, ov={}, hol={}, sch=set(), auto={}: logic.resolve_day(d, wmap, ov, hol, sch, auto)  # noqa: E731
    assert r(SUNDAY).schedule_id == 10 and r(mon).schedule_id == 1 and r(FRIDAY).reason == "off_day"
    assert r(mon, auto={mon: "חנוכה"}).reason == "auto_holiday" and r(mon, auto={mon: "חנוכה"}).name == "חנוכה"
    assert r(mon, sch={mon}, auto={mon: "חנוכה"}).schedule_id == 1          # school cancelled the holiday
    assert r(mon, hol={mon: "טיול"}).reason == "holiday"
    assert r(mon, ov={mon: 2}, hol={mon: ""}, auto={mon: "x"}).schedule_id == 2  # explicit schedule wins
    assert r(FRIDAY, ov={FRIDAY: 3}).schedule_id == 3                      # special Friday


def test_due_times_window_and_grace():
    d = SUNDAY
    at = lambda h, m, s=0: datetime(d.year, d.month, d.day, h, m, s)  # noqa: E731
    times = ["09:00", "09:10"]
    assert logic.due_times(times, d, at(8, 59, 59), at(9, 0, 0), 90) == ["09:00"]
    assert logic.due_times(times, d, at(9, 0, 0), at(9, 0, 1), 90) == []       # not twice
    assert logic.due_times(times, d, at(8, 59), at(9, 0, 30), 90) == ["09:00"]   # small lag ok
    assert logic.due_times(times, d, at(8, 0), at(9, 5), 90) == []               # long sleep: skip stale


def test_mute_state():
    m = MuteState(day=SUNDAY)
    assert m.reason_for(SUNDAY) == "today" and m.reason_for(SUNDAY + timedelta(days=1)) is None
    assert MuteState(forever=True).reason_for(FRIDAY) == "forever"
    assert MuteState(next_once=True).reason_for(FRIDAY) == "next"


# ---------------- service ----------------
MONDAY = date(2026, 11, 23)
THURSDAY = date(2026, 11, 26)
SUNDAY_BELLS = ["15:50", "16:30", "17:00", "18:15"]


def test_seed_weekday_schedules(env):
    svc, *_ = env
    assert svc.day_plan(SUNDAY)[1] == SUNDAY_BELLS
    for d in range(1, 4):                                       # Mon..Wed
        plan, times = svc.day_plan(SUNDAY + timedelta(days=d))
        assert times == REGULAR and svc.schedule_name(plan.schedule_id) == "רגילה"
    assert svc.day_plan(THURSDAY)[1] == REGULAR[:9] and svc.day_plan(THURSDAY)[1][-1] == "13:00"
    assert svc.day_plan(FRIDAY)[1] == [] and svc.day_plan(FRIDAY + timedelta(days=1))[1] == []
    names = {s["name"]: s["days"] for s in svc.list_schedules()}
    assert names["ראשון"] == [6] and names["רגילה"] == [0, 1, 2] and names["חמישי"] == [3]
    assert {"יום קצר", "מבחנים", "חג"} <= set(names)
    svc.seed()                                                  # idempotent
    assert svc.day_plan(MONDAY)[1] == REGULAR


def test_upgrade_from_1_1_assigns_weekdays(tmp_path):
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    db = Storage(tmp_path / "old.db")
    db.ensure_school(cfg.school_id, cfg.school_name)           # simulate a 1.1 database
    reg = db.create_schedule(cfg.school_id, "רגילה")
    for t in REGULAR + ["17:00"]:                               # the school edited its regular schedule
        db.add_bell(cfg.school_id, reg, t)
    db.set_setting(cfg.school_id, "active_schedule_id", reg)
    db.set_setting(cfg.school_id, "seeded", "1")
    svc = BellService(cfg, db, NullPlayer(), AudioProcessor(None), Notes(), Clock(datetime(2026, 11, 23, 7)))
    svc.seed()
    assert svc.day_plan(MONDAY)[1][-1] == "17:00"               # kept the school's own regular schedule
    assert svc.day_plan(SUNDAY)[1] == SUNDAY_BELLS and svc.day_plan(THURSDAY)[1][-1] == "13:00"


def test_week_rings_by_weekday(env):
    svc, clock, player, notes = env
    run(svc, clock, datetime(2026, 11, 22, 8, 0), datetime(2026, 11, 28, 20, 0), step=20)
    assert len(bells(player)) == 4 + 15 * 3 + 9                # Sun + Mon..Wed + Thu, nothing Fri/Sat
    assert notes.sent == []                                     # fire and forget: no routine messages


def test_auto_holidays_no_bells_and_override(env):
    svc, clock, player, _ = env
    chanukah = date(2026, 12, 7)                                # Monday, official MoE Chanukah 5–12/12/26
    plan, times = svc.day_plan(chanukah)
    assert plan.reason == "auto_holiday" and plan.name == "חנוכה" and times == []
    svc.set_day_mode(chanukah, "school", ACTOR)                 # the school decides to study that day
    assert svc.day_plan(chanukah)[1] == REGULAR
    svc.set_day_mode(chanukah, "auto", ACTOR)
    assert svc.day_plan(chanukah)[1] == []
    for d, name in [(date(2027, 3, 23), "פורים"), (date(2027, 4, 13), "פסח"), (date(2027, 5, 12), "יום העצמאות"),
                    (date(2027, 5, 25), 'ל"ג בעומר'), (date(2027, 6, 10), "שבועות"), (date(2027, 7, 1), "החופש הגדול")]:
        assert svc.day_plan(d)[0].name == name, d
    assert svc.day_plan(date(2027, 4, 29))[1] == REGULAR[:9]   # Thursday after Pesach (official ends 28/4)
    assert svc.day_plan(date(2027, 9, 1))[1] == REGULAR        # school year starts
    # 50 years ahead, computed from the Hebrew calendar
    assert svc.day_plan(date(2075, 12, 1))[0].reason in ("auto_holiday", "regular", "off_day")
    assert len([d for d in svc.auto_holidays() if d.year == 2070]) > 60


def test_date_override_returns_next_day(env):
    svc, clock, player, _ = env
    short = next(s["id"] for s in svc.list_schedules() if s["name"] == "יום קצר")
    for b in svc.get_schedule(short)["bells"][5:]:
        svc.delete_bell(b["id"], ACTOR)
    svc.set_date_schedule([MONDAY], short, ACTOR)
    assert len(svc.day_plan(MONDAY)[1]) == 5
    assert len(svc.day_plan(MONDAY + timedelta(days=1))[1]) == 15
    run(svc, clock, datetime(2026, 11, 23, 8, 0), datetime(2026, 11, 24, 17, 0), step=20)
    assert len(bells(player)) == 5 + 15


def test_holiday_and_weekday_assignment(env):
    svc, clock, player, _ = env
    svc.add_holidays(logic.parse_dates("23/11-24/11", SUNDAY), ACTOR)
    assert svc.day_plan(MONDAY)[1] == [] and svc.day_plan(MONDAY + timedelta(days=1))[1] == []
    exams = next(s["id"] for s in svc.list_schedules() if s["name"] == "מבחנים")
    svc.add_bells(exams, "08:15", ACTOR)
    svc.set_weekday(2, exams, ACTOR)                            # Wednesday -> exams
    plan, times = svc.day_plan(MONDAY + timedelta(days=2))
    assert plan.schedule_id == exams and "08:15" in times
    with pytest.raises(ValueError, match="משויכת"):
        svc.delete_schedule(exams, ACTOR)
    svc.set_weekday(4, exams, ACTOR)                            # even a Friday can get bells
    assert svc.day_plan(FRIDAY)[1]
    svc.set_weekday(4, None, ACTOR)
    assert svc.day_plan(FRIDAY)[1] == []


def test_edit_add_delete_move(env):
    svc, *_ = env
    reg = svc.weekday_map()[0]
    added, existing = svc.add_bells(reg, "08:00 09:00", ACTOR)
    assert added == ["08:00"] and existing == ["09:00"]
    b = next(b for b in svc.get_schedule(reg)["bells"] if b["time"] == "08:00")
    svc.move_bell(b["id"], "8:20", ACTOR)
    assert "08:20" in svc.day_plan(MONDAY)[1]
    with pytest.raises(ValueError):
        svc.move_bell(b["id"], "09:10", ACTOR)
    svc.delete_bell(b["id"], ACTOR)
    assert svc.day_plan(MONDAY)[1] == REGULAR


def test_mute_next_today_forever(env):
    svc, clock, player, _ = env
    clock.dt = datetime(2026, 11, 23, 8, 0)
    svc.set_mute("next", ACTOR)
    run(svc, clock, datetime(2026, 11, 23, 8, 0), datetime(2026, 11, 23, 9, 15), step=5)
    assert len(bells(player)) == 1          # 09:00 skipped, 09:10 rang
    svc.set_mute("today", ACTOR)
    run(svc, clock, datetime(2026, 11, 23, 9, 15), datetime(2026, 11, 23, 17, 0), step=10)
    assert len(bells(player)) == 1
    run(svc, clock, datetime(2026, 11, 24, 8, 59), datetime(2026, 11, 24, 9, 1), step=5)
    assert len(bells(player)) == 2          # mute-today expired
    svc.set_mute("forever", ACTOR)
    run(svc, clock, datetime(2026, 11, 25, 8, 0), datetime(2026, 11, 25, 17, 0), step=15)
    assert len(bells(player)) == 2
    svc.set_mute("off", ACTOR)
    run(svc, clock, datetime(2026, 11, 26, 8, 59), datetime(2026, 11, 26, 9, 1), step=5)
    assert len(bells(player)) == 3


def test_next_bell(env):
    svc, clock, *_ = env
    clock.dt = datetime(2026, 11, 23, 10, 31)
    assert svc.next_bell()[0] == datetime(2026, 11, 23, 10, 50)
    clock.dt = datetime(2026, 11, 26, 13, 5)        # Thursday after the last bell -> Sunday afternoon
    assert svc.next_bell()[0] == datetime(2026, 11, 29, 15, 50)
    clock.dt = datetime(2026, 11, 29, 16, 31)       # Sunday: 16:30 -> 17:00 -> 18:15
    assert svc.next_bell()[0] == datetime(2026, 11, 29, 17, 0)
    assert "ראשון" in svc.next_bell_text(svc.next_bell())
    clock.dt = datetime(2026, 12, 4, 12, 0)         # Friday before Chanukah -> first day after it
    assert svc.next_bell()[0] == datetime(2026, 12, 13, 15, 50)


def test_bell_interrupts_song(env):
    svc, clock, player, _ = env
    clock.dt = datetime(2026, 11, 23, 10, 29)
    svc.play_song(Path("song.wav"), "שיר", ACTOR)
    assert player.now_playing()["kind"] == "song"
    run(svc, clock, datetime(2026, 11, 23, 10, 29, 50), datetime(2026, 11, 23, 10, 30, 5))
    assert player.now_playing() is None and bells(player)


def test_ringtones_library_and_revert(env, tmp_path):
    svc, *_ = env
    default = svc.active_ringtone()
    assert default and svc.active_ringtone_path().exists()
    src = tmp_path / "x.wav"
    src.write_bytes((ROOT / "assets" / "default_bell.wav").read_bytes())
    rt = svc.import_ringtone(src, "בן צור", ACTOR)
    svc.activate_ringtone(rt["id"], ACTOR)
    assert svc.active_ringtone()["name"] == "בן צור"
    with pytest.raises(ValueError):
        svc.delete_ringtone(rt["id"], ACTOR)
    svc.revert_ringtone(ACTOR)
    assert svc.active_ringtone()["id"] == default["id"]


def test_random_ringtone_rotation(env, tmp_path):
    svc, clock, player, _ = env
    src = tmp_path / "x.wav"
    src.write_bytes((ROOT / "assets" / "default_bell.wav").read_bytes())
    ids = [svc.import_ringtone(src, f"r{i}", ACTOR)["id"] for i in range(3)]
    for i in ids:
        svc.set_rotation(i, True, ACTOR)
    svc.set_ringtone_mode("random", ACTOR)
    played = []
    for _ in range(40):
        expected = svc.upcoming_ringtone()["name"]          # shown in the UI before the bell
        svc.ring_now(ACTOR)
        played.append(svc.recent_log(1)[0]["details"])
        assert played[-1] == expected
    assert set(played) == {"r0", "r1", "r2"}
    assert all(a != b for a, b in zip(played, played[1:]))    # never the same twice in a row
    run(svc, clock, datetime(2026, 11, 23, 8, 59, 50), datetime(2026, 11, 23, 9, 0, 5))
    assert any(r["action"] == "bell" and r["details"].split(" – ")[-1] in {"r0", "r1", "r2"} for r in svc.recent_log(3))
    svc.set_rotation(ids[0], False, ACTOR)
    svc.set_rotation(ids[1], False, ACTOR)
    assert {svc.upcoming_ringtone()["name"] for _ in range(5)} == {"r2"}   # a single one may repeat
    svc.set_ringtone_mode("fixed", ACTOR)
    assert svc.upcoming_ringtone()["id"] == svc.active_ringtone()["id"]


def test_secrets_never_leak(env):
    from bells.core import redact
    svc, *_ = env
    token = "8123456789:AAH" + "x" * 32
    svc.set_bot_token(token, ACTOR)
    svc.add_user(987654321, "רחל", ACTOR)
    assert svc.token_info() == {"set": True, "last4": "xxxx", "bot": None}
    everything = " ".join(str(r) for r in svc.recent_log(50))
    assert token not in everything and "8123456789" not in everything and "987654321" not in everything
    assert all("987654321" not in str(u) for u in svc.list_users())
    assert redact.redact(f"GET https://api.telegram.org/bot{token}/getMe") .count("טוקן מוסתר") == 1
    svc.clear_bot_token(ACTOR)
    assert svc.bot_token() == "" and not svc.token_info()["set"]


def test_quiet_by_default_faults_only(env):
    svc, clock, player, notes = env
    run(svc, clock, datetime(2026, 11, 23, 8, 25), datetime(2026, 11, 23, 8, 35), step=5)
    assert notes.sent == []                                     # no daily status message
    player.healthy = lambda: False                              # audio device unplugged
    run(svc, clock, datetime(2026, 11, 24, 8, 25), datetime(2026, 11, 24, 8, 35), step=5)
    assert len(notes.sent) == 1 and "תקלה" in notes.sent[0]
    player.healthy = lambda: True
    svc.set_notify_option("holiday_today", True, ACTOR)
    svc.set_notify_option("holiday_reminder", True, ACTOR)
    run(svc, clock, datetime(2026, 11, 28, 7, 25), datetime(2026, 11, 28, 7, 35), step=5)   # 7 days before Chanukah
    assert "בעוד שבוע" in notes.sent[-1] and "חנוכה" in notes.sent[-1]
    run(svc, clock, datetime(2026, 12, 7, 7, 25), datetime(2026, 12, 7, 7, 35), step=5)
    assert "היום חופש" in notes.sent[-1]


def test_volumes_and_log(env):
    svc, _, player, _ = env
    assert svc.set_volume("bell", 150, ACTOR)["bell"] == 100
    assert svc.set_volume("music", 30, ACTOR)["music"] == 30
    svc.ring_now(ACTOR)
    assert bells(player)[-1][2] == 100
    actions = [r["action"] for r in svc.recent_log()]
    assert "ring_now" in actions and "volume" in actions
    assert all(r["school_id"] == svc.sid for r in svc.recent_log())


def test_status_text(env):
    svc, clock, *_ = env
    clock.dt = datetime(2026, 11, 23, 10, 0)
    s = svc.status_text()
    assert "רגילה" in s and "שני" in s and "10:30" in s
    clock.dt = datetime(2026, 12, 7, 10, 0)
    assert "חנוכה" in svc.status_text()


@pytest.mark.skipif(not __import__("shutil").which("ffmpeg"), reason="ffmpeg not installed")
def test_ffmpeg_normalize_and_trim(tmp_path):
    import shutil
    ap = AudioProcessor(shutil.which("ffmpeg"))
    src = tmp_path / "long.wav"
    import subprocess
    subprocess.run(["ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=40",
                    "-filter:a", "volume=0.05", str(src)], check=True)
    out, dur = ap.convert(src, tmp_path / "o.wav", normalize=True, max_seconds=20)
    assert 19.5 <= dur <= 20.1
    assert ap.make_preview(out, tmp_path / "p.mp3").exists()


def test_bot_builds(env):
    svc, *_ = env
    svc.cfg.bot_token = "123456:ABCDEF_fake_token_for_build"
    from bells.bot.telegram_bot import BellBot
    app = BellBot(svc).build()
    assert len(app.handlers[0]) >= 5


def test_restart_catches_missed_bell_without_double_ring(env, tmp_path):
    svc, clock, player, notes = env
    run(svc, clock, datetime(2026, 11, 23, 8, 59, 50), datetime(2026, 11, 23, 9, 0, 5))
    assert len(bells(player)) == 1
    # restart (e.g. an update) 40 s later: a new service on the same DB looks back 90 s
    svc2 = BellService(svc.cfg, svc.db, player, svc.audio, notes, clock)
    t = datetime(2026, 11, 23, 9, 0, 40)
    svc2.tick(t - timedelta(seconds=svc.cfg.fire_grace_seconds), t)
    assert len(bells(player)) == 1                       # 09:00 already rang -> not again
    # app was down across 09:10 and restarts at 09:10:30 -> the missed bell still rings
    t = datetime(2026, 11, 23, 9, 10, 30)
    svc3 = BellService(svc.cfg, svc.db, player, svc.audio, notes, clock)
    svc3.tick(t - timedelta(seconds=svc.cfg.fire_grace_seconds), t)
    assert len(bells(player)) == 2


def test_sunday_fix_only_when_untouched(tmp_path):
    def make(sunday_times):
        cfg = load_config(ROOT / "config.example.toml", ROOT)
        cfg.data_dir = tmp_path / str(len(sunday_times))
        db = Storage(cfg.data_dir / "x.db")
        svc = BellService(cfg, db, NullPlayer(), AudioProcessor(None), Notes(), Clock(datetime(2026, 11, 23, 7)))
        svc.seed()                                                     # as installed by an earlier 1.2 build:
        sun = db.get_schedule_by_name(cfg.school_id, "ראשון")["id"]
        for b in db.list_bells(cfg.school_id, sun):
            db.delete_bell(cfg.school_id, b["id"])
        for t in sunday_times:
            db.add_bell(cfg.school_id, sun, t)
        db.set_setting(cfg.school_id, "fix_sunday_2", "")
        svc2 = BellService(cfg, db, NullPlayer(), AudioProcessor(None), Notes(), Clock(datetime(2026, 11, 23, 7)))
        svc2.seed()                                                    # the update starts the new version
        return svc2.day_plan(SUNDAY)[1]
    assert make(["15:50", "16:30", "17:15", "17:30", "18:15"]) == SUNDAY_BELLS    # old default -> fixed
    assert make(["15:50", "16:30", "17:15", "17:45"]) == ["15:50", "16:30", "17:15", "17:45"]  # edited -> kept


def test_new_school_starts_from_empty_template(tmp_path):
    cfg_text = (ROOT / "config.example.toml").read_text(encoding="utf-8").replace(
        'template = "alonei_habashan"', 'template = "empty"').replace("ישיבת אלוני הבשן", "בית ספר חדש")
    (tmp_path / "config.toml").write_text(cfg_text, encoding="utf-8")
    cfg = load_config(tmp_path / "config.toml", ROOT)
    cfg.data_dir = tmp_path / "data"
    svc = BellService(cfg, Storage(cfg.data_dir / "n.db"), NullPlayer(), AudioProcessor(None), Notes(),
                      Clock(datetime(2026, 11, 23, 7)))
    svc.seed()
    assert [s["name"] for s in svc.list_schedules()] == ["רגילה"]
    assert svc.day_plan(MONDAY)[1] == [] and svc.weekday_map()[6] is not None and svc.weekday_map()[4] is None


def test_stop_all_keeps_schedule(env):
    svc, clock, player, _ = env
    run(svc, clock, datetime(2026, 11, 23, 8, 59, 55), datetime(2026, 11, 23, 9, 0, 2))
    svc.play_song(Path("song.wav"), "שיר", ACTOR)
    svc.stop_all(ACTOR)
    assert player.calls[-1] == ("stop_all",) and player.now_playing() is None and not svc.playlist.active
    run(svc, clock, datetime(2026, 11, 23, 9, 9, 55), datetime(2026, 11, 23, 9, 10, 2))
    assert len(bells(player)) == 2                               # the next bell rang as usual
