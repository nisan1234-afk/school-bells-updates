import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bells.config import load_config  # noqa: E402
from bells.core.service import BellService  # noqa: E402
from bells.player.audio_tools import AudioProcessor, wav_duration  # noqa: E402
from bells.player.player import NullPlayer  # noqa: E402
from bells.storage.db import Storage  # noqa: E402

FFMPEG = shutil.which("ffmpeg")
pytestmark = pytest.mark.skipif(not FFMPEG, reason="ffmpeg not installed")
A = ("1", "טסט")


@pytest.fixture
def svc(tmp_path):
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    s = BellService(cfg, Storage(tmp_path / "l.db"), NullPlayer(), AudioProcessor(FFMPEG), clock=datetime.now)
    s.seed()
    return s


def song(svc, tmp_path, name, seconds=30, freq=440, library=True):
    src = tmp_path / f"{name}.mp3"
    subprocess.run([FFMPEG, "-loglevel", "error", "-y", "-f", "lavfi", "-i", f"sine=frequency={freq}:duration={seconds}",
                    str(src)], check=True)
    return svc.stage_upload(src, name, A, library=library)


def test_songs_are_kept_compressed_with_waveform(svc, tmp_path):
    u = song(svc, tmp_path, "שיר א", 60)
    assert u["abs_path"].suffix == ".ogg" and u["abs_path"].stat().st_size < 1_500_000   # ~1 MB/min, not 10
    assert 59 <= u["duration"] <= 61 and len(svc.upload_peaks(u["id"])) > 100
    old = svc.now() - timedelta(days=30)
    svc.db._x("UPDATE uploads SET created_at=?", (old.isoformat(),))
    svc._maintenance()                                         # weekly cleanup must not touch the library
    assert [s["name"] for s in svc.list_songs()] == ["שיר א"]


def test_ringtone_only_uploads_are_temporary(svc, tmp_path):
    u = song(svc, tmp_path, "לצלצול", library=False)
    assert svc.list_songs() == []
    svc.db._x("UPDATE uploads SET created_at=?", ((svc.now() - timedelta(days=8)).isoformat(),))
    svc._maintenance()
    with pytest.raises(ValueError):
        svc.get_upload(u["id"])


def test_trim_is_saved_and_used_everywhere(svc, tmp_path):
    u = song(svc, tmp_path, "בן צור", 60)
    v = svc.set_song_trim(u["id"], 20, 46, A)
    assert (v["trim_start"], v["trim_end"]) == (20, 46) and abs(v["length"] - 26) < 0.1
    svc.play_uploads([u["id"]], A)                             # plays the saved segment
    assert 25.5 <= wav_duration(svc.playlist.current.path) <= 26.2 and "✂️" in svc.playlist.current.title
    rt = svc.ringtone_from_upload(u["id"], A)                  # one click -> ringtone of that whole segment
    assert svc.active_ringtone()["id"] == rt["id"] and 25.5 <= rt["duration"] <= 26.2
    svc.play_uploads([u["id"]], A, start=5, end=15)            # trimming while playing saves the new segment
    assert svc.list_songs()[0]["trim_start"] == 5
    svc.set_song_trim(u["id"], 0, 60, A)                       # whole song = no trim
    assert svc.list_songs()[0]["trim_end"] is None


def test_library_play_all_shuffle_selection_queue(svc, tmp_path):
    ids = [song(svc, tmp_path, n, 3, 300 + i * 50)["id"] for i, n in enumerate(["ג", "א", "ב", "ד"])]
    assert [s["name"] for s in svc.list_songs()] == ["א", "ב", "ג", "ד"]          # alphabetical
    st = svc.play_library(A)
    assert [st["current"]["title"]] + [t["title"] for t in st["queue"]] == ["א", "ב", "ג", "ד"]
    orders = {tuple([svc.play_library(A, shuffle=True)["current"]["title"]]) for _ in range(20)}
    assert len(orders) > 1                                                       # shuffled
    st = svc.play_library(A, [ids[2], ids[0]])                                   # a selection, in that order
    assert st["current"]["title"] == "ב" and [t["title"] for t in st["queue"]] == ["ג"]
    st = svc.enqueue([ids[3]], A)
    assert [t["title"] for t in st["queue"]] == ["ג", "ד"]
    svc.stop_all(A)
    st = svc.enqueue([ids[1]], A)                                                # nothing playing -> starts
    assert st["current"]["title"] == "א"
    assert [s["name"] for s in svc.list_songs("ב")] == ["ב"]


def test_no_length_limit(svc, tmp_path):
    u = song(svc, tmp_path, "ארוך", 75)                          # longer than the old 20 s / any cap
    rt = svc.ringtone_from_upload(u["id"], A)                  # untrimmed -> full length, normalized
    assert 74 <= rt["duration"] <= 76
    long_song = song(svc, tmp_path, "ארוך מאוד", 17 * 60, 220)  # longer than the old 15-minute song limit
    assert 17 * 60 - 1 <= long_song["duration"] <= 17 * 60 + 1


def test_rename_and_delete(svc, tmp_path):
    u = song(svc, tmp_path, "ישן", 3)
    svc.rename_song(u["id"], "חדש", A)
    assert svc.list_songs()[0]["name"] == "חדש"
    svc.play_uploads([u["id"]], A)
    svc.delete_song(u["id"], A)                                # deleting the playing song stops it
    assert svc.list_songs() == [] and not svc.playlist.active and not u["abs_path"].exists()
