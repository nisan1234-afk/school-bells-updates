import io
import sys
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bells.core import hebcal as H  # noqa: E402
from bells.core import holiday_import as HI  # noqa: E402
from bells.core import holidays as HD  # noqa: E402

TODAY = date(2026, 11, 23)


def test_hebrew_calendar_known_dates():
    assert H.to_gregorian(5787, H.TISHREI, 1) == date(2026, 9, 12)       # Rosh Hashana 5787
    assert H.to_gregorian(5786, H.TISHREI, 1) == date(2025, 9, 23)
    assert H.to_gregorian(5785, H.TISHREI, 1) == date(2024, 10, 3)
    assert H.to_gregorian(5787, H.KISLEV, 25) == date(2026, 12, 5)        # MoE: Chanukah 5.12.26
    assert H.to_gregorian(5787, H.purim_month(5787), 14) == date(2027, 3, 23)
    assert H.to_gregorian(5787, H.NISAN, 15) == date(2027, 4, 22)
    assert H.to_gregorian(5787, H.SIVAN, 6) == date(2027, 6, 11)
    assert H.hebrew_year_of(date(2026, 9, 11)) == 5786 and H.hebrew_year_of(date(2026, 9, 12)) == 5787


def test_against_reference_library_if_available():
    pyluach = pytest.importorskip("pyluach.dates")
    for y in range(5780, 5840):
        for m in range(1, H.last_month(y) + 1):
            assert H.to_gregorian(y, m, 1) == pyluach.HebrewDate(y, m, 1).to_pydate()


def test_official_5787_wins_and_computed_rules():
    spans = {s.key: s for s in HD.year_spans(5787)}
    assert all(s.source == "official" for s in spans.values())
    assert (spans["pesach"].start, spans["pesach"].end) == (date(2027, 4, 13), date(2027, 4, 28))
    assert spans["summer"].start == date(2027, 6, 21)
    c = {s.key: s for s in HD.computed_spans(5788)}                         # no official table -> computed
    assert c["sukkot"].start == H.to_gregorian(5788, H.TISHREI, 9)          # from Erev Yom Kippur
    assert c["sukkot"].end == H.to_gregorian(5788, H.TISHREI, 23)           # to Isru Chag
    assert (c["chanukah"].end - c["chanukah"].start).days == 7              # all 8 days
    assert (c["purim"].end - c["purim"].start).days == 1                    # Purim + Shushan Purim
    assert c["pesach"].start == H.to_gregorian(5788, H.NISAN, 8) and c["pesach"].end == H.to_gregorian(5788, H.NISAN, 22)
    assert c["summer"].start == date(2028, 6, 20) and c["summer"].end == date(2028, 8, 31)


@pytest.mark.parametrize("year,expected", [
    (5788, date(2028, 5, 2)),    # 5 Iyar = Monday -> Tuesday
    (5784, date(2024, 5, 14)),   # 5 Iyar = Tuesday (no shift)
    (5785, date(2025, 5, 1)),    # 5 Iyar = Saturday -> Thursday
    (5783, date(2023, 4, 26)),   # 5 Iyar = Wednesday
])
def test_atzmaut_shift_rules(year, expected):
    assert HD._atzmaut(year) == expected


def test_fifty_years_table():
    days = HD.vacation_days(5787, 50)
    years = {d.year for d in days}
    assert min(years) == 2026 and max(years) >= 2076
    for y in range(2027, 2076):   # every civil year has the core vacations
        names = {n for d, (n, _) in days.items() if d.year == y}
        assert {"חנוכה", "החופש הגדול"} <= names or y == 2026, y


def test_import_csv_xlsx_ics():
    csv_bytes = "תיאור;מתאריך;עד\nחופשת חורף;10/02/2027;12/02/2027\nכותרת בלי תאריך;;\n".encode("cp1255")
    e = HI.parse("x.csv", csv_bytes, TODAY)
    assert [d for d, _ in e] == [date(2027, 2, 10), date(2027, 2, 11), date(2027, 2, 12)] and "חורף" in e[0][1]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:      # minimal xlsx: a date serial cell + a shared string
        z.writestr("xl/sharedStrings.xml", '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                                           '<si><t>יום ספורט</t></si></sst>')
        z.writestr("xl/worksheets/sheet1.xml", '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<sheetData><row r="1"><c r="A1"><v>46437</v></c><c r="B1" t="s"><v>0</v></c></row></sheetData></worksheet>')
    e = HI.parse("x.xlsx", buf.getvalue(), TODAY)
    assert e == [(date(1899, 12, 30) + timedelta(days=46437), "יום ספורט")]

    ics = (b"BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nDTSTART;VALUE=DATE:20270301\r\nDTEND;VALUE=DATE:20270303\r\n"
           b"SUMMARY:\xd7\x97\xd7\x95\xd7\xa4\xd7\xa9\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n")
    e = HI.parse("cal.ics", ics, TODAY)
    assert [d for d, _ in e] == [date(2027, 3, 1), date(2027, 3, 2)]        # DTEND is exclusive


def test_gsheet_keywords_only_and_offline_keeps_copy(tmp_path):
    from bells.config import load_config
    from bells.core.service import BellService
    from bells.player.audio_tools import AudioProcessor
    from bells.player.player import NullPlayer
    from bells.storage.db import Storage
    cfg = load_config(ROOT / "config.example.toml", ROOT)
    cfg.data_dir = tmp_path
    svc = BellService(cfg, Storage(tmp_path / "g.db"), NullPlayer(), AudioProcessor(None), None,
                      lambda: datetime(2026, 11, 23, 9))
    svc.seed()
    sheet = "תאריך,הערה\n25/01/2027,חופש – ישיבת צוות\n26/01/2027,יום לימודים רגיל\n".encode()
    svc.db.set_setting(svc.sid, "gsheet_url", "https://docs.google.com/x/pub?output=csv")
    svc.sync_gsheet(fetch=lambda url: sheet)
    assert svc.day_plan(date(2027, 1, 25))[0].reason == "holiday"
    assert svc.day_plan(date(2027, 1, 26))[0].reason == "regular"           # no "vacation" word -> ignored

    def offline(url):
        raise OSError("no internet")
    st = svc.sync_gsheet(fetch=offline)
    assert "בעותק האחרון" in st["status"]
    assert svc.day_plan(date(2027, 1, 25))[0].reason == "holiday"           # last copy still used
    with pytest.raises(ValueError):
        svc.set_gsheet_url("http://insecure.example/x.csv", ("1", "x"))
