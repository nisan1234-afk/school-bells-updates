# school-bells – מערכת צלצולים לבית ספר

מערכת צלצולים למחשב Windows שמחובר למגבר, עם שליטה מבוט טלגרם.
הכול רץ על המחשב המקומי: אין שרת ענן ואין צורך לפתוח פורטים.

**מדריך התקנה:** [docs/INSTALL_HE.md](docs/INSTALL_HE.md)

## מבנה הקוד

| תיקייה | תפקיד |
|---|---|
| `bells/core` | לוגיקת לוח זמנים (`logic.py`, טהורה ונבדקת), `service.py` (ממשק אחד לכל הפעולות), `scheduler.py` (תהליכון שמצלצל, לא תלוי באינטרנט) |
| `bells/storage` | SQLite. כל רשומה עם `school_id` |
| `bells/player` | ניגון (pygame) ועיבוד שמע (ffmpeg: נרמול, קיצור) |
| `bells/bot` | בוט טלגרם (long polling) והתראות יוצאות |
| `bells/web` | ממשק מקומי (127.0.0.1 בלבד): שרת JSON דק מעל `BellService` ודף HTML/JS בלי תלויות חיצוניות |
| `bells/update` | עדכוני תוכנה: אימות חתימה (Ed25519 בפייתון טהור), `apply_update.py` (גיבוי, החלפה, בדיקת תקינות, חזרה לאחור) |
| `main.py` / `launcher.py` | הפעלה ו-watchdog |

כל ההגדרות (טוקן, משתמשים, נתיבים, שעות התחלתיות) נמצאות ב-`config.toml`. אין ערכים קבועים בקוד.

הבוט והממשק המקומי קוראים רק ל-`BellService`, בלי לוגיקה משלהם. כך אפשר בעתיד להוסיף ממשק נוסף, או להעביר את השירות לענן ולשרת כמה בתי ספר.

## בדיקות

```bash
pip install -r requirements-dev.txt
```

```bash
python -m pytest -q
```

## פיתוח: יצירת צלצול ברירת המחדל מחדש

```bash
python tools/make_default_bell.py
```

## שחרור גרסה (למפתח)

### מקור העדכונים – הכי פשוט: ריפו ציבורי בגיטהאב

1. יוצרים ריפו ריק, למשל `school-bells-updates`, ומשכפלים אותו לתיקייה ליד הקוד.
2. כתובת המקור שמדביקים בכל בית ספר:
   `https://raw.githubusercontent.com/<user>/school-bells-updates/main/manifest.json`
3. החבילות חתומות, ולכן אחסון ציבורי בטוח: אף אחד לא יכול להחדיר עדכון בלי המפתח הפרטי.

שימו לב:
- בקבצי העדכון יש את קוד התוכנה. כשתרצו להסתיר אותו (מכירה), אפשר להעביר את אותה תיקייה לכל אחסון קבצים סטטי, למשל Cloudflare R2 או Netlify, ולשנות רק את הכתובת.
- דרייב פחות מתאים: לכל קובץ יש מזהה משתנה, וקבצים גדולים מקבלים דף אזהרה במקום הקובץ.

### מחשבי בדיקה

רק מחשב שמזהה המכשיר שלו נמצא ברשימה החתומה מקבל את ערוץ הבדיקה. המזהה מופיע במסך **אודות** במחשב או בבוט (`/about`).

```bash
python tools/publish.py device-add SB-XXXX-XXXX-XXXX --name "מחשב בדיקה" --site ../school-bells-updates --key ~/school-bells-signing/private_key.hex --push
```

להסרה: `device-remove`. כל שינוי ב-`manifest.json` נחתם מחדש, ושינוי בלי המפתח נדחה בכל המחשבים.

### פרסום

1. מעדכנים את `VERSION` ואת `CHANGELOG.md`, עושים commit ומסמנים tag (`git tag v1.3`).
2. מפרסמים לערוץ **בדיקה**:

```bash
python tools/publish.py beta --site ../school-bells-updates --key ~/school-bells-signing/private_key.hex --push
```

   מחשב הבדיקה מקבל את העדכון בלילה, או מיד עם `/update`.

3. אחרי שהעדכון עבד על מחשב הבדיקה, מקדמים לכל בתי הספר:

```bash
python tools/publish.py promote --site ../school-bells-updates --key ~/school-bells-signing/private_key.hex --push
```

כדי לראות מה נמצא בכל ערוץ:

```bash
python tools/publish.py status --site ../school-bells-updates
```

החבילות מצטברות מגרסה `--base` (ברירת מחדל `v1.1`), כך שבית ספר שדילג על גרסאות מתעדכן בצעד אחד.

**בית ספר חדש:** בקובץ `config.example.toml` מגדירים `template = "empty"` (או תבנית משלו ב-`bells/data/templates`) ואת שם בית הספר. התבנית משמשת רק בהתקנה הראשונה.

**המפתח הפרטי לא נכנס לריפו.** בלעדיו אי אפשר להוציא עדכונים, ולכן חשוב לשמור עליו ולגבות אותו.
