#!/usr/bin/env python3
"""Applies a School Bells update package to an installed app folder.

Standalone (stdlib only) so it can run from the extracted package, before the new code is installed.
Started by update.bat (manual, one time) or by the running app after it verified the package signature.

Steps: checks -> verify file hashes -> backup -> stop app -> replace files -> (pip) -> start app
       -> health check (new version answers) -> on any failure: restore backup, start old version.
Never touches data/, config.toml, .venv/ or updates/ (except writing its own logs/backups under updates/).

Exit codes: 0 updated, 1 failed and rolled back, 2 rejected (nothing changed).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

FORMAT = 1
APP_ID = "school-bells"
TASK_NAME = "SchoolBells"
ROOT_FILES = {
    "main.py", "launcher.py", "VERSION", "CHANGELOG.md", "README.md", "requirements.txt", "requirements-dev.txt",
    "config.example.toml", "install.ps1", "install.bat", "restart.ps1", "restart.bat", "stop.bat",
    "uninstall.ps1", "uninstall.bat", "run_console.bat", "update.bat",
}
ROOT_DIRS = ("bells/", "assets/", "docs/", "tools/", "tests/")
FORBIDDEN = ("data/", "updates/", ".venv/", "tools/ffmpeg/", "config.toml", ".git/")
KEEP_BACKUPS = 3
IS_WIN = os.name == "nt"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if IS_WIN else 0


class Rejected(Exception):
    pass


def is_allowed_path(rel: str) -> bool:
    if not rel or "\\" in rel or rel.startswith("/") or ":" in rel:
        return False
    parts = rel.split("/")
    if any(p in ("", ".", "..") for p in parts):
        return False
    if any(rel == f.rstrip("/") or rel.startswith(f) for f in FORBIDDEN):
        return False
    return rel in ROOT_FILES or rel.startswith(ROOT_DIRS)


def vtuple(v: str) -> tuple[int, ...]:
    if not re.fullmatch(r"\d+(\.\d+){0,3}", str(v).strip()):
        raise Rejected(f"bad version: {v}")
    return tuple(int(x) for x in str(v).strip().split("."))


def installed_version(app_dir: Path) -> str:
    try:
        v = (app_dir / "VERSION").read_text(encoding="utf-8-sig").strip()
        if v:
            return v
    except OSError:
        pass
    return "1.1" if (app_dir / "bells" / "web").is_dir() else "1.0"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


class Log:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.f = open(path, "a", encoding="utf-8")

    def __call__(self, msg: str):
        line = f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
        print(line, flush=True)
        self.f.write(line + "\n")
        self.f.flush()


# ---------------- process control ----------------
def _list_processes() -> list[tuple[int, str]]:
    if IS_WIN:
        cmd = ("Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
               "Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress")
        r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, timeout=60,
                           creationflags=NO_WINDOW)
        try:
            data = json.loads(r.stdout.decode("utf-8", "ignore") or "[]")
        except json.JSONDecodeError:
            return []
        if isinstance(data, dict):
            data = [data]
        return [(int(x["ProcessId"]), x.get("CommandLine") or "") for x in data]
    out = []
    for d in Path("/proc").iterdir():
        if d.name.isdigit():
            try:
                out.append((int(d.name), (d / "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "ignore")))
            except OSError:
                pass
    return out


def app_processes(app_dir: Path) -> list[int]:
    key = str(app_dir.resolve())
    norm = (lambda s: s.lower().replace("/", "\\")) if IS_WIN else (lambda s: s)
    key = norm(key)
    pids = []
    for pid, cmd in _list_processes():
        c = norm(cmd)
        # never the updater itself (on Windows the venv launcher + real python both carry "apply_update").
        # NOT excluding the parent: when started from the app, the parent IS the app that must stop.
        if pid == os.getpid() or "apply_update" in c or key not in c:
            continue
        if "main.py" in c or "launcher.py" in c:
            pids.append(pid)
    return pids


def stop_app(app_dir: Path, log: Log, timeout: int = 30):
    for attempt in range(timeout):
        pids = app_processes(app_dir)
        if not pids:
            log("app stopped")
            return
        for pid in pids:
            try:
                if IS_WIN:
                    subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, creationflags=NO_WINDOW)
                else:
                    os.kill(pid, signal.SIGKILL if attempt > 3 else signal.SIGTERM)
            except (OSError, subprocess.SubprocessError):
                pass
        time.sleep(1)
    raise RuntimeError("could not stop the running app")


def _start_direct(app_dir: Path, log: Log):
    if IS_WIN:
        py = app_dir / ".venv" / "Scripts" / "pythonw.exe"
        flags = (getattr(subprocess, "DETACHED_PROCESS", 0x8) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x200)
                 | NO_WINDOW)
        subprocess.Popen([str(py if py.exists() else sys.executable), str(app_dir / "launcher.py")], cwd=str(app_dir),
                         creationflags=flags, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        subprocess.Popen([sys.executable, str(app_dir / "launcher.py")], cwd=str(app_dir), start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log("started launcher directly")


def start_app(app_dir: Path, log: Log, wait_seconds: int = 20):
    """Windows: ask Task Scheduler (the app must run in the user's session for audio). Task Scheduler answers
    'SUCCESS' even when it ignores the request (e.g. it still sees the old instance as running), so we check
    that the app really appeared and otherwise start the launcher ourselves (same user session)."""
    if IS_WIN:
        r = subprocess.run(["schtasks", "/Run", "/TN", TASK_NAME], capture_output=True, creationflags=NO_WINDOW)
        log(f"schtasks /Run -> {r.returncode}")
        if r.returncode == 0:
            for _ in range(wait_seconds):
                time.sleep(1)
                if app_processes(app_dir):
                    log("started via Task Scheduler")
                    return
            log("Task Scheduler did not start the app")
    _start_direct(app_dir, log)


def _tail(path: Path, lines: int) -> str:
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 64_000))
            data = f.read().decode("utf-8", "replace").splitlines()
        return "\n".join(data[-lines:])
    except OSError:
        return ""


def diagnostics(app_dir: Path, since: float) -> str:
    """The end of the logs of the version that failed to start – shown in the update error window."""
    logs = app_dir / "data" / "logs"
    parts = []
    for name, n in (("main-stderr.log", 40), ("bells.log", 30), ("launcher.log", 10)):
        p = logs / name
        try:
            if p.stat().st_mtime < since - 5:
                continue                       # not touched by the failed start
        except OSError:
            continue
        t = _tail(p, n).strip()
        if t:
            parts.append(f"== {name} ==\n{t}")
    return "\n\n".join(parts)[-6000:]


def firewall_rules(app_dir: Path, log: Log):
    """Windows: allow the app's Python to reach the internet (Telegram, updates). Best effort, never fatal.
    The venv's python.exe is only a launcher – the real network traffic comes from the base interpreter,
    so both get a rule."""
    if not IS_WIN:
        return
    exes = []
    venv = app_dir / ".venv" / "Scripts"
    for n in ("python.exe", "pythonw.exe"):
        if (venv / n).exists():
            exes.append(venv / n)
    try:
        cfg = (app_dir / ".venv" / "pyvenv.cfg").read_text(encoding="utf-8", errors="ignore")
        home = next((l.split("=", 1)[1].strip() for l in cfg.splitlines() if l.lower().startswith("home")), "")
        for n in ("python.exe", "pythonw.exe"):
            if home and (Path(home) / n).exists():
                exes.append(Path(home) / n)
    except OSError:
        pass
    for i, exe in enumerate(exes):
        name = f"School Bells - {exe.parent.name} {exe.name}"
        try:
            subprocess.run(["netsh", "advfirewall", "firewall", "delete", "rule", f"name={name}"],
                           capture_output=True, timeout=30, creationflags=NO_WINDOW)
            r = subprocess.run(["netsh", "advfirewall", "firewall", "add", "rule", f"name={name}", "dir=out",
                                "action=allow", f"program={exe}", "enable=yes", "profile=any"],
                               capture_output=True, timeout=30, creationflags=NO_WINDOW)
            log(f"firewall rule for {exe}: {'ok' if r.returncode == 0 else 'failed'}")
        except Exception as e:
            log(f"firewall rule for {exe} skipped: {e}")


def web_settings(app_dir: Path) -> tuple[bool, int]:
    try:
        import tomllib
        raw = tomllib.loads((app_dir / "config.toml").read_text(encoding="utf-8-sig"))
        web = raw.get("web", {})
        return bool(web.get("enabled", True)), int(web.get("port", 8787))
    except Exception:
        return True, 8787


def healthy(app_dir: Path, expect_version: str | None, timeout: int, log: Log) -> bool:
    enabled, port = web_settings(app_dir)
    deadline = time.time() + timeout
    if not enabled:  # no web UI: the process must stay up
        time.sleep(min(20, timeout))
        return bool(app_processes(app_dir))
    while time.time() < deadline:
        for path in ("/api/health", "/api/state"):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=3) as r:
                    data = json.loads(r.read() or b"{}")
                    if expect_version is None or (path == "/api/health" and data.get("version") == expect_version):
                        log(f"health ok ({path} {data.get('version', '')})")
                        return True
            except Exception:
                pass
        time.sleep(2)
    log("health check timed out")
    return False


# ---------------- update ----------------
def load_manifest(pkg: Path) -> dict:
    man = json.loads((pkg / "manifest.json").read_text(encoding="utf-8"))
    if man.get("app") != APP_ID or man.get("format") != FORMAT:
        raise Rejected("not a School Bells update package")
    return man


def check(man: dict, app_dir: Path, pkg: Path) -> str:
    if not (app_dir / "main.py").exists() or not (app_dir / "bells").is_dir():
        raise Rejected(f"{app_dir} is not a School Bells folder")
    cur, new = installed_version(app_dir), man["version"]
    if vtuple(new) <= vtuple(cur):
        raise Rejected(f"installed version {cur} is not older than {new} – nothing to do")
    if man.get("min_from") and vtuple(cur) < vtuple(man["min_from"]):
        raise Rejected(f"this update needs version {man['min_from']} or newer (installed: {cur}) – use the full installer")
    for rel, digest in man["files"].items():
        if not is_allowed_path(rel):
            raise Rejected(f"forbidden path in package: {rel}")
        f = pkg / "payload" / rel
        if not f.is_file() or sha256(f) != digest:
            raise Rejected(f"file damaged or missing in package: {rel}")
    for rel in man.get("delete", []):
        if not is_allowed_path(rel):
            raise Rejected(f"forbidden delete path: {rel}")
    return cur


def backup(app_dir: Path, man: dict, cur: str, log: Log) -> Path:
    bdir = app_dir / "updates" / "backups" / f"{cur}_{datetime.now():%Y%m%d_%H%M%S}"
    (bdir / "files").mkdir(parents=True, exist_ok=True)
    touched = list(man["files"]) + list(man.get("delete", []))
    existed, new_files = [], []
    for rel in touched:
        src = app_dir / rel
        if src.is_file():
            dst = bdir / "files" / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            existed.append(rel)
        else:
            new_files.append(rel)
    (bdir / "backup.json").write_text(json.dumps({"version": cur, "existed": existed, "new": new_files}, indent=1),
                                      encoding="utf-8")
    log(f"backup: {len(existed)} files -> {bdir}")
    return bdir


def replace_files(app_dir: Path, man: dict, pkg: Path, log: Log):
    for rel in man["files"]:
        dst = app_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + ".upd-new")
        shutil.copyfile(pkg / "payload" / rel, tmp)
        os.replace(tmp, dst)
    for rel in man.get("delete", []):
        (app_dir / rel).unlink(missing_ok=True)
    log(f"replaced {len(man['files'])} files, deleted {len(man.get('delete', []))}")


def restore(app_dir: Path, bdir: Path, log: Log):
    info = json.loads((bdir / "backup.json").read_text(encoding="utf-8"))
    for rel in info["existed"]:
        dst = app_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(bdir / "files" / rel, dst)
    for rel in info["new"]:
        (app_dir / rel).unlink(missing_ok=True)
    log(f"restored {len(info['existed'])} files, removed {len(info['new'])} new files")


def pip_install(app_dir: Path, log: Log):
    py = app_dir / ".venv" / ("Scripts/python.exe" if IS_WIN else "bin/python")
    if not py.exists():
        log("no venv – skipping pip")
        return
    r = subprocess.run([str(py), "-m", "pip", "install", "-q", "-r", str(app_dir / "requirements.txt")],
                       capture_output=True, timeout=900, creationflags=NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError("pip install failed: " + r.stderr.decode("utf-8", "ignore")[-400:])
    log("requirements installed")


def prune_backups(app_dir: Path):
    root = app_dir / "updates" / "backups"
    dirs = sorted((d for d in root.iterdir() if d.is_dir()), key=lambda d: d.stat().st_mtime) if root.exists() else []
    for d in dirs[:-KEEP_BACKUPS]:
        shutil.rmtree(d, ignore_errors=True)


def write_result(app_dir: Path, **kw):
    p = app_dir / "updates" / "last_result.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"at": datetime.now().isoformat(timespec="seconds"), "notified": False, **kw},
                            ensure_ascii=False, indent=1), encoding="utf-8")


def run(app_dir: Path, pkg: Path, health_timeout: int = 120) -> int:
    app_dir, pkg = app_dir.resolve(), pkg.resolve()
    man = load_manifest(pkg)
    log = Log(app_dir / "updates" / "logs" / f"update-{man['version']}.log")
    lock = app_dir / "updates" / "update.lock"
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        if time.time() - lock.stat().st_mtime < 1800:
            log("another update is running – abort")
            write_result(app_dir, status="rejected", to=man.get("version"), error="another update is running")
            return 2
        lock.unlink(missing_ok=True)
        return run(app_dir, pkg, health_timeout)
    try:
        try:
            cur = check(man, app_dir, pkg)
        except Rejected as e:
            log(f"REJECTED: {e}")
            write_result(app_dir, status="rejected", to=man.get("version"), error=str(e))
            return 2
        log(f"updating {cur} -> {man['version']} ({app_dir})")
        bdir = backup(app_dir, man, cur, log)
        started_at = time.time()
        try:
            stop_app(app_dir, log)
            replace_files(app_dir, man, pkg, log)
            firewall_rules(app_dir, log)
            if man.get("requirements_changed"):
                pip_install(app_dir, log)
            start_app(app_dir, log)
            if not healthy(app_dir, man["version"], health_timeout, log):
                raise RuntimeError(f"version {man['version']} did not start correctly")
        except Exception as e:
            log(f"FAILED: {e} – rolling back")
            tail = diagnostics(app_dir, started_at)       # read BEFORE rollback restarts the old version
            if tail:
                log("---- end of the failed version's logs ----\n" + tail)
            try:
                stop_app(app_dir, log)
            except Exception as e2:
                log(f"stop during rollback failed: {e2}")
            restore(app_dir, bdir, log)
            start_app(app_dir, log)
            ok = healthy(app_dir, None, health_timeout, log)
            write_result(app_dir, status="rolled_back", **{"from": cur, "to": man["version"]}, error=str(e),
                         old_running=ok, log_tail=tail)
            log("rollback complete" + ("" if ok else " (old version did not answer!)"))
            return 1
        write_result(app_dir, status="ok", **{"from": cur, "to": man["version"]}, changes=man.get("changes", []))
        prune_backups(app_dir)
        log(f"UPDATED to {man['version']}")
        return 0
    finally:
        lock.unlink(missing_ok=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app-dir", required=True)
    ap.add_argument("--package-dir", default=str(Path(__file__).resolve().parent))
    ap.add_argument("--health-timeout", type=int, default=120)
    a = ap.parse_args()
    sys.exit(run(Path(a.app_dir), Path(a.package_dir), a.health_timeout))


if __name__ == "__main__":
    main()
